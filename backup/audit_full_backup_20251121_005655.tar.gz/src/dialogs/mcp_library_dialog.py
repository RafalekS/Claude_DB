"""MCP Library Dialog - manages MCP server templates"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QCheckBox, QWidget, QDialogButtonBox, QInputDialog,
    QLineEdit, QFormLayout
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from pathlib import Path
import sys
import json
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.theme import *
from utils.template_manager import get_template_manager


class AddHTTPServerDialog(QDialog):
    """Simple dialog for adding HTTP MCP server templates"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add HTTP MCP Server Template")
        self.setModal(True)
        self.setMinimumWidth(500)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("Add HTTP MCP Server Template")
        header.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY}; font-size: {FONT_SIZE_NORMAL}px;")
        layout.addWidget(header)

        # Form layout
        form = QFormLayout()

        # Server Name
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g., sap-docs")
        self.name_input.setStyleSheet(get_line_edit_style())
        form.addRow("Server Name*:", self.name_input)

        # URL
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("e.g., https://mcp-sap-docs.marianzeis.de/mcp")
        self.url_input.setStyleSheet(get_line_edit_style())
        self.url_input.textChanged.connect(self.on_url_changed)
        form.addRow("URL*:", self.url_input)

        # Server Type (HTTP or SSE)
        type_layout = QHBoxLayout()
        self.http_radio = QPushButton("HTTP")
        self.http_radio.setCheckable(True)
        self.http_radio.setChecked(True)
        self.http_radio.setStyleSheet(get_button_style())
        self.http_radio.clicked.connect(lambda: self.set_type("http"))

        self.sse_radio = QPushButton("SSE")
        self.sse_radio.setCheckable(True)
        self.sse_radio.setStyleSheet(get_button_style())
        self.sse_radio.clicked.connect(lambda: self.set_type("sse"))

        type_layout.addWidget(self.http_radio)
        type_layout.addWidget(self.sse_radio)
        type_layout.addStretch()
        form.addRow("Type*:", type_layout)

        self.server_type = "http"

        layout.addLayout(form)

        # Info
        info = QLabel("* Required fields. This creates a template for an HTTP-based MCP server.")
        info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(info)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def set_type(self, server_type):
        """Set server type and update radio button states"""
        self.server_type = server_type
        self.http_radio.setChecked(server_type == "http")
        self.sse_radio.setChecked(server_type == "sse")

    def on_url_changed(self, text):
        """Auto-suggest server name from URL"""
        if not self.name_input.text():  # Only auto-fill if name is empty
            # Try to extract a meaningful name from URL
            # e.g., https://mcp-sap-docs.marianzeis.de/mcp -> sap-docs
            try:
                from urllib.parse import urlparse
                parsed = urlparse(text)
                hostname = parsed.hostname or ""
                # Try to extract from hostname
                if "mcp-" in hostname:
                    # Extract part after "mcp-"
                    parts = hostname.split("mcp-", 1)
                    if len(parts) > 1:
                        name_part = parts[1].split(".")[0]  # Get first part before domain
                        self.name_input.setText(name_part)
            except:
                pass

    def validate_and_accept(self):
        """Validate inputs before accepting"""
        if not self.name_input.text().strip():
            QMessageBox.warning(self, "Validation Error", "Server name is required!")
            return

        if not self.url_input.text().strip():
            QMessageBox.warning(self, "Validation Error", "URL is required!")
            return

        # Validate URL format
        url = self.url_input.text().strip()
        if not (url.startswith("http://") or url.startswith("https://")):
            QMessageBox.warning(self, "Validation Error", "URL must start with http:// or https://")
            return

        self.accept()

    def get_server_config(self):
        """Get the server configuration"""
        server_name = self.name_input.text().strip()
        server_config = {
            "type": self.server_type,
            "url": self.url_input.text().strip()
        }
        return server_name, server_config


class MCPLibraryDialog(QDialog):
    """Dialog for managing MCP server templates in config/templates/mcp/"""

    def __init__(self, templates_dir, scope, parent=None):
        super().__init__(parent)
        self.templates_dir = templates_dir
        self.scope = scope
        self.template_mgr = get_template_manager()
        self.setWindowTitle("MCP Server Library")
        self.setModal(True)
        self.setMinimumWidth(900)
        self.setMinimumHeight(700)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        header = QLabel("MCP Server Library - Manage and deploy MCP server templates")
        header.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY}; font-size: {FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        file_info = QLabel(f"Templates Folder: {self.templates_dir}")
        file_info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(file_info)

        self.load_templates()

        self.table = QTableWidget()
        self.table.setColumnCount(1)
        self.table.setHorizontalHeaderLabels(["Name"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSortingEnabled(True)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {BG_DARK};
                color: {FG_PRIMARY};
                border: 1px solid {BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {BG_MEDIUM};
                color: {FG_PRIMARY};
                padding: 5px;
                border: 1px solid {BG_LIGHT};
            }}
            QHeaderView::section:hover {{
                background-color: {BG_LIGHT};
                cursor: pointer;
            }}
        """)

        self.populate_table()
        layout.addWidget(self.table)

        manage_layout = QHBoxLayout()

        add_btn = QPushButton("➕ Add Template")
        add_btn.setStyleSheet(get_button_style())
        add_btn.setToolTip("Add stdio/command-based MCP server template")
        add_btn.clicked.connect(self.add_template)
        manage_layout.addWidget(add_btn)

        add_http_btn = QPushButton("🌐 Add HTTP Template")
        add_http_btn.setStyleSheet(get_button_style())
        add_http_btn.setToolTip("Add HTTP/SSE-based MCP server template")
        add_http_btn.clicked.connect(self.add_http_template)
        manage_layout.addWidget(add_http_btn)

        edit_btn = QPushButton("✏️ Edit Selected")
        edit_btn.setStyleSheet(get_button_style())
        edit_btn.clicked.connect(self.edit_template)
        manage_layout.addWidget(edit_btn)

        bulk_add_btn = QPushButton("📋 Bulk Add")
        bulk_add_btn.setStyleSheet(get_button_style())
        bulk_add_btn.clicked.connect(self.bulk_add_mcps)
        manage_layout.addWidget(bulk_add_btn)

        delete_btn = QPushButton("🗑️ Delete Selected")
        delete_btn.setStyleSheet(get_button_style())
        delete_btn.clicked.connect(self.delete_selected)
        manage_layout.addWidget(delete_btn)

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setStyleSheet(get_button_style())
        refresh_btn.clicked.connect(self.refresh_templates)
        manage_layout.addWidget(refresh_btn)

        open_folder_btn = QPushButton("📁 Open Folder")
        open_folder_btn.setStyleSheet(get_button_style())
        open_folder_btn.clicked.connect(self.open_folder)
        manage_layout.addWidget(open_folder_btn)

        manage_layout.addStretch()
        layout.addLayout(manage_layout)

        select_layout = QHBoxLayout()
        select_all_btn = QPushButton("✓ Select All")
        select_all_btn.setStyleSheet(get_button_style())
        select_all_btn.clicked.connect(self.select_all)
        select_layout.addWidget(select_all_btn)

        deselect_all_btn = QPushButton("✗ Deselect All")
        deselect_all_btn.setStyleSheet(get_button_style())
        deselect_all_btn.clicked.connect(self.deselect_all)
        select_layout.addWidget(deselect_all_btn)

        select_layout.addStretch()
        layout.addLayout(select_layout)

        info = QLabel("Select MCP servers to deploy, then click OK. You can also drop .json files directly into the templates folder.")
        info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def load_templates(self):
        self.templates = {}
        template_names = self.template_mgr.list_templates('mcp')

        for name in template_names:
            try:
                content = self.template_mgr.read_template('mcp', name)
                self.templates[name] = {
                    'content': content
                }
            except Exception as e:
                print(f"Error loading template {name}: {e}")

    def populate_table(self):
        # Disable sorting during population for better performance
        self.table.setSortingEnabled(False)

        self.table.setRowCount(len(self.templates))

        for row, (mcp_name, mcp_data) in enumerate(self.templates.items()):
            name_item = QTableWidgetItem(mcp_name)
            name_item.setForeground(QColor(FG_PRIMARY))
            self.table.setItem(row, 0, name_item)

        # Re-enable sorting and sort by name by default
        self.table.setSortingEnabled(True)
        self.table.sortItems(0, Qt.SortOrder.AscendingOrder)

    def select_all(self):
        self.table.selectAll()

    def deselect_all(self):
        self.table.clearSelection()

    def get_selected_mcps(self):
        selected = []
        for row in range(self.table.rowCount()):
            if self.table.item(row, 0).isSelected():
                mcp_name = self.table.item(row, 0).text()
                selected.append((mcp_name, self.templates[mcp_name]['content']))
        return selected

    def add_template(self):
        """Add a new template using the same dialog as MCP tab"""
        # Import here to avoid circular import
        from tabs.mcp_tab import AddServerDialog

        # Use the same AddServerDialog from MCP tab
        dialog = AddServerDialog(self, edit_mode=False)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            server_name, server_config = dialog.get_server_config()

            try:
                # Convert server config to JSON template
                content = json.dumps(server_config, indent=2)
                self.template_mgr.save_template('mcp', server_name, content)
                self.refresh_templates()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save template:\n{str(e)}")

    def add_http_template(self):
        """Add a new HTTP server template using simplified dialog"""
        dialog = AddHTTPServerDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            server_name, server_config = dialog.get_server_config()

            try:
                # Convert server config to JSON template
                content = json.dumps(server_config, indent=2)
                self.template_mgr.save_template('mcp', server_name, content)
                self.refresh_templates()
                QMessageBox.information(
                    self,
                    "Template Added",
                    f"HTTP server template '{server_name}' added successfully!"
                )
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save template:\n{str(e)}")

    def edit_template(self):
        """Edit selected template using the same dialog as MCP tab"""
        # Import here to avoid circular import
        from tabs.mcp_tab import AddServerDialog

        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select a template to edit.")
            return

        # Edit the first selected template
        row = selected_rows[0].row()
        mcp_name = self.table.item(row, 0).text()
        content = self.templates[mcp_name]['content']

        try:
            # Parse JSON to get server config
            server_config = json.loads(content)

            # Extract and preserve metadata fields
            metadata = {}
            metadata_fields = ['_creator', 'name', 'updated_at']
            for field in metadata_fields:
                if field in server_config:
                    metadata[field] = server_config.pop(field)
        except json.JSONDecodeError:
            QMessageBox.critical(self, "Invalid JSON", f"Template '{mcp_name}' contains invalid JSON.")
            return

        # Use AddServerDialog in edit mode
        dialog = AddServerDialog(
            self,
            edit_mode=True,
            server_name=mcp_name,
            server_config=server_config
        )
        if dialog.exec() == QDialog.DialogCode.Accepted:
            _, new_server_config = dialog.get_server_config()
            try:
                # Restore metadata fields
                final_config = {**metadata, **new_server_config}

                # Convert to JSON and save
                new_content = json.dumps(final_config, indent=2)
                self.template_mgr.save_template('mcp', mcp_name, new_content)
                self.refresh_templates()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save template:\n{str(e)}")

    def bulk_add_mcps(self):
        """Open bulk add dialog"""
        from dialogs.bulk_mcp_add_dialog import BulkMCPAddDialog
        dialog = BulkMCPAddDialog(self.templates_dir, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh_templates()

    def delete_selected(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select templates to delete.")
            return

        selected = [self.table.item(row.row(), 0).text() for row in selected_rows]

        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete {len(selected)} template(s)?\n\n" + "\n".join(selected),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            for name in selected:
                try:
                    self.template_mgr.delete_template('mcp', name)
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to delete {name}:\n{str(e)}")

            QMessageBox.information(self, "Success", f"Deleted {len(selected)} template(s)!")
            self.refresh_templates()

    def refresh_templates(self):
        self.load_templates()
        self.populate_table()

    def open_folder(self):
        import subprocess
        import platform
        if platform.system() == 'Windows':
            subprocess.Popen(['explorer', str(self.templates_dir)])
        elif platform.system() == 'Darwin':
            subprocess.Popen(['open', str(self.templates_dir)])
        else:
            subprocess.Popen(['xdg-open', str(self.templates_dir)])
