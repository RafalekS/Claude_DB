"""Skill Library Dialog - manages skill templates"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QCheckBox, QWidget, QDialogButtonBox, QInputDialog,
    QLineEdit, QFormLayout, QTextEdit, QGridLayout
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.theme import *
from utils.template_manager import get_template_manager

# Available Claude Code tools
AVAILABLE_TOOLS = [
    "Read", "Write", "Edit", "MultiEdit",
    "Grep", "Glob", "Bash",
    "WebFetch", "WebSearch",
    "Task", "TodoWrite", "NotebookEdit",
    "AskUserQuestion", "Skill", "SlashCommand"
]


class SkillLibraryDialog(QDialog):
    """Dialog for managing skill templates in config/templates/skills/"""

    def __init__(self, templates_dir, scope, parent=None):
        super().__init__(parent)
        self.templates_dir = templates_dir
        self.scope = scope
        self.template_mgr = get_template_manager()
        self.setWindowTitle("Skill Library")
        self.setModal(True)
        self.setMinimumWidth(900)
        self.setMinimumHeight(700)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        header = QLabel("Skill Library - Manage and deploy skill templates")
        header.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY}; font-size: {FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        file_info = QLabel(f"Templates Folder: {self.templates_dir}")
        file_info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(file_info)

        self.load_templates()

        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Name", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSortingEnabled(True)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {BG_DARK};
                color: {FG_PRIMARY};
                border: 1px solid {BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {BG_MEDIUM};
                color: {FG_PRIMARY};
                padding: 5px;
                border: 1px solid {BG_LIGHT};
            }}
            QHeaderView::section:hover {{
                background-color: {BG_LIGHT};
                cursor: pointer;
            }}
        """)

        self.populate_table()
        layout.addWidget(self.table)

        manage_layout = QHBoxLayout()

        add_btn = QPushButton("➕ Add Template")
        add_btn.setStyleSheet(get_button_style())
        add_btn.setToolTip("Create a new skill template")
        add_btn.clicked.connect(self.add_template)
        manage_layout.addWidget(add_btn)

        edit_btn = QPushButton("✏️ Edit Selected")
        edit_btn.setStyleSheet(get_button_style())
        edit_btn.setToolTip("Edit selected template")
        edit_btn.clicked.connect(self.edit_template)
        manage_layout.addWidget(edit_btn)

        bulk_add_btn = QPushButton("📋 Bulk Add")
        bulk_add_btn.setStyleSheet(get_button_style())
        bulk_add_btn.setToolTip("Add multiple skills at once by pasting")
        bulk_add_btn.clicked.connect(self.bulk_add_skills)
        manage_layout.addWidget(bulk_add_btn)

        delete_btn = QPushButton("🗑️ Delete Selected")
        delete_btn.setStyleSheet(get_button_style())
        delete_btn.clicked.connect(self.delete_selected)
        manage_layout.addWidget(delete_btn)

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setStyleSheet(get_button_style())
        refresh_btn.clicked.connect(self.refresh_templates)
        manage_layout.addWidget(refresh_btn)

        open_folder_btn = QPushButton("📁 Open Folder")
        open_folder_btn.setStyleSheet(get_button_style())
        open_folder_btn.clicked.connect(self.open_folder)
        manage_layout.addWidget(open_folder_btn)

        manage_layout.addStretch()
        layout.addLayout(manage_layout)

        select_layout = QHBoxLayout()
        select_all_btn = QPushButton("✓ Select All")
        select_all_btn.setStyleSheet(get_button_style())
        select_all_btn.clicked.connect(self.select_all)
        select_layout.addWidget(select_all_btn)

        deselect_all_btn = QPushButton("✗ Deselect All")
        deselect_all_btn.setStyleSheet(get_button_style())
        deselect_all_btn.clicked.connect(self.deselect_all)
        select_layout.addWidget(deselect_all_btn)

        select_layout.addStretch()
        layout.addLayout(select_layout)

        info = QLabel("Select skills to deploy, then click OK. You can also drop .md files directly into the templates folder.")
        info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def load_templates(self):
        self.templates = {}
        template_names = self.template_mgr.list_templates('skills')

        for name in template_names:
            try:
                content = self.template_mgr.read_template('skills', name)
                info = self.template_mgr.get_template_info('skills', name)
                description = info.get('description', 'No description') if info else 'No description'
                self.templates[name] = {
                    'content': content,
                    'description': description
                }
            except Exception as e:
                print(f"Error loading template {name}: {e}")

    def populate_table(self):
        # Disable sorting during population for better performance
        self.table.setSortingEnabled(False)

        self.table.setRowCount(len(self.templates))

        for row, (skill_name, skill_data) in enumerate(self.templates.items()):
            name_item = QTableWidgetItem(skill_name)
            name_item.setForeground(QColor(FG_PRIMARY))
            self.table.setItem(row, 0, name_item)

            description = skill_data.get('description', 'No description')
            desc_item = QTableWidgetItem(description)
            desc_item.setForeground(QColor(FG_SECONDARY))
            self.table.setItem(row, 1, desc_item)

        # Re-enable sorting and sort by name by default
        self.table.setSortingEnabled(True)
        self.table.sortItems(0, Qt.SortOrder.AscendingOrder)

    def select_all(self):
        self.table.selectAll()

    def deselect_all(self):
        self.table.clearSelection()

    def get_selected_skills(self):
        selected = []
        for row in range(self.table.rowCount()):
            if self.table.item(row, 0).isSelected():
                skill_name = self.table.item(row, 0).text()
                selected.append((skill_name, self.templates[skill_name]['content']))
        return selected

    def add_template(self):
        """Add a new template"""
        dialog = NewSkillTemplateDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            template_data = dialog.get_template_data()
            try:
                # Build frontmatter
                content = f"""---
name: {template_data['name']}
description: {template_data['description']}
allowed-tools: {template_data['allowed_tools']}
---

# {template_data['name']}

{template_data['description']}

## Usage

How to use this skill.
"""

                self.template_mgr.save_template('skills', template_data['name'], content)
                self.refresh_templates()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save template:\n{str(e)}")

    def edit_template(self):
        """Edit selected template with form dialog"""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select a template to edit.")
            return

        # Edit the first selected template
        row = selected_rows[0].row()
        skill_name = self.table.item(row, 0).text()
        content = self.templates[skill_name]['content']

        dialog = EditSkillTemplateDialog(skill_name, content, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_data = dialog.get_template_data()
            try:
                # Regenerate content with updated frontmatter
                new_content = f"""---
name: {new_data['name']}
description: {new_data['description']}
allowed-tools: {new_data['allowed_tools']}
---

# {new_data['name']}

{new_data['description']}

## Usage

How to use this skill.
"""
                self.template_mgr.save_template('skills', skill_name, new_content)
                self.refresh_templates()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save template:\n{str(e)}")

    def bulk_add_skills(self):
        """Open bulk add dialog"""
        from dialogs.bulk_skill_add_dialog import BulkSkillAddDialog
        dialog = BulkSkillAddDialog(self.templates_dir, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh_templates()

    def delete_selected(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select templates to delete.")
            return

        selected = [self.table.item(row.row(), 0).text() for row in selected_rows]

        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete {len(selected)} template(s)?\n\n" + "\n".join(selected),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            for name in selected:
                try:
                    self.template_mgr.delete_template('skills', name)
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to delete {name}:\n{str(e)}")

            QMessageBox.information(self, "Success", f"Deleted {len(selected)} template(s)!")
            self.refresh_templates()

    def refresh_templates(self):
        self.load_templates()
        self.populate_table()

    def open_folder(self):
        import subprocess
        import platform
        if platform.system() == 'Windows':
            subprocess.Popen(['explorer', str(self.templates_dir)])
        elif platform.system() == 'Darwin':
            subprocess.Popen(['open', str(self.templates_dir)])
        else:
            subprocess.Popen(['xdg-open', str(self.templates_dir)])


class NewSkillTemplateDialog(QDialog):
    """Dialog for creating a new skill template"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create New Skill Template")
        self.setMinimumWidth(500)
        self.init_ui()

    def init_ui(self):
        from PyQt6.QtWidgets import QFormLayout
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        form = QFormLayout()
        form.setSpacing(8)

        # Name field
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("e.g., example-skill")
        self.name_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Template Name*:", self.name_edit)

        # Description field
        self.description_edit = QTextEdit()
        self.description_edit.setPlaceholderText("e.g., A skill that does something useful")
        self.description_edit.setStyleSheet(get_text_edit_style())
        self.description_edit.setMinimumHeight(100)
        self.description_edit.setMaximumHeight(150)
        form.addRow("Description*:", self.description_edit)

        layout.addLayout(form)

        # Tools checkboxes
        tools_label = QLabel("Allowed Tools (optional):")
        tools_label.setStyleSheet(f"color: {FG_PRIMARY}; font-weight: bold;")
        layout.addWidget(tools_label)

        self.tool_checkboxes = {}
        tools_grid = QGridLayout()
        tools_grid.setSpacing(5)

        # Create checkboxes in a 3-column grid - default Read, Grep, Glob checked
        for idx, tool in enumerate(AVAILABLE_TOOLS):
            checkbox = QCheckBox(tool)
            checkbox.setStyleSheet(f"color: {FG_PRIMARY};")
            # Default to Read, Grep, Glob checked
            if tool in ["Read", "Grep", "Glob"]:
                checkbox.setChecked(True)
            self.tool_checkboxes[tool] = checkbox
            row = idx // 3
            col = idx % 3
            tools_grid.addWidget(checkbox, row, col)

        tools_widget = QWidget()
        tools_widget.setLayout(tools_grid)
        tools_widget.setStyleSheet(f"background: {BG_MEDIUM}; padding: 8px; border-radius: 3px;")
        layout.addWidget(tools_widget)

        info_label = QLabel("* Required fields")
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {FG_SECONDARY}; background: {BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(info_label)

        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.setStyleSheet(get_button_style())
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def validate_and_accept(self):
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "Validation Error", "Template name is required.")
            return
        if not self.description_edit.toPlainText().strip():
            QMessageBox.warning(self, "Validation Error", "Description is required.")
            return
        self.accept()

    def get_template_data(self):
        # Collect checked tools
        selected_tools = [tool for tool, checkbox in self.tool_checkboxes.items() if checkbox.isChecked()]
        tools_str = ", ".join(selected_tools) if selected_tools else ""

        return {
            'name': self.name_edit.text().strip(),
            'description': self.description_edit.toPlainText().strip(),
            'allowed_tools': tools_str
        }


class EditSkillTemplateDialog(QDialog):
    """Dialog for editing a skill template with form fields"""

    def __init__(self, template_name, content, parent=None):
        super().__init__(parent)
        self.template_name = template_name
        self.setWindowTitle(f"Edit Skill Template: {template_name}")
        self.setMinimumWidth(500)
        self.init_ui(content)

    def init_ui(self, content):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # Parse YAML frontmatter
        import re
        frontmatter_match = re.search(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if frontmatter_match:
            frontmatter_text = frontmatter_match.group(1)
            # Parse frontmatter fields
            name_match = re.search(r'name:\s*(.+)', frontmatter_text)
            desc_match = re.search(r'description:\s*(.+)', frontmatter_text)
            tools_match = re.search(r'allowed-tools:\s*(.+)', frontmatter_text)

            parsed_name = name_match.group(1).strip() if name_match else self.template_name
            parsed_desc = desc_match.group(1).strip() if desc_match else ""
            parsed_tools = tools_match.group(1).strip() if tools_match else "Read, Grep, Glob"
        else:
            parsed_name = self.template_name
            parsed_desc = ""
            parsed_tools = "Read, Grep, Glob"

        form = QFormLayout()
        form.setSpacing(8)

        # Name field
        self.name_edit = QLineEdit()
        self.name_edit.setText(parsed_name)
        self.name_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Template Name*:", self.name_edit)

        # Description field
        self.description_edit = QTextEdit()
        self.description_edit.setPlainText(parsed_desc)
        self.description_edit.setStyleSheet(get_text_edit_style())
        self.description_edit.setMinimumHeight(100)
        self.description_edit.setMaximumHeight(150)
        form.addRow("Description*:", self.description_edit)

        layout.addLayout(form)

        # Tools checkboxes
        tools_label = QLabel("Allowed Tools (optional):")
        tools_label.setStyleSheet(f"color: {FG_PRIMARY}; font-weight: bold;")
        layout.addWidget(tools_label)

        self.tool_checkboxes = {}
        tools_grid = QGridLayout()
        tools_grid.setSpacing(5)

        # Parse existing tools (comma-separated) and create set for lookup
        existing_tools = set()
        if parsed_tools:
            existing_tools = {tool.strip() for tool in parsed_tools.split(',')}

        # Create checkboxes in a 3-column grid
        for idx, tool in enumerate(AVAILABLE_TOOLS):
            checkbox = QCheckBox(tool)
            checkbox.setStyleSheet(f"color: {FG_PRIMARY};")
            # Check if this tool was in the parsed list
            if tool in existing_tools:
                checkbox.setChecked(True)
            self.tool_checkboxes[tool] = checkbox
            row = idx // 3
            col = idx % 3
            tools_grid.addWidget(checkbox, row, col)

        tools_widget = QWidget()
        tools_widget.setLayout(tools_grid)
        tools_widget.setStyleSheet(f"background: {BG_MEDIUM}; padding: 8px; border-radius: 3px;")
        layout.addWidget(tools_widget)

        info_label = QLabel("* Required fields")
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {FG_SECONDARY}; background: {BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(info_label)

        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.setStyleSheet(get_button_style())
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def validate_and_accept(self):
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "Validation Error", "Template name is required.")
            return
        if not self.description_edit.toPlainText().strip():
            QMessageBox.warning(self, "Validation Error", "Description is required.")
            return
        self.accept()

    def get_template_data(self):
        # Collect checked tools
        selected_tools = [tool for tool, checkbox in self.tool_checkboxes.items() if checkbox.isChecked()]
        tools_str = ", ".join(selected_tools) if selected_tools else ""

        return {
            'name': self.name_edit.text().strip(),
            'description': self.description_edit.toPlainText().strip(),
            'allowed_tools': tools_str
        }
