"""
Skills Tab - managing Claude Code skills (directory-based with SKILL.md files)
"""

import os
import shutil
from pathlib import Path
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit,
    QLabel, QMessageBox, QListWidget, QSplitter, QLineEdit, QInputDialog,
    QListWidgetItem, QGroupBox, QFileDialog, QTabWidget, QDialog,
    QDialogButtonBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QCheckBox, QAbstractItemView
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
import sys
import json
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import theme


class SkillsTab(QWidget):
    """Tab for managing Claude Code skills (directory-based)"""

    def __init__(self, config_manager, backup_manager, scope, project_context=None):
        super().__init__()
        self.config_manager = config_manager
        self.backup_manager = backup_manager
        self.scope = scope
        self.project_context = project_context
        self.current_skill = None

        # Validate parameters
        if scope == "project" and not project_context:
            raise ValueError("project_context is required when scope='project'")

        self.init_ui()

        # Connect to project changes if project scope
        if self.scope == "project" and self.project_context:
            self.project_context.project_changed.connect(self.on_project_changed)

    def init_ui(self):
        """Initialize the UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)

        # Header
        header_layout = QHBoxLayout()
        header_layout.setSpacing(5)

        scope_label = "User" if self.scope == "user" else "Project"
        header = QLabel(f"Skills Management ({scope_label})")
        header.setStyleSheet(f"font-size: {theme.FONT_SIZE_LARGE}px; font-weight: bold; color: {theme.ACCENT_PRIMARY};")

        header_layout.addWidget(header)
        header_layout.addStretch()

        layout.addLayout(header_layout)

        # Single skills editor for current scope
        editor_widget = self.create_skills_editor()
        layout.addWidget(editor_widget, 1)

        # Info section at bottom
        info_group = QGroupBox("About Skills")
        info_group.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 5px;
                margin-top: 5px;
                padding-top: 10px;
                color: {theme.FG_PRIMARY};
                background-color: {theme.BG_MEDIUM};
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
                background-color: {theme.BG_MEDIUM};
            }}
        """)

        info_layout = QVBoxLayout()
        info_text = QLabel(
            "Skills are directory-based, NOT stored in JSON files.\n"
            "• User Skills: ~/.claude/skills/ - Personal skills available across all projects\n"
            "• Project Skills: ./.claude/skills/ - Shared with team via git\n"
            "• Each skill is a directory containing a SKILL.md file\n"
            "• Skills are automatically discovered when Claude Code runs"
        )
        info_text.setWordWrap(True)
        info_text.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px; padding: 5px;")
        info_layout.addWidget(info_text)
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)

    def create_skills_editor(self):
        """Create skills editor for the current scope"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # File path label
        skills_dir = self.get_scope_skills_dir()
        self.path_label = QLabel(f"Directory: {skills_dir}")
        self.path_label.setStyleSheet(f"font-size: {theme.FONT_SIZE_SMALL}px; color: {theme.FG_SECONDARY};")
        layout.addWidget(self.path_label)

        # Splitter for list and editor
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left panel - skills list
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)

        # Search
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search skills...")
        self.search_box.textChanged.connect(self.filter_skills)
        self.search_box.setStyleSheet(theme.get_line_edit_style())
        left_layout.addWidget(self.search_box)

        list_label = QLabel("Skills (directories with SKILL.md)")
        list_label.setStyleSheet(f"font-size: {theme.FONT_SIZE_NORMAL}px; font-weight: bold; color: {theme.FG_PRIMARY};")
        left_layout.addWidget(list_label)

        self.skills_list = QListWidget()
        self.skills_list.itemClicked.connect(self.load_skill_content)
        self.skills_list.setStyleSheet(theme.get_list_widget_style())
        left_layout.addWidget(self.skills_list)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(5)

        new_btn = QPushButton("➕ New")
        new_btn.setToolTip("Create new skill")
        edit_btn = QPushButton("✏️ Edit")
        edit_btn.setToolTip("Load selected skill for editing")
        del_btn = QPushButton("🗑 Delete")
        del_btn.setToolTip("Delete selected skill")
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setToolTip("Reload skills list")
        library_btn = QPushButton("📚 Skill Library")
        library_btn.setToolTip("Browse and add skills from library templates")

        for btn in [new_btn, edit_btn, del_btn, refresh_btn, library_btn]:
            btn.setStyleSheet(theme.get_button_style())

        new_btn.clicked.connect(self.create_new_skill)
        edit_btn.clicked.connect(self.edit_skill)
        del_btn.clicked.connect(self.delete_skill)
        refresh_btn.clicked.connect(self.load_skills)
        library_btn.clicked.connect(self.open_skill_library)

        btn_layout.addWidget(new_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(del_btn)
        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(library_btn)
        left_layout.addLayout(btn_layout)

        splitter.addWidget(left_panel)

        # Right panel - editor
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(5)

        # Editor header
        editor_btn_layout = QHBoxLayout()
        editor_btn_layout.setSpacing(5)

        self.skill_name_label = QLabel("No skill selected")
        self.skill_name_label.setStyleSheet(theme.get_label_style("normal", "secondary"))

        save_btn = QPushButton("💾 Save")
        save_btn.setToolTip("Save SKILL.md file")
        backup_save_btn = QPushButton("📦 Backup & Save")
        backup_save_btn.setToolTip("Create backup and save SKILL.md")
        revert_btn = QPushButton("Revert")
        revert_btn.setToolTip("Revert to saved version")

        for btn in [save_btn, backup_save_btn, revert_btn]:
            btn.setStyleSheet(theme.get_button_style())

        save_btn.clicked.connect(self.save_skill)
        backup_save_btn.clicked.connect(self.backup_and_save_skill)
        revert_btn.clicked.connect(self.revert_skill)

        editor_btn_layout.addWidget(self.skill_name_label)
        editor_btn_layout.addStretch()
        editor_btn_layout.addWidget(save_btn)
        editor_btn_layout.addWidget(backup_save_btn)
        editor_btn_layout.addWidget(revert_btn)

        right_layout.addLayout(editor_btn_layout)

        # Editor
        self.editor = QTextEdit()
        self.editor.setStyleSheet(f"""
            QTextEdit {{
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: {theme.FONT_SIZE_NORMAL}px;
                background-color: {theme.BG_DARK};
                color: {theme.FG_PRIMARY};
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 3px;
                padding: 8px;
            }}
        """)
        self.editor.setPlaceholderText("Select a skill to edit its SKILL.md file, or create a new skill.")
        right_layout.addWidget(self.editor, 1)

        splitter.addWidget(right_panel)
        splitter.setSizes([300, 700])

        layout.addWidget(splitter, 1)

        # Load initial data
        self.load_skills()

        return widget

    def on_project_changed(self, project_path: Path):
        """Handle project context change"""
        # Update path label
        skills_dir = self.get_scope_skills_dir()
        if skills_dir:
            self.path_label.setText(f"Directory: {skills_dir}")
        # Reload skills from new project
        self.load_skills()

    def get_scope_skills_dir(self):
        """Get skills directory for the current scope"""
        if self.scope == "user":
            return self.config_manager.claude_dir / "skills"
        else:  # project
            if not self.project_context or not self.project_context.has_project():
                return None
            return self.project_context.get_project() / ".claude" / "skills"


    def load_skills(self):
        """Load all skills from the scope's directory"""
        self.skills_list.clear()

        skills_dir = self.get_scope_skills_dir()

        if skills_dir and skills_dir.exists():
            for skill_dir in skills_dir.iterdir():
                if skill_dir.is_dir():
                    skill_md = skill_dir / "SKILL.md"
                    if skill_md.exists():
                        item = QListWidgetItem(skill_dir.name)
                        item.setData(Qt.ItemDataRole.UserRole, skill_dir)
                        item.setForeground(QColor(theme.ACCENT_PRIMARY))
                        self.skills_list.addItem(item)

        # Show message if no skills found
        if self.skills_list.count() == 0:
            item = QListWidgetItem("No skills found. Click 'New' to create one.")
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            item.setForeground(QColor(theme.FG_DIM))
            self.skills_list.addItem(item)

    def filter_skills(self, text):
        """Filter skills list based on search text"""
        for i in range(self.skills_list.count()):
            item = self.skills_list.item(i)
            if text.lower() in item.text().lower():
                item.setHidden(False)
            else:
                item.setHidden(True)

    def load_skill_content(self, item):
        """Load selected skill's SKILL.md content"""
        skill_path = item.data(Qt.ItemDataRole.UserRole)
        if not skill_path:
            return

        skill_md = skill_path / "SKILL.md"

        if not skill_md.exists():
            QMessageBox.warning(
                self,
                "File Not Found",
                f"SKILL.md not found at:\n{skill_md}"
            )
            return

        try:
            with open(skill_md, 'r', encoding='utf-8') as f:
                content = f.read()

            self.editor.setPlainText(content)
            self.current_skill = skill_path
            self.skill_name_label.setText(f"Editing: {skill_path.name}")

        except Exception as e:
            QMessageBox.critical(
                self,
                "Load Error",
                f"Failed to load SKILL.md:\n{str(e)}"
            )

    def edit_skill(self):
        """Load selected skill for editing"""
        current_item = self.skills_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "No Selection", "Please select a skill to edit.")
            return
        self.load_skill_content(current_item)

    def create_new_skill(self):
        """Create a new skill directory and SKILL.md file"""
        # Ask for skill name
        skill_name, ok = QInputDialog.getText(
            self,
            "New Skill",
            "Enter skill name (will be used as directory name):\n\nTip: Use subfolder/name for nested skills (e.g., 'my-category/skill-name')"
        )

        if not ok or not skill_name:
            return

        # Clean up the skill name
        skill_name = skill_name.strip().lower().replace(' ', '-')

        skills_dir = self.get_scope_skills_dir()
        skill_dir = skills_dir / skill_name
        skill_md = skill_dir / "SKILL.md"

        # Check if already exists
        if skill_dir.exists():
            QMessageBox.warning(
                self,
                "Skill Exists",
                f"A skill named '{skill_name}' already exists at:\n{skill_dir}"
            )
            return

        try:
            # Create directory (and parent directories if needed)
            skill_dir.mkdir(parents=True, exist_ok=True)

            # Get just the skill name for template
            display_name = Path(skill_name).stem

            # Create SKILL.md with template
            template = f"""# {display_name}

## Description
Describe what this skill does.

## Usage
Explain how to use this skill.

## Examples
Provide examples of using this skill.
"""

            with open(skill_md, 'w', encoding='utf-8') as f:
                f.write(template)

            QMessageBox.information(
                self,
                "Skill Created",
                f"New skill created at:\n{skill_dir}\n\nSKILL.md has been created with a template."
            )

            # Reload skills list
            self.load_skills()

        except Exception as e:
            QMessageBox.critical(
                self,
                "Creation Error",
                f"Failed to create skill:\n{str(e)}"
            )

    def delete_skill(self):
        """Delete the selected skill directory"""
        current_item = self.skills_list.currentItem()
        if not current_item:
            QMessageBox.warning(
                self,
                "No Selection",
                "Please select a skill to delete."
            )
            return

        skill_path = current_item.data(Qt.ItemDataRole.UserRole)
        if not skill_path:
            return

        skill_name = skill_path.name

        # Confirm deletion
        reply = QMessageBox.question(
            self,
            "Confirm Deletion",
            f"Are you sure you want to delete the skill '{skill_name}'?\n\n"
            f"This will delete the entire directory:\n{skill_path}\n\n"
            f"This action cannot be undone!",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Delete directory and all contents
                shutil.rmtree(skill_path)

                QMessageBox.information(
                    self,
                    "Deleted",
                    f"Skill '{skill_name}' has been deleted."
                )

                # Clear editor
                self.editor.clear()
                self.skill_name_label.setText("No skill selected")
                self.current_skill = None

                # Reload list
                self.load_skills()

            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Deletion Error",
                    f"Failed to delete skill:\n{str(e)}"
                )

    def save_skill(self):
        """Save current SKILL.md content"""
        current_skill = self.current_skill
        if not current_skill:
            QMessageBox.warning(
                self,
                "No Skill Selected",
                "Please select a skill to save."
            )
            return

        skill_md = current_skill / "SKILL.md"

        try:
            # Save content
            content = self.editor.toPlainText()
            with open(skill_md, 'w', encoding='utf-8') as f:
                f.write(content)

            QMessageBox.information(
                self,
                "Saved",
                f"SKILL.md saved to:\n{skill_md}"
            )

        except Exception as e:
            QMessageBox.critical(
                self,
                "Save Error",
                f"Failed to save SKILL.md:\n{str(e)}"
            )

    def backup_and_save_skill(self):
        """Create backup and save current SKILL.md"""
        current_skill = self.current_skill
        if not current_skill:
            QMessageBox.warning(
                self,
                "No Skill Selected",
                "Please select a skill to save."
            )
            return

        skill_md = current_skill / "SKILL.md"

        try:
            # Create backup if file exists
            if skill_md.exists():
                self.backup_manager.create_file_backup(skill_md)

            # Save content
            content = self.editor.toPlainText()
            with open(skill_md, 'w', encoding='utf-8') as f:
                f.write(content)

            QMessageBox.information(
                self,
                "Saved",
                f"Backup created and SKILL.md saved to:\n{skill_md}"
            )

        except Exception as e:
            QMessageBox.critical(
                self,
                "Save Error",
                f"Failed to save SKILL.md:\n{str(e)}"
            )

    def revert_skill(self):
        """Revert to saved version"""
        current_skill = self.current_skill
        if not current_skill:
            return

        reply = QMessageBox.question(
            self,
            "Revert Changes",
            "Are you sure you want to revert to the saved version?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                skill_md = current_skill / "SKILL.md"
                with open(skill_md, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.editor.setPlainText(content)
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Error",
                    f"Failed to revert:\n{str(e)}"
                )

    def open_skill_library(self):
        """Open skill library to browse and add skills from templates"""
        sources_file = Path(__file__).parent.parent.parent / "config" / "sources" / "skills.json"

        if not sources_file.exists():
            QMessageBox.warning(
                self, "Library Not Found",
                f"Skill library file not found:\n{sources_file}\n\nPlease ensure the file exists."
            )
            return

        dialog = SkillSourcesDialog(sources_file, self.scope, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            selected = dialog.get_selected_skills()
            if selected:
                self.deploy_skills(selected)
                self.load_skills()

    def deploy_skills(self, skills):
        """Deploy selected skills to the specified scope"""
        skills_dir = self.get_scope_skills_dir()
        if not skills_dir:
            QMessageBox.warning(self, "No Project", "Please select a project first.")
            return
        skills_dir.mkdir(parents=True, exist_ok=True)

        added_count = 0
        skipped_count = 0

        for skill_name, skill_data in skills:
            skill_dir = skills_dir / skill_name
            if skill_dir.exists():
                skipped_count += 1
                continue

            try:
                skill_dir.mkdir(parents=True, exist_ok=True)
                skill_md = skill_dir / "SKILL.md"
                content = skill_data.get("content", "")
                with open(skill_md, 'w', encoding='utf-8') as f:
                    f.write(content)
                added_count += 1
            except Exception as e:
                QMessageBox.critical(self, "Deploy Error", f"Failed to deploy '{skill_name}':\n{str(e)}")

        if added_count > 0 or skipped_count > 0:
            msg = f"Added {added_count} skill(s)"
            if skipped_count > 0:
                msg += f"\nSkipped {skipped_count} (already exist)"
            QMessageBox.information(self, "Deploy Complete", msg)


class SkillSourcesDialog(QDialog):
    """Dialog for adding skills from config/sources/skills.json"""

    def __init__(self, sources_file, scope, parent=None):
        super().__init__(parent)
        self.sources_file = sources_file
        self.scope = scope
        self.setWindowTitle("Skill Library")
        self.setModal(True)
        self.setMinimumWidth(900)
        self.setMinimumHeight(700)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("Skill Library - Manage and deploy skill templates")
        header.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY}; font-size: {theme.FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        # File info
        file_info = QLabel(f"Source File: {self.sources_file}")
        file_info.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px;")
        layout.addWidget(file_info)

        # Load sources
        try:
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                sources_data = json.load(f)
            self.skills = sources_data.get("skills", {})
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load skill sources:\n{str(e)}")
            self.skills = {}

        # Table with checkboxes
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Select", "Name", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {theme.BG_DARK};
                color: {theme.FG_PRIMARY};
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {theme.BG_MEDIUM};
                color: {theme.FG_PRIMARY};
                padding: 5px;
                border: 1px solid {theme.BG_LIGHT};
            }}
        """)

        # Populate table
        self.checkboxes = []
        self.table.setRowCount(len(self.skills))
        for row, (skill_name, skill_data) in enumerate(self.skills.items()):
            # Checkbox
            checkbox = QCheckBox()
            checkbox_widget = QWidget()
            checkbox_layout = QHBoxLayout(checkbox_widget)
            checkbox_layout.addWidget(checkbox)
            checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            checkbox_layout.setContentsMargins(0, 0, 0, 0)
            self.table.setCellWidget(row, 0, checkbox_widget)
            self.checkboxes.append((skill_name, checkbox))

            # Name
            name_item = QTableWidgetItem(skill_name)
            self.table.setItem(row, 1, name_item)

            # Description
            description = skill_data.get("description", "No description")
            desc_item = QTableWidgetItem(description)
            self.table.setItem(row, 2, desc_item)

        layout.addWidget(self.table)

        # Management buttons
        manage_layout = QHBoxLayout()

        delete_btn = QPushButton("🗑️ Delete Selected")
        delete_btn.setStyleSheet(theme.get_button_style())
        delete_btn.setToolTip("Delete selected skills from library")
        delete_btn.clicked.connect(self.delete_selected)
        manage_layout.addWidget(delete_btn)

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setStyleSheet(theme.get_button_style())
        refresh_btn.setToolTip("Reload skills from file")
        refresh_btn.clicked.connect(self.refresh_sources)
        manage_layout.addWidget(refresh_btn)

        manage_layout.addStretch()
        layout.addLayout(manage_layout)

        # Select All / Deselect All buttons
        select_layout = QHBoxLayout()
        select_all_btn = QPushButton("✓ Select All")
        select_all_btn.setStyleSheet(theme.get_button_style())
        select_all_btn.clicked.connect(self.select_all)
        select_layout.addWidget(select_all_btn)

        deselect_all_btn = QPushButton("✗ Deselect All")
        deselect_all_btn.setStyleSheet(theme.get_button_style())
        deselect_all_btn.clicked.connect(self.deselect_all)
        select_layout.addWidget(deselect_all_btn)

        select_layout.addStretch()
        layout.addLayout(select_layout)

        # Info label
        info = QLabel("Select skills to deploy, then click OK.")
        info.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px;")
        layout.addWidget(info)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def select_all(self):
        """Select all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(True)

    def deselect_all(self):
        """Deselect all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(False)

    def get_selected_skills(self):
        """Get list of selected skill names and their data"""
        selected = []
        for skill_name, checkbox in self.checkboxes:
            if checkbox.isChecked():
                selected.append((skill_name, self.skills[skill_name]))
        return selected

    def delete_selected(self):
        """Delete selected skills from config/sources/skills.json"""
        selected = self.get_selected_skills()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select skills to delete.")
            return

        skill_names = [name for name, _ in selected]
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete {len(skill_names)} skill(s) from library?\n\n" + "\n".join(skill_names),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                with open(self.sources_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                for name in skill_names:
                    if name in data.get("skills", {}):
                        del data["skills"][name]

                with open(self.sources_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)

                QMessageBox.information(self, "Success", f"Deleted {len(skill_names)} skill(s) from library.")
                self.refresh_sources()
            except Exception as e:
                QMessageBox.critical(self, "Delete Error", f"Failed to delete skills:\n{str(e)}")

    def refresh_sources(self):
        """Reload skills from file and refresh table"""
        try:
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.skills = data.get("skills", {})

            # Rebuild table
            self.checkboxes = []
            self.table.setRowCount(len(self.skills))

            for row, (skill_name, skill_data) in enumerate(self.skills.items()):
                # Checkbox
                checkbox = QCheckBox()
                checkbox_widget = QWidget()
                checkbox_layout = QHBoxLayout(checkbox_widget)
                checkbox_layout.addWidget(checkbox)
                checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
                checkbox_layout.setContentsMargins(0, 0, 0, 0)
                self.table.setCellWidget(row, 0, checkbox_widget)
                self.checkboxes.append((skill_name, checkbox))

                # Name
                name_item = QTableWidgetItem(skill_name)
                name_item.setForeground(QColor(theme.FG_PRIMARY))
                self.table.setItem(row, 1, name_item)

                # Description
                description = skill_data.get("description", "No description")
                desc_item = QTableWidgetItem(description)
                desc_item.setForeground(QColor(theme.FG_SECONDARY))
                self.table.setItem(row, 2, desc_item)

        except Exception as e:
            QMessageBox.critical(self, "Reload Error", f"Failed to reload skills:\n{str(e)}")
