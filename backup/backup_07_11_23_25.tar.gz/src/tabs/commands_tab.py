"""
Commands Tab - Manage Claude Code commands
"""

from pathlib import Path
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit,
    QLabel, QMessageBox, QListWidget, QSplitter, QLineEdit, QInputDialog,
    QFileDialog, QTabWidget, QDialog, QDialogButtonBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QCheckBox, QAbstractItemView
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
import sys
import json
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.theme import *


class CommandsTab(QWidget):
    """Tab for managing Claude Code commands (single-scope)"""

    def __init__(self, config_manager, backup_manager, scope, project_context=None):
        super().__init__()
        self.config_manager = config_manager
        self.backup_manager = backup_manager
        self.scope = scope
        self.project_context = project_context

        # Validate parameters
        if scope == "project" and not project_context:
            raise ValueError("project_context is required when scope='project'")

        self.init_ui()

        # Connect to project changes if project scope
        if self.scope == "project" and self.project_context:
            self.project_context.project_changed.connect(self.on_project_changed)

    def init_ui(self):
        """Initialize the UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)

        # Header
        header_layout = QHBoxLayout()
        header_layout.setSpacing(5)

        scope_label = "User" if self.scope == "user" else "Project"
        header = QLabel(f"Commands ({scope_label})")
        header.setStyleSheet(f"font-size: {FONT_SIZE_LARGE}px; font-weight: bold; color: {ACCENT_PRIMARY};")

        header_layout.addWidget(header)
        header_layout.addStretch()

        layout.addLayout(header_layout)

        # Single commands editor for current scope
        editor_widget = self.create_commands_editor()
        layout.addWidget(editor_widget, 1)

        # Info tip with essential commands
        tip_label = QLabel(
            "💡 <b>Essential Built-in Commands:</b> "
            "/add-dir (add directories) • "
            "/agents (manage subagents) • "
            "/clear (erase history) • "
            "/config (settings) • "
            "/cost (token usage) • "
            "/doctor (health check) • "
            "/init (create CLAUDE.md) • "
            "/mcp (MCP servers) • "
            "/memory (edit CLAUDE.md) • "
            "/model (change model) • "
            "/permissions (tool access) • "
            "/review (code review) • "
            "/status (account) • "
            "/vim (vim mode)"
            "<br><b>Custom Commands:</b> "
            "Create .md files in commands/ directory • "
            "User commands (~/.claude/commands/) are global • "
            "Project commands (./.claude/commands/) are shared via git • "
            "Use <code>/command-name</code> to invoke"
        )
        tip_label.setWordWrap(True)
        tip_label.setStyleSheet(f"color: {FG_SECONDARY}; background: {BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(tip_label)

    def create_commands_editor(self):
        """Create commands editor for the current scope"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # File path label
        commands_dir = self.get_scope_commands_dir()
        path_label = QLabel(f"Directory: {commands_dir}")
        path_label.setStyleSheet(f"font-size: {FONT_SIZE_SMALL}px; color: {FG_SECONDARY};")
        layout.addWidget(path_label)

        # Store references
        self.path_label = path_label
        self.current_command = None

        # Splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left panel - command list
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)

        # Search
        search_box = QLineEdit()
        search_box.setPlaceholderText("Search...")
        search_box.textChanged.connect(self.filter_commands)
        search_box.setStyleSheet(get_line_edit_style())
        left_layout.addWidget(search_box)

        # Command list
        command_list = QListWidget()
        command_list.itemClicked.connect(self.load_command_content)
        command_list.setStyleSheet(get_list_widget_style())
        left_layout.addWidget(command_list)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(5)

        new_btn = QPushButton("➕ New")
        new_btn.setToolTip("Create a new command")
        edit_btn = QPushButton("✏️ Edit")
        edit_btn.setToolTip("Load selected command for editing")
        del_btn = QPushButton("🗑️ Delete")
        del_btn.setToolTip("Delete the selected command")
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setToolTip("Reload the commands list")
        library_btn = QPushButton("📚 Command Library")
        library_btn.setToolTip("Browse and add commands from library templates")

        for btn in [new_btn, edit_btn, del_btn, refresh_btn, library_btn]:
            btn.setStyleSheet(get_button_style())

        new_btn.clicked.connect(self.create_new_command)
        edit_btn.clicked.connect(self.edit_command)
        del_btn.clicked.connect(self.delete_command)
        refresh_btn.clicked.connect(self.load_commands)
        library_btn.clicked.connect(self.open_command_library)

        btn_layout.addWidget(new_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(del_btn)
        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(library_btn)
        left_layout.addLayout(btn_layout)

        splitter.addWidget(left_panel)

        # Right panel - editor
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(5)

        # Editor buttons
        editor_btn_layout = QHBoxLayout()
        editor_btn_layout.setSpacing(5)

        command_name_label = QLabel("No command selected")
        command_name_label.setStyleSheet(get_label_style("normal", "secondary"))

        save_btn = QPushButton("💾 Save")
        save_btn.setToolTip("Save the current command to file")
        backup_save_btn = QPushButton("📦 Backup & Save")
        backup_save_btn.setToolTip("Create timestamped backup before saving command")
        revert_btn = QPushButton("Revert")
        revert_btn.setToolTip("Revert to saved version (discards unsaved changes)")

        for btn in [save_btn, backup_save_btn, revert_btn]:
            btn.setStyleSheet(get_button_style())

        save_btn.clicked.connect(self.save_command)
        backup_save_btn.clicked.connect(self.backup_and_save_command)
        revert_btn.clicked.connect(self.revert_command)

        editor_btn_layout.addWidget(command_name_label)
        editor_btn_layout.addStretch()
        editor_btn_layout.addWidget(save_btn)
        editor_btn_layout.addWidget(backup_save_btn)
        editor_btn_layout.addWidget(revert_btn)
        right_layout.addLayout(editor_btn_layout)

        # Editor
        command_editor = QTextEdit()
        command_editor.setStyleSheet(get_text_edit_style())
        right_layout.addWidget(command_editor)

        splitter.addWidget(right_panel)
        splitter.setSizes([300, 1000])

        layout.addWidget(splitter, 1)

        # Store references
        self.search_box = search_box
        self.command_list = command_list
        self.command_name_label = command_name_label
        self.command_editor = command_editor

        # Load initial data
        self.load_commands()

        return widget

    def get_scope_commands_dir(self):
        """Get commands directory for the current scope"""
        if self.scope == "user":
            return self.config_manager.commands_dir
        else:  # project
            if not self.project_context.has_project():
                return None
            return self.project_context.get_project() / ".claude" / "commands"

    def on_project_changed(self, project_path: Path):
        """Handle project context change"""
        # Update path label
        commands_dir = self.get_scope_commands_dir()
        if commands_dir:
            self.path_label.setText(f"Directory: {commands_dir}")
        # Reload commands from new project
        self.load_commands()

    def load_commands(self):
        """Load all commands for the current scope"""
        try:
            self.command_list.clear()

            commands_dir = self.get_scope_commands_dir()

            if not commands_dir or not commands_dir.exists():
                return

            # List all .md files in commands directory and subdirectories (recursive)
            commands = list(commands_dir.glob("**/*.md"))
            for command_path in sorted(commands):
                # Show relative path from commands_dir
                rel_path = command_path.relative_to(commands_dir)
                self.command_list.addItem(str(rel_path))

        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load commands:\n{str(e)}")

    def filter_commands(self, text):
        """Filter commands based on search text"""
        for i in range(self.command_list.count()):
            item = self.command_list.item(i)
            item.setHidden(text.lower() not in item.text().lower())

    def load_command_content(self, item):
        """Load content of selected command"""
        try:
            command_name = item.text()
            commands_dir = self.get_scope_commands_dir()
            command_path = commands_dir / command_name

            if command_path.exists():
                with open(command_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.current_command = command_path
                self.command_name_label.setText(f"Editing: {command_name}")
                self.command_editor.setPlainText(content)
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load command:\n{str(e)}")

    def edit_command(self):
        """Load selected command for editing"""
        current_item = self.command_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "No Selection", "Please select a command to edit.")
            return
        self.load_command_content(current_item)

    def save_command(self):
        """Save current command"""
        if not self.current_command:
            QMessageBox.warning(self, "No Command Selected", "Please select a command to save.")
            return
        try:
            content = self.command_editor.toPlainText()
            with open(self.current_command, 'w', encoding='utf-8') as f:
                f.write(content)
            QMessageBox.information(self, "Save Success", "Command saved successfully!")
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save command:\n{str(e)}")

    def backup_and_save_command(self):
        """Backup and save current command"""
        if not self.current_command:
            QMessageBox.warning(self, "No Command Selected", "Please select a command to save.")
            return
        try:
            self.backup_manager.create_file_backup(self.current_command)
            content = self.command_editor.toPlainText()
            with open(self.current_command, 'w', encoding='utf-8') as f:
                f.write(content)
            QMessageBox.information(self, "Backup & Save Success", "Backup created and command saved!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to backup and save:\n{str(e)}")

    def revert_command(self):
        """Revert command to saved version"""
        if not self.current_command:
            return
        reply = QMessageBox.question(
            self, "Revert Changes", "Are you sure you want to revert to the saved version?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            try:
                with open(self.current_command, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.command_editor.setPlainText(content)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to revert:\n{str(e)}")

    def create_new_command(self):
        """Create a new command"""
        name, ok = QInputDialog.getText(
            self,
            "New Command",
            "Enter command name (without .md extension):\n\nTip: Use subfolder/name for nested commands (e.g., 'config/bash-timeout')"
        )
        if ok and name:
            # Clean up the path
            name = name.strip()
            if not name.endswith('.md'):
                name += '.md'

            commands_dir = self.get_scope_commands_dir()
            command_path = commands_dir / name

            if command_path.exists():
                QMessageBox.warning(self, "Command Exists", f"Command '{name}' already exists.")
                return
            try:
                # Create parent directories if they don't exist
                command_path.parent.mkdir(parents=True, exist_ok=True)

                # Get just the filename for the template title
                command_name = Path(name).stem

                template = f"""# {command_name}

## Description
Brief description of what this command does.

## Usage
When to use this command.

## Instructions
Detailed instructions for the command.
"""
                with open(command_path, 'w', encoding='utf-8') as f:
                    f.write(template)
                self.load_commands()
                QMessageBox.information(self, "Command Created", f"Command '{name}' created successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to create command:\n{str(e)}")

    def delete_command(self):
        """Delete selected command"""
        if not self.current_command:
            QMessageBox.warning(self, "No Command Selected", "Please select a command to delete.")
            return
        reply = QMessageBox.question(
            self, "Delete Command", f"Are you sure you want to delete:\n{self.current_command.name}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            try:
                self.current_command.unlink()
                self.command_editor.clear()
                self.command_name_label.setText("No command selected")
                self.current_command = None
                self.load_commands()
                QMessageBox.information(self, "Delete Success", "Command deleted successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to delete command:\n{str(e)}")

    def open_command_library(self):
        """Open command library to browse and add commands from templates"""
        sources_file = Path(__file__).parent.parent.parent / "config" / "sources" / "commands.json"

        if not sources_file.exists():
            QMessageBox.warning(
                self, "Library Not Found",
                f"Command library file not found:\n{sources_file}\n\nPlease ensure the file exists."
            )
            return

        dialog = CommandSourcesDialog(sources_file, self.scope, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            selected = dialog.get_selected_commands()
            if selected:
                self.deploy_commands(selected)
                self.load_commands()

    def deploy_commands(self, commands):
        """Deploy selected commands to the current scope"""
        commands_dir = self.get_scope_commands_dir()
        commands_dir.mkdir(parents=True, exist_ok=True)

        added_count = 0
        skipped_count = 0

        for cmd_name, cmd_data in commands:
            cmd_file = commands_dir / f"{cmd_name}.md"
            if cmd_file.exists():
                skipped_count += 1
                continue

            try:
                content = cmd_data.get("content", "")
                with open(cmd_file, 'w', encoding='utf-8') as f:
                    f.write(content)
                added_count += 1
            except Exception as e:
                QMessageBox.critical(self, "Deploy Error", f"Failed to deploy '{cmd_name}':\n{str(e)}")

        if added_count > 0 or skipped_count > 0:
            msg = f"Added {added_count} command(s)"
            if skipped_count > 0:
                msg += f"\nSkipped {skipped_count} (already exist)"
            QMessageBox.information(self, "Deploy Complete", msg)


class CommandSourcesDialog(QDialog):
    """Dialog for adding commands from config/sources/commands.json"""

    def __init__(self, sources_file, scope, parent=None):
        super().__init__(parent)
        self.sources_file = sources_file
        self.scope = scope
        self.setWindowTitle("Command Library")
        self.setModal(True)
        self.setMinimumWidth(900)
        self.setMinimumHeight(700)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("Command Library - Manage and deploy command templates")
        header.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY}; font-size: {FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        # File info
        file_info = QLabel(f"Source File: {self.sources_file}")
        file_info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(file_info)

        # Load sources
        try:
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                sources_data = json.load(f)
            self.commands = sources_data.get("commands", {})
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load command sources:\n{str(e)}")
            self.commands = {}

        # Table with checkboxes
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Select", "Name", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {BG_DARK};
                color: {FG_PRIMARY};
                border: 1px solid {BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {BG_MEDIUM};
                color: {FG_PRIMARY};
                padding: 5px;
                border: 1px solid {BG_LIGHT};
            }}
        """)

        # Populate table
        self.checkboxes = []
        self.table.setRowCount(len(self.commands))
        for row, (cmd_name, cmd_data) in enumerate(self.commands.items()):
            # Checkbox
            checkbox = QCheckBox()
            checkbox_widget = QWidget()
            checkbox_layout = QHBoxLayout(checkbox_widget)
            checkbox_layout.addWidget(checkbox)
            checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            checkbox_layout.setContentsMargins(0, 0, 0, 0)
            self.table.setCellWidget(row, 0, checkbox_widget)
            self.checkboxes.append((cmd_name, checkbox))

            # Name
            name_item = QTableWidgetItem(cmd_name)
            self.table.setItem(row, 1, name_item)

            # Description
            description = cmd_data.get("description", "No description")
            desc_item = QTableWidgetItem(description)
            self.table.setItem(row, 2, desc_item)

        layout.addWidget(self.table)

        # Management buttons
        manage_layout = QHBoxLayout()

        bulk_add_btn = QPushButton("➕ Bulk Add Commands")
        bulk_add_btn.setStyleSheet(get_button_style())
        bulk_add_btn.setToolTip("Open bulk paste dialog to add multiple commands at once")
        bulk_add_btn.clicked.connect(self.open_bulk_add)
        manage_layout.addWidget(bulk_add_btn)

        delete_btn = QPushButton("🗑️ Delete Selected")
        delete_btn.setStyleSheet(get_button_style())
        delete_btn.setToolTip("Delete selected commands from library")
        delete_btn.clicked.connect(self.delete_selected)
        manage_layout.addWidget(delete_btn)

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setStyleSheet(get_button_style())
        refresh_btn.setToolTip("Reload commands from file")
        refresh_btn.clicked.connect(self.refresh_sources)
        manage_layout.addWidget(refresh_btn)

        manage_layout.addStretch()
        layout.addLayout(manage_layout)

        # Select All / Deselect All buttons
        select_layout = QHBoxLayout()
        select_all_btn = QPushButton("✓ Select All")
        select_all_btn.setStyleSheet(get_button_style())
        select_all_btn.clicked.connect(self.select_all)
        select_layout.addWidget(select_all_btn)

        deselect_all_btn = QPushButton("✗ Deselect All")
        deselect_all_btn.setStyleSheet(get_button_style())
        deselect_all_btn.clicked.connect(self.deselect_all)
        select_layout.addWidget(deselect_all_btn)

        select_layout.addStretch()
        layout.addLayout(select_layout)

        # Info label
        info = QLabel("Select commands to deploy, then click OK.")
        info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(info)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def select_all(self):
        """Select all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(True)

    def deselect_all(self):
        """Deselect all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(False)

    def get_selected_commands(self):
        """Get list of selected command names and their data"""
        selected = []
        for cmd_name, checkbox in self.checkboxes:
            if checkbox.isChecked():
                selected.append((cmd_name, self.commands[cmd_name]))
        return selected

    def open_bulk_add(self):
        """Open bulk edit dialog to add commands to library"""
        dialog = BulkCommandEditDialog(self.sources_file, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh_sources()

    def delete_selected(self):
        """Delete selected commands from config/sources/commands.json"""
        selected = self.get_selected_commands()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select commands to delete.")
            return

        cmd_names = [name for name, _ in selected]
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete {len(cmd_names)} command(s) from library?\n\n" + "\n".join(cmd_names),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                with open(self.sources_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                for name in cmd_names:
                    if name in data.get("commands", {}):
                        del data["commands"][name]

                with open(self.sources_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)

                QMessageBox.information(self, "Success", f"Deleted {len(cmd_names)} command(s) from library.")
                self.refresh_sources()
            except Exception as e:
                QMessageBox.critical(self, "Delete Error", f"Failed to delete commands:\n{str(e)}")

    def refresh_sources(self):
        """Reload commands from file and refresh table"""
        try:
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.commands = data.get("commands", {})

            # Rebuild table
            self.checkboxes = []
            self.table.setRowCount(len(self.commands))

            for row, (cmd_name, cmd_data) in enumerate(self.commands.items()):
                # Checkbox
                checkbox = QCheckBox()
                checkbox_widget = QWidget()
                checkbox_layout = QHBoxLayout(checkbox_widget)
                checkbox_layout.addWidget(checkbox)
                checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
                checkbox_layout.setContentsMargins(0, 0, 0, 0)
                self.table.setCellWidget(row, 0, checkbox_widget)
                self.checkboxes.append((cmd_name, checkbox))

                # Name
                name_item = QTableWidgetItem(cmd_name)
                name_item.setForeground(QColor(FG_PRIMARY))
                self.table.setItem(row, 1, name_item)

                # Description
                description = cmd_data.get("description", "No description")
                desc_item = QTableWidgetItem(description)
                desc_item.setForeground(QColor(FG_SECONDARY))
                self.table.setItem(row, 2, desc_item)

        except Exception as e:
            QMessageBox.critical(self, "Reload Error", f"Failed to reload commands:\n{str(e)}")


class BulkCommandEditDialog(QDialog):
    """Dialog for bulk editing command sources"""

    def __init__(self, sources_file, parent=None):
        super().__init__(parent)
        self.sources_file = sources_file
        self.setWindowTitle("Bulk Add Commands")
        self.setModal(True)
        self.setMinimumWidth(700)
        self.setMinimumHeight(500)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("Bulk Add Commands")
        header.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY}; font-size: {FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        # Instructions
        instructions = QLabel(
            "Paste command definitions in any format:\n\n"
            "<b>Format 1 (name,description,content):</b> quick-commit,Quick git commit,Create a git commit...\n"
            "<b>Format 2 (name: content):</b> quick-commit: Create a git commit...\n"
            "<b>Format 3 (JSON):</b> Direct JSON from commands.json\n\n"
            "Each command should be on a separate line or as valid JSON."
        )
        instructions.setWordWrap(True)
        instructions.setStyleSheet(f"color: {FG_SECONDARY}; background: {BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(instructions)

        # Text area for pasting
        input_label = QLabel("Paste command definitions:")
        input_label.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY};")
        layout.addWidget(input_label)

        self.input_text = QTextEdit()
        self.input_text.setPlaceholderText(
            "quick-commit,Quick git commit,Create a git commit with conventional format\n"
            "review-security: Review staged changes for security issues\n"
            "Or paste JSON: {\"quick-commit\": {\"name\": \"quick-commit\", ...}}"
        )
        self.input_text.setStyleSheet(get_text_edit_style())
        layout.addWidget(self.input_text)

        # Buttons
        button_layout = QHBoxLayout()

        parse_btn = QPushButton("🔄 Parse & Preview")
        parse_btn.setStyleSheet(get_button_style())
        parse_btn.clicked.connect(self.parse_and_preview)
        button_layout.addWidget(parse_btn)

        button_layout.addStretch()

        save_btn = QPushButton("💾 Save to Library")
        save_btn.setStyleSheet(get_button_style())
        save_btn.clicked.connect(self.save_to_library)
        button_layout.addWidget(save_btn)

        close_btn = QPushButton("✗ Close")
        close_btn.setStyleSheet(get_button_style())
        close_btn.clicked.connect(self.reject)
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

        # Preview area
        preview_label = QLabel("Preview (JSON):")
        preview_label.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY};")
        layout.addWidget(preview_label)

        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setStyleSheet(get_text_edit_style())
        layout.addWidget(self.preview_text)

    def parse_and_preview(self):
        """Parse input and show preview"""
        input_text = self.input_text.toPlainText().strip()
        if not input_text:
            QMessageBox.warning(self, "Empty Input", "Please paste command definitions first.")
            return

        try:
            parsed_commands = {}

            # Try JSON first
            if input_text.startswith("{"):
                data = json.loads(input_text)
                if "commands" in data:
                    parsed_commands = data["commands"]
                else:
                    parsed_commands = data
            else:
                # Parse line by line
                lines = input_text.split('\n')
                for line in lines:
                    line = line.strip()
                    if not line:
                        continue

                    # Format: name,description,content
                    if ',' in line:
                        parts = line.split(',', 2)
                        if len(parts) >= 2:
                            name = parts[0].strip()
                            description = parts[1].strip() if len(parts) > 1 else "No description"
                            content = parts[2].strip() if len(parts) > 2 else description
                            parsed_commands[name] = {
                                "name": name,
                                "description": description,
                                "content": content
                            }
                    # Format: name: content
                    elif ':' in line:
                        name, content = line.split(':', 1)
                        name = name.strip()
                        content = content.strip()
                        parsed_commands[name] = {
                            "name": name,
                            "description": f"Command: {name}",
                            "content": content
                        }

            if not parsed_commands:
                QMessageBox.warning(self, "Parse Error", "No valid commands found in input.")
                return

            # Show preview
            preview = json.dumps({"commands": parsed_commands}, indent=2)
            self.preview_text.setPlainText(preview)
            self.parsed_data = parsed_commands

        except Exception as e:
            QMessageBox.critical(self, "Parse Error", f"Failed to parse input:\n{str(e)}")

    def save_to_library(self):
        """Save parsed commands to library"""
        if not hasattr(self, 'parsed_data') or not self.parsed_data:
            QMessageBox.warning(self, "No Data", "Please parse commands first using 'Parse & Preview'.")
            return

        try:
            # Load existing
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if "commands" not in data:
                data["commands"] = {}

            # Merge
            added = 0
            for cmd_name, cmd_data in self.parsed_data.items():
                if cmd_name not in data["commands"]:
                    data["commands"][cmd_name] = cmd_data
                    added += 1

            # Save
            with open(self.sources_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)

            QMessageBox.information(self, "Success", f"Added {added} command(s) to library.")
            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save commands:\n{str(e)}")
