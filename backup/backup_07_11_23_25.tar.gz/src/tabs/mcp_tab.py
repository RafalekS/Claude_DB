"""
MCP Tab - Manage Claude Code MCP server configuration
"""

import json
import re
from pathlib import Path
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit,
    QLabel, QMessageBox, QListWidget, QSplitter, QComboBox, QListWidgetItem,
    QDialog, QFormLayout, QLineEdit, QTextEdit as QTextEditWidget, QDialogButtonBox,
    QFileDialog, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QCheckBox
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon, QColor
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import theme
from utils.terminal_utils import run_command_silent
from dialogs.mcp_tools_dialog import MCPToolsDialog


class KeyValueTableWidget(QWidget):
    """Reusable widget for editing key-value pairs"""

    def __init__(self, title="Key-Value Pairs", parent=None):
        super().__init__(parent)
        self.title = title
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # Header with add/remove buttons
        header_layout = QHBoxLayout()
        label = QLabel(self.title)
        label.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY};")
        header_layout.addWidget(label)
        header_layout.addStretch()

        add_btn = QPushButton("➕ Add Row")
        add_btn.setStyleSheet(theme.get_button_style())
        add_btn.clicked.connect(self.add_row)
        header_layout.addWidget(add_btn)

        remove_btn = QPushButton("➖ Remove Row")
        remove_btn.setStyleSheet(theme.get_button_style())
        remove_btn.clicked.connect(self.remove_row)
        header_layout.addWidget(remove_btn)

        layout.addLayout(header_layout)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Key", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {theme.BG_DARK};
                color: {theme.FG_PRIMARY};
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {theme.BG_MEDIUM};
                color: {theme.FG_PRIMARY};
                padding: 5px;
                border: 1px solid {theme.BG_LIGHT};
            }}
        """)
        layout.addWidget(self.table)

    def add_row(self, key="", value=""):
        """Add a new row to the table"""
        row_position = self.table.rowCount()
        self.table.insertRow(row_position)
        self.table.setItem(row_position, 0, QTableWidgetItem(key))
        self.table.setItem(row_position, 1, QTableWidgetItem(value))

    def remove_row(self):
        """Remove selected row"""
        current_row = self.table.currentRow()
        if current_row >= 0:
            self.table.removeRow(current_row)

    def set_data(self, data_dict):
        """Load data from dictionary"""
        self.table.setRowCount(0)
        for key, value in data_dict.items():
            self.add_row(key, str(value))

    def get_data(self):
        """Get data as dictionary"""
        data = {}
        for row in range(self.table.rowCount()):
            key_item = self.table.item(row, 0)
            value_item = self.table.item(row, 1)
            if key_item and value_item:
                key = key_item.text().strip()
                value = value_item.text().strip()
                if key:  # Only add non-empty keys
                    data[key] = value
        return data


class AddServerDialog(QDialog):
    """Dialog for adding/editing MCP servers"""

    def __init__(self, parent=None, edit_mode=False, server_name=None, server_config=None):
        super().__init__(parent)
        self.edit_mode = edit_mode
        self.original_server_name = server_name
        self.setWindowTitle("Edit MCP Server" if edit_mode else "Add MCP Server")
        self.setModal(True)
        self.setMinimumWidth(600)
        self.setMinimumHeight(500)
        self.init_ui(server_config)

    def init_ui(self, server_config=None):
        layout = QVBoxLayout(self)

        # Form layout
        form = QFormLayout()

        # Server Name
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g., my-server")
        self.name_input.setStyleSheet(theme.get_line_edit_style())
        if self.edit_mode:
            self.name_input.setText(self.original_server_name)
            self.name_input.setReadOnly(True)
            self.name_input.setToolTip("Server name cannot be changed when editing")
        form.addRow("Server Name*:", self.name_input)

        # Server Type (http vs command/stdio)
        type_layout = QHBoxLayout()
        self.type_combo = QComboBox()
        self.type_combo.addItems(["Command (stdio)", "HTTP", "SSE"])
        self.type_combo.setStyleSheet(theme.get_combo_style())
        self.type_combo.currentTextChanged.connect(self.on_type_changed)
        type_layout.addWidget(self.type_combo)

        type_info = QLabel("💡 Command = local process, HTTP/SSE = remote server")
        type_info.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px;")
        type_layout.addWidget(type_info)
        type_layout.addStretch()
        form.addRow("Server Type*:", type_layout)

        # Command Template (for stdio type) - NEW
        self.template_label = QLabel("Command Template:")
        template_layout = QHBoxLayout()
        self.template_combo = QComboBox()
        self.template_combo.addItems(["Custom", "npx", "uvx"])
        self.template_combo.setStyleSheet(theme.get_combo_style())
        self.template_combo.currentTextChanged.connect(self.on_template_changed)
        template_layout.addWidget(self.template_combo)

        template_info = QLabel("💡 npx = cmd /k npx -y • uvx = cmd /k uvx")
        template_info.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px;")
        template_layout.addWidget(template_info)
        template_layout.addStretch()
        form.addRow(self.template_label, template_layout)

        # Command (for stdio type)
        self.command_label = QLabel("Command*:")
        self.command_input = QLineEdit()
        self.command_input.setPlaceholderText("e.g., npx @example/server or C:\\path\\to\\python.exe")
        self.command_input.setStyleSheet(theme.get_line_edit_style())
        form.addRow(self.command_label, self.command_input)

        # Arguments (for stdio type)
        self.args_label = QLabel("Arguments:")
        self.args_input = QTextEdit()
        self.args_input.setPlaceholderText("One argument per line, e.g.:\nC:\\path\\to\\script.py\n--verbose\n--port 3000")
        self.args_input.setStyleSheet(theme.get_text_edit_style())
        self.args_input.setMaximumHeight(80)
        form.addRow(self.args_label, self.args_input)

        # URL (for HTTP/SSE type)
        self.url_label = QLabel("URL*:")
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("e.g., http://localhost:3000/mcp or https://api.example.com/mcp")
        self.url_input.setStyleSheet(theme.get_line_edit_style())
        form.addRow(self.url_label, self.url_input)

        layout.addLayout(form)

        # Environment Variables (key-value table)
        self.env_table = KeyValueTableWidget("Environment Variables", self)
        layout.addWidget(self.env_table)

        # Headers (key-value table, HTTP only)
        self.headers_table = KeyValueTableWidget("Headers (HTTP/SSE only)", self)
        layout.addWidget(self.headers_table)

        # Info label
        info = QLabel("* Required fields. Environment and Headers are optional.")
        info.setStyleSheet("color: #999; font-size: 11px;")
        layout.addWidget(info)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

        # Load existing config if editing
        if server_config:
            self.load_config(server_config)
        else:
            # Default to Command type
            self.on_type_changed("Command (stdio)")

    def load_config(self, config):
        """Load existing server configuration into form"""
        # Determine server type
        if "type" in config:
            server_type = config["type"]
            if server_type == "http":
                self.type_combo.setCurrentText("HTTP")
            elif server_type == "sse":
                self.type_combo.setCurrentText("SSE")
        else:
            # No type = command/stdio
            self.type_combo.setCurrentText("Command (stdio)")

        # Load command
        if "command" in config:
            self.command_input.setText(config["command"])

        # Load args
        if "args" in config:
            args_list = config["args"]
            if isinstance(args_list, list):
                self.args_input.setPlainText("\n".join(args_list))

        # Load URL
        if "url" in config:
            self.url_input.setText(config["url"])

        # Load environment
        if "env" in config and isinstance(config["env"], dict):
            self.env_table.set_data(config["env"])

        # Load headers
        if "headers" in config and isinstance(config["headers"], dict):
            self.headers_table.set_data(config["headers"])

    def on_type_changed(self, server_type):
        """Update UI based on server type"""
        is_command = "Command" in server_type
        is_http = "HTTP" in server_type or "SSE" in server_type

        # Show/hide fields based on type
        self.template_label.setVisible(is_command)
        self.template_combo.setVisible(is_command)
        self.command_label.setVisible(is_command)
        self.command_input.setVisible(is_command)
        self.args_label.setVisible(is_command)
        self.args_input.setVisible(is_command)

        self.url_label.setVisible(is_http)
        self.url_input.setVisible(is_http)

        self.headers_table.setVisible(is_http)

    def on_template_changed(self, template):
        """Update command and args based on template selection"""
        if template == "npx":
            # npx template: cmd /k npx -y <package>
            self.command_input.setText("cmd")
            self.command_input.setPlaceholderText("Command is set to 'cmd'")
            # Pre-fill args with /k npx -y
            self.args_input.setPlaceholderText("Template pre-filled. Add package name on next line:\n/k\nnpx\n-y\n@modelcontextprotocol/server-filesystem")
            self.args_input.setPlainText("/k\nnpx\n-y\n")
            # Move cursor to end for user to add package name
            self.args_input.moveCursor(self.args_input.textCursor().MoveOperation.End)
        elif template == "uvx":
            # uvx template: uvx -y <package> (no cmd wrapper)
            self.command_input.setText("uvx")
            self.command_input.setPlaceholderText("Command is set to 'uvx'")
            # Pre-fill args with -y
            self.args_input.setPlaceholderText("Template pre-filled. Add package name on next line:\n-y\nmcp-server-package")
            self.args_input.setPlainText("-y\n")
            # Move cursor to end for user to add package name
            self.args_input.moveCursor(self.args_input.textCursor().MoveOperation.End)
        else:  # Custom
            # Reset to custom mode
            self.command_input.setPlaceholderText("e.g., npx @example/server or C:\\path\\to\\python.exe")
            self.args_input.setPlaceholderText("One argument per line, e.g.:\nC:\\path\\to\\script.py\n--verbose\n--port 3000")
            # Don't clear fields when switching to custom

    def validate_and_accept(self):
        """Validate inputs before accepting"""
        if not self.name_input.text().strip():
            QMessageBox.warning(self, "Validation Error", "Server name is required!")
            return

        server_type = self.type_combo.currentText()
        is_command = "Command" in server_type
        is_http = "HTTP" in server_type or "SSE" in server_type

        if is_command and not self.command_input.text().strip():
            QMessageBox.warning(self, "Validation Error", "Command is required for Command type servers!")
            return

        if is_http and not self.url_input.text().strip():
            QMessageBox.warning(self, "Validation Error", "URL is required for HTTP/SSE type servers!")
            return

        self.accept()

    def get_server_config(self):
        """Get the server configuration from form inputs"""
        config = {}
        server_type = self.type_combo.currentText()

        if "Command" in server_type:
            # Command/stdio type - no "type" field in config
            config["command"] = self.command_input.text().strip()

            # Parse args (one per line)
            args_text = self.args_input.toPlainText().strip()
            if args_text:
                config["args"] = [arg.strip() for arg in args_text.split('\n') if arg.strip()]
        else:
            # HTTP or SSE type
            if "HTTP" in server_type:
                config["type"] = "http"
            elif "SSE" in server_type:
                config["type"] = "sse"

            config["url"] = self.url_input.text().strip()

            # Add headers if any
            headers = self.headers_table.get_data()
            if headers:
                config["headers"] = headers

        # Add environment if any
        env = self.env_table.get_data()
        if env:
            config["env"] = env

        return self.name_input.text().strip(), config


class CustomRenameDialog(QDialog):
    """Dialog for custom renaming of conflicting servers"""

    def __init__(self, conflicts, existing_names, parent=None):
        super().__init__(parent)
        self.conflicts = conflicts  # List of conflicting server names
        self.existing_names = existing_names  # Set of all existing names to avoid
        self.rename_map = {}  # Maps old_name -> new_name
        self.setWindowTitle("Rename Conflicting Servers")
        self.setModal(True)
        self.setMinimumWidth(600)
        self.setMinimumHeight(400)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("The following servers conflict with existing names.\nPlease provide new names:")
        header.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY}; font-size: {theme.FONT_SIZE_NORMAL}px;")
        layout.addWidget(header)

        # Table for conflicts
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Conflicting Name", "New Name"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {theme.BG_DARK};
                color: {theme.FG_PRIMARY};
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {theme.BG_MEDIUM};
                color: {theme.FG_PRIMARY};
                padding: 5px;
                border: 1px solid {theme.BG_LIGHT};
            }}
        """)

        # Populate table
        self.name_inputs = {}
        self.table.setRowCount(len(self.conflicts))
        for row, conflict_name in enumerate(self.conflicts):
            # Conflicting name (read-only)
            name_item = QTableWidgetItem(conflict_name)
            name_item.setFlags(name_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.table.setItem(row, 0, name_item)

            # New name input
            new_name_input = QLineEdit()
            new_name_input.setPlaceholderText(f"{conflict_name}-renamed")
            new_name_input.setStyleSheet(theme.get_line_edit_style())
            self.table.setCellWidget(row, 1, new_name_input)
            self.name_inputs[conflict_name] = new_name_input

        layout.addWidget(self.table)

        # Info label
        info = QLabel("New names must be unique and not conflict with existing servers.")
        info.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px;")
        layout.addWidget(info)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def validate_and_accept(self):
        """Validate new names and accept"""
        self.rename_map = {}
        new_names_used = set()

        for conflict_name, input_widget in self.name_inputs.items():
            new_name = input_widget.text().strip()

            if not new_name:
                QMessageBox.warning(self, "Empty Name", f"Please provide a new name for '{conflict_name}'")
                return

            if new_name in self.existing_names:
                QMessageBox.warning(self, "Name Exists", f"Name '{new_name}' already exists. Please choose a different name.")
                return

            if new_name in new_names_used:
                QMessageBox.warning(self, "Duplicate Name", f"Name '{new_name}' is used multiple times. Each new name must be unique.")
                return

            new_names_used.add(new_name)
            self.rename_map[conflict_name] = new_name

        self.accept()

    def get_rename_map(self):
        """Get the rename mapping"""
        return self.rename_map


class MCPSourcesDialog(QDialog):
    """Dialog for adding MCP servers from config/sources/mcp_servers.json"""

    def __init__(self, sources_file, parent=None):
        super().__init__(parent)
        self.sources_file = sources_file
        self.selected_servers = []
        self.setWindowTitle("MCP Sources Library")
        self.setModal(True)
        self.setMinimumWidth(900)
        self.setMinimumHeight(700)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("MCP Sources Library - Manage and deploy MCP servers")
        header.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY}; font-size: {theme.FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        # File info
        file_info = QLabel(f"Source File: {self.sources_file}")
        file_info.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px;")
        layout.addWidget(file_info)

        # Load sources
        try:
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                sources_data = json.load(f)
            self.servers = sources_data.get("mcpServers", {})
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load MCP sources:\n{str(e)}")
            self.servers = {}

        # Table with checkboxes
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Select", "Name", "Command"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {theme.BG_DARK};
                color: {theme.FG_PRIMARY};
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {theme.BG_MEDIUM};
                color: {theme.FG_PRIMARY};
                padding: 5px;
                border: 1px solid {theme.BG_LIGHT};
            }}
        """)

        # Populate table
        self.checkboxes = []
        self.table.setRowCount(len(self.servers))
        for row, (server_name, server_config) in enumerate(self.servers.items()):
            # Checkbox
            checkbox = QCheckBox()
            checkbox_widget = QWidget()
            checkbox_layout = QHBoxLayout(checkbox_widget)
            checkbox_layout.addWidget(checkbox)
            checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            checkbox_layout.setContentsMargins(0, 0, 0, 0)
            self.table.setCellWidget(row, 0, checkbox_widget)
            self.checkboxes.append((server_name, checkbox))

            # Name
            name_item = QTableWidgetItem(server_name)
            self.table.setItem(row, 1, name_item)

            # Command (formatted)
            command = server_config.get("command", "")
            args = server_config.get("args", [])
            full_command = command
            if args:
                full_command += " " + " ".join(args)
            command_item = QTableWidgetItem(full_command)
            self.table.setItem(row, 2, command_item)

        layout.addWidget(self.table)

        # Management buttons
        manage_layout = QHBoxLayout()

        bulk_add_btn = QPushButton("➕ Bulk Add Servers")
        bulk_add_btn.setStyleSheet(theme.get_button_style())
        bulk_add_btn.setToolTip("Open bulk paste dialog to add multiple servers at once")
        bulk_add_btn.clicked.connect(self.open_bulk_add)
        manage_layout.addWidget(bulk_add_btn)

        delete_btn = QPushButton("🗑️ Delete Selected")
        delete_btn.setStyleSheet(theme.get_button_style())
        delete_btn.setToolTip("Delete selected servers from sources library")
        delete_btn.clicked.connect(self.delete_selected)
        manage_layout.addWidget(delete_btn)

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setStyleSheet(theme.get_button_style())
        refresh_btn.setToolTip("Reload servers from file")
        refresh_btn.clicked.connect(self.refresh_sources)
        manage_layout.addWidget(refresh_btn)

        manage_layout.addStretch()
        layout.addLayout(manage_layout)

        # Select All / Deselect All buttons
        select_layout = QHBoxLayout()
        select_all_btn = QPushButton("✓ Select All")
        select_all_btn.setStyleSheet(theme.get_button_style())
        select_all_btn.clicked.connect(self.select_all)
        select_layout.addWidget(select_all_btn)

        deselect_all_btn = QPushButton("✗ Deselect All")
        deselect_all_btn.setStyleSheet(theme.get_button_style())
        deselect_all_btn.clicked.connect(self.deselect_all)
        select_layout.addWidget(deselect_all_btn)

        select_layout.addStretch()
        layout.addLayout(select_layout)

        # Info label
        info = QLabel("Select servers to add, then click OK. Conflicts will be resolved.")
        info.setStyleSheet(f"color: {theme.FG_SECONDARY}; font-size: {theme.FONT_SIZE_SMALL}px;")
        layout.addWidget(info)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def select_all(self):
        """Select all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(True)

    def deselect_all(self):
        """Deselect all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(False)

    def get_selected_servers(self):
        """Get list of selected server names and their configs"""
        selected = []
        for server_name, checkbox in self.checkboxes:
            if checkbox.isChecked():
                selected.append((server_name, self.servers[server_name]))
        return selected

    def open_bulk_add(self):
        """Open bulk edit dialog to add servers to library"""
        dialog = BulkEditDialog(self.sources_file, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh_sources()  # Reload table after adding

    def delete_selected(self):
        """Delete selected servers from config/sources/mcp_servers.json"""
        selected = self.get_selected_servers()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select servers to delete.")
            return

        # Confirm deletion
        server_names = [name for name, _ in selected]
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete {len(server_names)} server(s) from library?\n\n" + "\n".join(server_names),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Load, remove, save
                with open(self.sources_file, 'r') as f:
                    data = json.load(f)

                for name in server_names:
                    if name in data.get("mcpServers", {}):
                        del data["mcpServers"][name]

                with open(self.sources_file, 'w') as f:
                    json.dump(data, f, indent=2)

                QMessageBox.information(self, "Success", f"Deleted {len(server_names)} server(s) from library.")
                self.refresh_sources()
            except Exception as e:
                QMessageBox.critical(self, "Delete Error", f"Failed to delete servers:\n{str(e)}")

    def refresh_sources(self):
        """Reload servers from file and refresh table"""
        try:
            with open(self.sources_file, 'r') as f:
                data = json.load(f)
            self.servers = data.get("mcpServers", {})

            # Rebuild table
            self.checkboxes = []
            self.table.setRowCount(len(self.servers))

            for row, (server_name, server_config) in enumerate(self.servers.items()):
                # Checkbox
                checkbox = QCheckBox()
                checkbox_widget = QWidget()
                checkbox_layout = QHBoxLayout(checkbox_widget)
                checkbox_layout.addWidget(checkbox)
                checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
                checkbox_layout.setContentsMargins(0, 0, 0, 0)
                self.table.setCellWidget(row, 0, checkbox_widget)
                self.checkboxes.append((server_name, checkbox))

                # Server name
                name_item = QTableWidgetItem(server_name)
                name_item.setForeground(QColor(theme.FG_PRIMARY))
                self.table.setItem(row, 1, name_item)

                # Full command
                command = server_config.get("command", "")
                args = " ".join(server_config.get("args", []))
                full_command = f"{command} {args}"
                command_item = QTableWidgetItem(full_command)
                command_item.setForeground(QColor(theme.FG_SECONDARY))
                self.table.setItem(row, 2, command_item)

        except Exception as e:
            QMessageBox.critical(self, "Reload Error", f"Failed to reload servers:\n{str(e)}")


class BulkEditDialog(QDialog):
    """Dialog for bulk editing MCP sources (paste & convert)"""

    def __init__(self, sources_file, parent=None):
        super().__init__(parent)
        self.sources_file = sources_file
        self.setWindowTitle("Bulk Edit MCP Sources")
        self.setModal(True)
        self.setMinimumWidth(700)
        self.setMinimumHeight(500)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("Bulk Add MCP Servers")
        header.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY}; font-size: {theme.FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        # Instructions
        instructions = QLabel(
            "Paste server definitions in any format:\n\n"
            "<b>Format 1 (explicit):</b> name,command @package\n"
            "<b>Format 2 (auto-name):</b> command @package\n"
            "<b>Format 3 (JSON):</b> Direct JSON from .mcp.json\n\n"
            "Supported: npx, uvx, .bat, .cmd, .exe, python -m, pwsh -File\n\n"
            "Examples:\n"
            "npx @j0kz/api-designer-mcp\n"
            "uvx @j0kz/doc-generator-mcp\n"
            "Or paste JSON: {\"server\": {\"command\": \"cmd\", \"args\": [...]}}"
        )
        instructions.setWordWrap(True)
        instructions.setStyleSheet(f"color: {theme.FG_SECONDARY}; background: {theme.BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {theme.FONT_SIZE_SMALL}px;")
        layout.addWidget(instructions)

        # Text area for pasting
        input_label = QLabel("Paste server definitions:")
        input_label.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY};")
        layout.addWidget(input_label)

        self.input_text = QTextEdit()
        self.input_text.setPlaceholderText("npx @j0kz/api-designer-mcp\nnpx @j0kz/db-schema-mcp\npython -m scanner-mcp.py\nuvx @j0kz/doc-generator-mcp")
        self.input_text.setStyleSheet(theme.get_text_edit_style())
        layout.addWidget(self.input_text)

        # Buttons
        button_layout = QHBoxLayout()

        parse_btn = QPushButton("🔄 Parse & Preview")
        parse_btn.setStyleSheet(theme.get_button_style())
        parse_btn.clicked.connect(self.parse_and_preview)
        button_layout.addWidget(parse_btn)

        button_layout.addStretch()

        save_btn = QPushButton("💾 Save to Sources")
        save_btn.setStyleSheet(theme.get_button_style())
        save_btn.clicked.connect(self.save_to_sources)
        button_layout.addWidget(save_btn)

        close_btn = QPushButton("✗ Close")
        close_btn.setStyleSheet(theme.get_button_style())
        close_btn.clicked.connect(self.reject)
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

        # Preview area
        preview_label = QLabel("Preview (JSON):")
        preview_label.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY};")
        layout.addWidget(preview_label)

        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setStyleSheet(theme.get_text_edit_style())
        layout.addWidget(self.preview_text)

    def extract_name_from_command(self, command_str):
        """Extract server name from command string"""
        if command_str.startswith("npx ") or command_str.startswith("uvx "):
            # Extract from package name: npx @j0kz/api-designer-mcp → api-designer
            package = command_str.split(None, 1)[1] if ' ' in command_str else ""
            # Remove @scope/ if present
            if package.startswith("@"):
                package = package.split('/', 1)[1] if '/' in package else package
            # Remove -mcp suffix if present
            if package.endswith("-mcp"):
                package = package[:-4]
            # Use package name as server name
            return package if package else None
        elif command_str.startswith("python -m "):
            # Extract from module: python -m scanner-mcp.py → scanner-mcp
            module = command_str.replace("python -m ", "").strip()
            # Remove .py extension if present
            if module.endswith(".py"):
                module = module[:-3]
            return module if module else None
        elif command_str.startswith("pwsh -File "):
            # Extract from script: pwsh -File C:\path\to\script.ps1 → script
            script = command_str.replace("pwsh -File ", "").strip()
            # Get filename without path and extension
            from pathlib import Path
            script_name = Path(script).stem
            return script_name if script_name else None
        elif command_str.endswith(".bat") or command_str.endswith(".cmd") or command_str.endswith(".exe"):
            # Extract from executable: C:\path\to\tool.exe → tool
            from pathlib import Path
            exec_name = Path(command_str).stem
            return exec_name if exec_name else None
        return None

    def parse_line(self, line):
        """Parse a single line into server name and config
        Supports two formats:
        1. name,command @package
        2. command @package (auto-generates name)
        """
        line = line.strip()
        if not line:
            return None, None

        # Check if line has explicit name (contains comma)
        if ',' in line:
            parts = line.split(',', 1)
            if len(parts) != 2:
                return None, None
            server_name = parts[0].strip()
            command_str = parts[1].strip()
        else:
            # Auto-generate name from command
            command_str = line
            server_name = self.extract_name_from_command(command_str)
            if not server_name:
                return None, None

        # Detect command type and construct config
        config = {}

        if command_str.startswith("npx "):
            # npx template: cmd /k npx -y @package
            package = command_str.replace("npx ", "").strip()
            config["command"] = "cmd"
            config["args"] = ["/k", "npx", "-y", package]
        elif command_str.startswith("uvx "):
            # uvx template: uvx -y @package
            package = command_str.replace("uvx ", "").strip()
            config["command"] = "uvx"
            config["args"] = ["-y", package]
        elif command_str.endswith(".bat"):
            # .bat file
            config["command"] = command_str
            config["args"] = []
        elif command_str.endswith(".cmd"):
            # .cmd file
            config["command"] = command_str
            config["args"] = []
        elif command_str.endswith(".exe"):
            # .exe file
            config["command"] = command_str
            config["args"] = []
        elif command_str.startswith("python -m "):
            # python -m module
            module = command_str.replace("python -m ", "").strip()
            config["command"] = "python"
            config["args"] = ["-m", module]
        elif command_str.startswith("pwsh -File "):
            # pwsh -File script.ps1
            script = command_str.replace("pwsh -File ", "").strip()
            config["command"] = "pwsh"
            config["args"] = ["-File", script]
        else:
            # Unknown format - return None
            return None, None

        return server_name, config

    def parse_and_preview(self):
        """Parse input text and show preview"""
        input_text = self.input_text.toPlainText().strip()

        parsed_servers = {}
        errors = []

        # Try to detect if input is JSON format
        if input_text.startswith('{') or input_text.startswith('"'):
            try:
                # Try to parse as JSON
                # Handle both full format {"mcpServers": {...}} and partial format {"server-name": {...}}
                data = json.loads('{' + input_text + '}' if not input_text.startswith('{') else input_text)

                # Check if it's the full format with mcpServers wrapper
                if "mcpServers" in data:
                    parsed_servers = data["mcpServers"]
                else:
                    # Assume it's direct server definitions
                    parsed_servers = data

                QMessageBox.information(self, "JSON Detected", f"Successfully parsed JSON format with {len(parsed_servers)} server(s).")
            except json.JSONDecodeError as e:
                QMessageBox.warning(self, "JSON Parse Error", f"Failed to parse as JSON:\n{str(e)}\n\nTrying line-by-line format...")
                # Fall back to line-by-line parsing
                parsed_servers = {}
                errors = []
                lines = input_text.split('\n')
                for i, line in enumerate(lines, 1):
                    server_name, config = self.parse_line(line)
                    if server_name and config:
                        parsed_servers[server_name] = config
                    elif line.strip():
                        errors.append(f"Line {i}: Failed to parse - {line}")
        else:
            # Line-by-line format
            lines = input_text.split('\n')
            for i, line in enumerate(lines, 1):
                server_name, config = self.parse_line(line)
                if server_name and config:
                    parsed_servers[server_name] = config
                elif line.strip():  # Non-empty line that failed to parse
                    errors.append(f"Line {i}: Failed to parse - {line}")

        # Show preview
        preview_data = {"mcpServers": parsed_servers}
        preview_json = json.dumps(preview_data, indent=2)
        self.preview_text.setPlainText(preview_json)

        # Show errors if any
        if errors:
            error_msg = "\n".join(errors)
            QMessageBox.warning(self, "Parse Errors", f"Some lines could not be parsed:\n\n{error_msg}")

    def save_to_sources(self):
        """Save parsed servers to config/sources/mcp_servers.json with conflict detection"""
        # Parse input (same as parse_and_preview but without the preview display)
        input_text = self.input_text.toPlainText().strip()

        parsed_servers = {}

        # Try to detect if input is JSON format
        if input_text.startswith('{') or input_text.startswith('"'):
            try:
                data = json.loads('{' + input_text + '}' if not input_text.startswith('{') else input_text)
                if "mcpServers" in data:
                    parsed_servers = data["mcpServers"]
                else:
                    parsed_servers = data
            except json.JSONDecodeError:
                # Fall back to line-by-line parsing
                lines = input_text.split('\n')
                for line in lines:
                    server_name, config = self.parse_line(line)
                    if server_name and config:
                        parsed_servers[server_name] = config
        else:
            # Line-by-line format
            lines = input_text.split('\n')
            for line in lines:
                server_name, config = self.parse_line(line)
                if server_name and config:
                    parsed_servers[server_name] = config

        if not parsed_servers:
            QMessageBox.warning(self, "No Servers", "No valid servers to save. Please check your input format.")
            return

        # Load existing sources
        try:
            if Path(self.sources_file).exists():
                with open(self.sources_file, 'r', encoding='utf-8') as f:
                    sources_data = json.load(f)
            else:
                sources_data = {"mcpServers": {}}

            if "mcpServers" not in sources_data:
                sources_data["mcpServers"] = {}

            # Check for conflicts
            conflicts = []
            for server_name in parsed_servers.keys():
                if server_name in sources_data["mcpServers"]:
                    conflicts.append(server_name)

            # Handle conflicts if any
            if conflicts:
                conflict_msg = f"The following servers already exist in sources:\n\n" + "\n".join(conflicts) + "\n\nWhat would you like to do?"

                # Create custom dialog for conflict resolution
                conflict_dialog = QMessageBox(self)
                conflict_dialog.setWindowTitle("Server Conflicts")
                conflict_dialog.setText(conflict_msg)
                conflict_dialog.setIcon(QMessageBox.Icon.Warning)

                overwrite_btn = conflict_dialog.addButton("Overwrite All", QMessageBox.ButtonRole.AcceptRole)
                rename_btn = conflict_dialog.addButton("Rename All", QMessageBox.ButtonRole.ActionRole)
                skip_btn = conflict_dialog.addButton("Skip Conflicts", QMessageBox.ButtonRole.RejectRole)
                cancel_btn = conflict_dialog.addButton("Cancel", QMessageBox.ButtonRole.DestructiveRole)

                conflict_dialog.exec()
                clicked_button = conflict_dialog.clickedButton()

                if clicked_button == cancel_btn:
                    return
                elif clicked_button == overwrite_btn:
                    # Overwrite all conflicts
                    sources_data["mcpServers"].update(parsed_servers)
                elif clicked_button == rename_btn:
                    # Open custom rename dialog
                    existing_names = set(sources_data["mcpServers"].keys())
                    rename_dialog = CustomRenameDialog(conflicts, existing_names, self)
                    if rename_dialog.exec() == QDialog.DialogCode.Accepted:
                        rename_map = rename_dialog.rename_map
                        # Add servers with custom names
                        for server_name, server_config in parsed_servers.items():
                            if server_name in rename_map:
                                sources_data["mcpServers"][rename_map[server_name]] = server_config
                            else:
                                sources_data["mcpServers"][server_name] = server_config
                    else:
                        return  # User cancelled rename
                elif clicked_button == skip_btn:
                    # Skip conflicts - only add new servers
                    for server_name, server_config in parsed_servers.items():
                        if server_name not in sources_data["mcpServers"]:
                            sources_data["mcpServers"][server_name] = server_config
            else:
                # No conflicts - add all
                sources_data["mcpServers"].update(parsed_servers)

            # Save back
            with open(self.sources_file, 'w', encoding='utf-8') as f:
                json.dump(sources_data, f, indent=2)

            QMessageBox.information(
                self,
                "Saved",
                f"Processed {len(parsed_servers)} server(s) to {self.sources_file}"
            )
            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save:\n{str(e)}")


class MCPTab(QWidget):
    """Tab for managing MCP servers"""

    def __init__(self, config_manager, backup_manager, scope, project_context=None):
        super().__init__()
        self.config_manager = config_manager
        self.backup_manager = backup_manager
        self.scope = scope
        self.project_context = project_context
        self.server_health = {}  # Store health status from claude mcp list

        # Validate parameters
        if scope in ("project", "local") and not project_context:
            raise ValueError("project_context is required when scope='project' or 'local'")

        self.init_ui()

        # Connect to project changes if project or local scope
        if self.scope in ("project", "local") and self.project_context:
            self.project_context.project_changed.connect(self.on_project_changed)

    def init_ui(self):
        """Initialize the UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)

        # Header
        header_layout = QHBoxLayout()
        header_layout.setSpacing(5)

        scope_label = "User" if self.scope == "user" else "Local" if self.scope == "local" else "Project"
        header = QLabel(f"MCP Servers ({scope_label})")
        header.setStyleSheet(f"font-size: {theme.FONT_SIZE_LARGE}px; font-weight: bold; color: {theme.ACCENT_PRIMARY};")

        header_layout.addWidget(header)
        header_layout.addStretch()

        layout.addLayout(header_layout)

        # Single MCP editor for current scope
        editor_widget = self.create_mcp_editor()
        layout.addWidget(editor_widget, 1)

        # Info section with recommended servers
        info_label = QLabel(
            "💡 <b>MCP Quick Commands:</b> "
            "<code>claude mcp list</code> (view servers) • "
            "<code>claude mcp add &lt;name&gt; &lt;cmd&gt;</code> (add) • "
            "<code>claude mcp remove &lt;name&gt;</code> (remove) • "
            "<code>claude mcp add-from-claude-desktop</code> (import)"
            "<br><b>Recommended Servers:</b> "
            "Filesystem: <code>npx @modelcontextprotocol/server-filesystem</code> • "
            "GitHub: <code>npx @modelcontextprotocol/server-github</code> (needs GITHUB_TOKEN) • "
            "Puppeteer: <code>npx @modelcontextprotocol/server-puppeteer</code> • "
            "Memory: <code>npx @modelcontextprotocol/server-memory</code>"
            "<br><b>Scopes:</b> "
            "User (~/.claude.json) affects all projects • "
            "Local (~/.claude/.mcp.json) affects current user • "
            "Project (./.mcp.json) is shared with team • "
            "Use <code>-s user/project</code> flag to specify scope • "
            "Health status checked automatically"
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {theme.FG_SECONDARY}; background: {theme.BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {theme.FONT_SIZE_SMALL}px;")
        layout.addWidget(info_label)

    def create_mcp_editor(self):
        """Create MCP editor for the current scope"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # File path label
        file_path = self.get_scope_file_path()
        self.path_label = QLabel(f"File: {file_path}")
        self.path_label.setStyleSheet(f"font-size: {theme.FONT_SIZE_SMALL}px; color: {theme.FG_SECONDARY};")
        layout.addWidget(self.path_label)

        # Store config and health data
        self.config = {"mcpServers": {}}
        self.health = {}

        # Splitter with server list and editor
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left side - Server list
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)

        # Search box
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search servers...")
        self.search_box.textChanged.connect(self.filter_servers)
        self.search_box.setStyleSheet(theme.get_line_edit_style())
        left_layout.addWidget(self.search_box)

        list_label = QLabel("Servers:")
        list_label.setStyleSheet(f"font-weight: bold; color: {theme.FG_PRIMARY};")
        left_layout.addWidget(list_label)

        self.server_list = QListWidget()
        self.server_list.setStyleSheet(f"""
            QListWidget {{
                background-color: {theme.BG_DARK};
                color: {theme.FG_PRIMARY};
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 3px;
                padding: 5px;
                font-size: {theme.FONT_SIZE_NORMAL}px;
            }}
            QListWidget::item {{
                padding: 5px;
            }}
            QListWidget::item:selected {{
                background-color: {theme.ACCENT_PRIMARY};
                color: {theme.BG_DARK};
            }}
        """)
        self.server_list.itemClicked.connect(self.on_server_selected)
        left_layout.addWidget(self.server_list)

        # Buttons - matching pattern from other tabs
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(5)

        add_btn = QPushButton("➕ Add")
        add_btn.setToolTip("Add a new MCP server")
        edit_btn = QPushButton("✏️ Edit")
        edit_btn.setToolTip("Edit selected MCP server")
        remove_btn = QPushButton("🗑️ Delete")
        remove_btn.setToolTip("Remove selected MCP server")
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setToolTip("Reload MCP configuration")
        library_btn = QPushButton("📚 MCP Library")
        library_btn.setToolTip("Browse and deploy servers from library")
        tools_btn = QPushButton("🔧 Tools")
        tools_btn.setToolTip("List tools from selected server")

        for btn in [add_btn, edit_btn, remove_btn, refresh_btn, library_btn, tools_btn]:
            btn.setStyleSheet(theme.get_button_style())

        add_btn.clicked.connect(self.add_server)
        edit_btn.clicked.connect(self.edit_server)
        remove_btn.clicked.connect(self.remove_server)
        refresh_btn.clicked.connect(self.load_mcp_config)
        library_btn.clicked.connect(self.open_mcp_sources)
        tools_btn.clicked.connect(self.list_server_tools)

        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(remove_btn)
        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(library_btn)
        btn_layout.addWidget(tools_btn)
        left_layout.addLayout(btn_layout)

        splitter.addWidget(left_panel)

        # Right side - JSON editor
        editor_panel = QWidget()
        editor_layout = QVBoxLayout(editor_panel)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        editor_layout.setSpacing(5)

        # Editor header with buttons
        editor_header = QHBoxLayout()
        editor_header.setSpacing(5)

        self.server_name_label = QLabel("No server selected")
        self.server_name_label.setStyleSheet(theme.get_label_style("normal", "secondary"))

        save_btn = QPushButton("💾 Save")
        save_btn.setToolTip("Save MCP configuration")
        backup_btn = QPushButton("📦 Backup & Save")
        backup_btn.setToolTip("Create backup and save")
        revert_btn = QPushButton("Revert")
        revert_btn.setToolTip("Revert to saved version")

        for btn in [save_btn, backup_btn, revert_btn]:
            btn.setStyleSheet(theme.get_button_style())

        save_btn.clicked.connect(self.save_mcp_config)
        backup_btn.clicked.connect(self.backup_and_save)
        revert_btn.clicked.connect(self.revert_mcp_config)

        editor_header.addWidget(self.server_name_label)
        editor_header.addStretch()
        editor_header.addWidget(save_btn)
        editor_header.addWidget(backup_btn)
        editor_header.addWidget(revert_btn)

        editor_layout.addLayout(editor_header)

        self.editor = QTextEdit()
        self.editor.setStyleSheet(f"""
            QTextEdit {{
                background-color: {theme.BG_DARK};
                color: {theme.FG_PRIMARY};
                border: 1px solid {theme.BG_LIGHT};
                border-radius: 3px;
                padding: 8px;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: {theme.FONT_SIZE_NORMAL}px;
            }}
        """)
        editor_layout.addWidget(self.editor)

        splitter.addWidget(editor_panel)
        splitter.setSizes([300, 700])
        layout.addWidget(splitter, 1)

        # Load initial data
        self.load_mcp_config()

        return widget


    def get_scope_file_path(self):
        """Get file path for the current scope"""
        if self.scope == "user":
            return self.config_manager.get_mcp_file_path("user")
        elif self.scope == "local":
            if not self.project_context or not self.project_context.has_project():
                return Path.home() / ".claude" / ".mcp.json"
            return self.project_context.get_project() / ".claude" / ".mcp.json"
        else:  # project
            if not self.project_context or not self.project_context.has_project():
                return None
            return self.project_context.get_project() / ".mcp.json"

    def on_project_changed(self, project_path: Path):
        """Handle project context change"""
        # Update path label
        file_path = self.get_scope_file_path()
        if file_path:
            self.path_label.setText(f"File: {file_path}")
        # Reload MCP config from new project
        self.load_mcp_config()

    def get_scope_display_name(self):
        """Get display name for current scope"""
        return {
            "user": "User",
            "local": "Local",
            "project": "Project"
        }.get(self.scope, "Unknown")

    def update_server_list(self):
        """Update the server list from config with health status icons"""
        self.server_list.clear()
        if "mcpServers" in self.config:
            for server_name, server_config in self.config["mcpServers"].items():
                # Get health status
                status = self.health.get(server_name, "unknown")
                if status == "connected":
                    icon = "✓"
                    color = theme.SUCCESS_COLOR
                elif status == "failed":
                    icon = "✗"
                    color = theme.ERROR_COLOR
                else:
                    icon = "⚠"
                    color = theme.WARNING_COLOR

                # Get server type
                server_type = server_config.get("type", "stdio")

                # Create list item with icon and type
                item_text = f"{icon} {server_name} ({server_type})"
                item = QListWidgetItem(item_text)
                item.setData(Qt.ItemDataRole.UserRole, server_name)  # Store server name
                self.server_list.addItem(item)

    def filter_servers(self, text):
        """Filter server list based on search text"""
        for i in range(self.server_list.count()):
            item = self.server_list.item(i)
            if text.lower() in item.text().lower():
                item.setHidden(False)
            else:
                item.setHidden(True)

    def on_server_selected(self, item):
        """Handle server selection - highlight it in editor and update label"""
        server_name = item.data(Qt.ItemDataRole.UserRole)

        if server_name and "mcpServers" in self.config:
            # Update label to show selected server
            self.server_name_label.setText(f"Editing: {server_name}")

            # Find the server name in the editor text and highlight it
            text = self.editor.toPlainText()
            search_text = f'"{server_name}"'

            # Find the position of the server name
            cursor = self.editor.textCursor()
            doc = self.editor.document()
            cursor = doc.find(search_text)

            if not cursor.isNull():
                # Select the entire server block (approximate by selecting multiple lines)
                cursor.movePosition(cursor.MoveOperation.StartOfLine)
                cursor.movePosition(cursor.MoveOperation.Down, cursor.MoveMode.KeepAnchor, 10)
                self.editor.setTextCursor(cursor)
                self.editor.ensureCursorVisible()

    def load_mcp_config(self):
        """Load MCP configuration from current scope and auto-check health"""
        try:
            if self.scope == "user":
                full_config = self.config_manager.get_mcp_config(self.scope)
            else:
                # For local/project, read from project folder
                file_path = self.get_scope_file_path()
                if file_path and file_path.exists():
                    with open(file_path, 'r', encoding='utf-8') as f:
                        full_config = json.load(f)
                else:
                    full_config = {}

            # Extract ONLY mcpServers section
            if "mcpServers" in full_config:
                self.config = {"mcpServers": full_config["mcpServers"]}
            else:
                self.config = {"mcpServers": {}}

            formatted_json = json.dumps(self.config, indent=2)
            self.editor.setPlainText(formatted_json)
            self.update_server_list()

            # Reset label when loading fresh config
            self.server_name_label.setText("No server selected")

            # Auto-check health after load
            self.check_server_health()

        except FileNotFoundError:
            # File doesn't exist yet - create empty config
            self.config = {"mcpServers": {}}
            self.editor.setPlainText('{\n  "mcpServers": {\n  }\n}')
            self.update_server_list()
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load MCP configuration:\n{str(e)}")

    def strip_ansi_codes(self, text):
        """Strip ANSI escape codes from text"""
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    def check_server_health(self):
        """Run claude mcp list to check server health - updates silently"""
        success, stdout, stderr = run_command_silent(["claude.cmd", "mcp", "list"], timeout=30)

        if success:
            # Strip ANSI codes and parse output to get server status
            clean_output = self.strip_ansi_codes(stdout)
            self.parse_health_status(clean_output)
            self.update_server_list()
            # Silent update - no popup
        else:
            if "not found" in stderr.lower() or "no such file" in stderr.lower():
                QMessageBox.warning(
                    self,
                    "Command Not Found",
                    "claude.cmd not found. Please ensure Claude Code CLI is in your PATH."
                )
            else:
                QMessageBox.warning(
                    self,
                    "Health Check Failed",
                    f"Failed to check server health:\n{stderr}"
                )

    def parse_health_status(self, output):
        """Parse claude mcp list output to extract server health"""
        self.health = {}
        for line in output.split('\n'):
            if ':' in line and ('✓' in line or '✗' in line):
                # Extract server name and status
                parts = line.split(':')
                if len(parts) >= 2:
                    server_name = parts[0].strip()
                    if '✓' in line:
                        self.health[server_name] = "connected"
                    elif '✗' in line:
                        self.health[server_name] = "failed"

    def add_server(self):
        """Add a new MCP server via dialog"""
        dialog = AddServerDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            server_name, server_config = dialog.get_server_config()

            config = self.config

            # Check if server already exists
            if "mcpServers" in config and server_name in config["mcpServers"]:
                reply = QMessageBox.question(
                    self,
                    "Server Exists",
                    f"Server '{server_name}' already exists. Overwrite?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply == QMessageBox.StandardButton.No:
                    return

            # Add server to config
            if "mcpServers" not in config:
                config["mcpServers"] = {}

            config["mcpServers"][server_name] = server_config
            self.config = config

            # Update editor and list
            formatted_json = json.dumps(config, indent=2)
            self.editor.setPlainText(formatted_json)
            self.update_server_list()

            # Auto-check health after adding server
            self.check_server_health()

            QMessageBox.information(
                self,
                "Server Added",
                f"Server '{server_name}' added successfully!\n\nDon't forget to save the configuration."
            )

    def remove_server(self):
        """Remove selected MCP server"""
        server_list = self.server_list
        selected_items = server_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a server to remove.")
            return

        server_name = selected_items[0].data(Qt.ItemDataRole.UserRole)

        reply = QMessageBox.question(
            self,
            "Confirm Removal",
            f"Are you sure you want to remove server '{server_name}' from {self.get_scope_display_name()} scope?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                config = self.config
                # Remove from config
                if "mcpServers" in config and server_name in config["mcpServers"]:
                    del config["mcpServers"][server_name]
                    # Update editor
                    formatted_json = json.dumps(config, indent=2)
                    self.editor.setPlainText(formatted_json)
                    # Save
                    self.save_mcp_config_internal(config)
                    self.update_server_list()
                    # Auto-check health after removing server
                    self.check_server_health()
                    QMessageBox.information(self, "Removed", f"Server '{server_name}' removed successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to remove server:\n{str(e)}")

    def edit_server(self):
        """Edit selected MCP server via dialog"""
        server_list = self.server_list
        selected_items = server_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a server to edit.")
            return

        server_name = selected_items[0].data(Qt.ItemDataRole.UserRole)
        config = self.config

        if "mcpServers" not in config or server_name not in config["mcpServers"]:
            QMessageBox.warning(self, "Error", f"Server '{server_name}' not found in configuration.")
            return

        # Get existing server config
        server_config = config["mcpServers"][server_name]

        # Open dialog in edit mode
        dialog = AddServerDialog(
            self,
            edit_mode=True,
            server_name=server_name,
            server_config=server_config
        )

        if dialog.exec() == QDialog.DialogCode.Accepted:
            # Get updated config (name should be the same since we disabled the name field)
            _, updated_config = dialog.get_server_config()

            # Update config
            config["mcpServers"][server_name] = updated_config
            self.config = config

            # Update editor and list
            formatted_json = json.dumps(config, indent=2)
            self.editor.setPlainText(formatted_json)
            self.update_server_list()

            # Auto-check health after editing server
            self.check_server_health()

            QMessageBox.information(
                self,
                "Server Updated",
                f"Server '{server_name}' updated successfully!\n\nDon't forget to save the configuration."
            )

    def list_server_tools(self):
        """List all tools available from the selected MCP server"""
        server_list = self.server_list
        selected_items = server_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a server to inspect.")
            return

        server_name = selected_items[0].data(Qt.ItemDataRole.UserRole)
        config = self.config

        if "mcpServers" not in config or server_name not in config["mcpServers"]:
            QMessageBox.warning(self, "Error", f"Server '{server_name}' not found in configuration.")
            return

        # Get server config
        server_config = config["mcpServers"][server_name]

        # Open the MCP Tools Dialog
        dialog = MCPToolsDialog(server_name, server_config, self)
        dialog.exec()

    def validate_json(self):
        """Validate the JSON in the editor"""
        try:
            editor = self.editor
            json.loads(editor.toPlainText())
            QMessageBox.information(self, "Valid", "JSON is valid!")
            return True
        except json.JSONDecodeError as e:
            QMessageBox.critical(self, "Invalid JSON", f"Invalid JSON:\n{str(e)}")
            return False

    def save_mcp_config(self):
        """Save MCP configuration"""
        if not self.validate_json():
            return
        try:
            editor = self.editor
            content = editor.toPlainText()
            config = json.loads(content)
            self.save_mcp_config_internal(config)
            self.config = config
            self.update_server_list()
            QMessageBox.information(self, "Saved", f"MCP configuration saved to {self.get_scope_display_name()} scope!")
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save:\n{str(e)}")

    def save_mcp_config_internal(self, config):
        """Internal method to save config without validation"""
        if self.scope == "user":
            self.config_manager.save_mcp_config(config, self.scope)
        else:
            # For local/project, save to project folder
            file_path = self.get_scope_file_path()
            if file_path:
                file_path.parent.mkdir(parents=True, exist_ok=True)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(config, f, indent=2)

    def backup_and_save(self):
        """Create backup before saving"""
        try:
            file_path = self.get_scope_file_path()
            if file_path.exists():
                self.backup_manager.create_file_backup(file_path)
            if self.validate_json():
                editor = self.editor
                content = editor.toPlainText()
                config = json.loads(content)
                self.save_mcp_config_internal(config)
                self.config = config
                self.update_server_list()
                QMessageBox.information(self, "Saved", "Backup created and MCP configuration saved!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed:\n{str(e)}")

    def revert_mcp_config(self):
        """Revert to saved version"""
        reply = QMessageBox.question(
            self,
            "Revert Changes",
            "Are you sure you want to revert to the saved version?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            self.load_mcp_config()

    def open_mcp_sources(self):
        """Open MCP Sources library - manage and deploy servers"""
        sources_file = Path(__file__).parent.parent.parent / "config" / "sources" / "mcp_servers.json"

        if not sources_file.exists():
            # Create empty sources file
            sources_file.parent.mkdir(parents=True, exist_ok=True)
            with open(sources_file, 'w') as f:
                json.dump({"mcpServers": {}}, f, indent=2)

        # Open unified MCP Sources dialog
        dialog = MCPSourcesDialog(sources_file, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            selected_servers = dialog.get_selected_servers()

            if not selected_servers:
                QMessageBox.information(self, "No Selection", "No servers selected.")
                return

            config = self.config
            if "mcpServers" not in config:
                config["mcpServers"] = {}

            # Handle conflicts
            conflicts = []
            for server_name, server_config in selected_servers:
                if server_name in config["mcpServers"]:
                    conflicts.append(server_name)

            # Process conflicts if any
            if conflicts:
                conflict_msg = f"The following servers already exist:\n\n" + "\n".join(conflicts) + "\n\nWhat would you like to do?"

                # Create custom dialog for conflict resolution
                conflict_dialog = QMessageBox(self)
                conflict_dialog.setWindowTitle("Server Conflicts")
                conflict_dialog.setText(conflict_msg)
                conflict_dialog.setIcon(QMessageBox.Icon.Warning)

                overwrite_btn = conflict_dialog.addButton("Overwrite All", QMessageBox.ButtonRole.AcceptRole)
                rename_btn = conflict_dialog.addButton("Rename All", QMessageBox.ButtonRole.ActionRole)
                skip_btn = conflict_dialog.addButton("Skip Conflicts", QMessageBox.ButtonRole.RejectRole)
                cancel_btn = conflict_dialog.addButton("Cancel", QMessageBox.ButtonRole.DestructiveRole)

                conflict_dialog.exec()
                clicked_button = conflict_dialog.clickedButton()

                if clicked_button == cancel_btn:
                    return
                elif clicked_button == overwrite_btn:
                    # Overwrite all conflicts
                    for server_name, server_config in selected_servers:
                        config["mcpServers"][server_name] = server_config
                elif clicked_button == rename_btn:
                    # Open custom rename dialog
                    existing_names = set(config["mcpServers"].keys())
                    rename_dialog = CustomRenameDialog(conflicts, existing_names, self)
                    if rename_dialog.exec() == QDialog.DialogCode.Accepted:
                        rename_map = rename_dialog.rename_map
                        # Add servers with custom names
                        for server_name, server_config in selected_servers:
                            if server_name in rename_map:
                                config["mcpServers"][rename_map[server_name]] = server_config
                            else:
                                config["mcpServers"][server_name] = server_config
                    else:
                        return  # User cancelled rename
                elif clicked_button == skip_btn:
                    # Skip conflicts
                    for server_name, server_config in selected_servers:
                        if server_name not in config["mcpServers"]:
                            config["mcpServers"][server_name] = server_config
            else:
                # No conflicts - add all
                for server_name, server_config in selected_servers:
                    config["mcpServers"][server_name] = server_config

            # Update UI
            self.config = config
            formatted_json = json.dumps(config, indent=2)
            self.editor.setPlainText(formatted_json)
            self.update_server_list()
            self.check_server_health()

            QMessageBox.information(
                self,
                "Servers Added",
                f"Added {len(selected_servers)} server(s) to {self.get_scope_display_name()} scope.\n\n"
                "Don't forget to save the configuration!"
            )

    def reset_project_choices(self):
        """Reset MCP project choices"""
        # Confirm action
        reply = QMessageBox.question(
            self,
            "Confirm Reset",
            "Are you sure you want to reset all MCP project choices?\n\n"
            "This will clear your project-specific MCP server selections.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply != QMessageBox.StandardButton.Yes:
            return

        success, stdout, stderr = run_command_silent(
            ["claude.cmd", "mcp", "reset-project-choices"],
            timeout=30,
            shell=True
        )

        if success:
            QMessageBox.information(
                self,
                "Success",
                "MCP project choices have been reset!\n\n" + stdout
            )
            # Reload configuration
            self.load_mcp_config()
        else:
            if "timed out" in stderr.lower():
                QMessageBox.critical(self, "Timeout", "Command timed out after 30 seconds")
            elif "not found" in stderr.lower() or "no such file" in stderr.lower():
                QMessageBox.critical(
                    self,
                    "Command Not Found",
                    "claude command not found in PATH.\n\n"
                    "Make sure Claude Code is installed and the claude CLI is in your system PATH."
                )
            else:
                QMessageBox.warning(
                    self,
                    "Command Failed",
                    f"Failed to reset project choices:\n\n{stderr}"
                )
