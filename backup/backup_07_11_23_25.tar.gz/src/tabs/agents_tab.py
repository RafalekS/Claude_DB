"""
Agents Tab - Manage Claude Code agents
"""

from pathlib import Path
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit,
    QLabel, QMessageBox, QListWidget, QSplitter, QLineEdit, QInputDialog,
    QFileDialog, QTabWidget, QDialog, QComboBox, QFormLayout, QDialogButtonBox,
    QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
import sys
import json
sys.path.insert(0, str(Path(__file__).parent.parent))
from utils.theme import *


class NewAgentDialog(QDialog):
    """Dialog for creating a new agent with proper YAML frontmatter"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create New Agent")
        self.setMinimumWidth(500)
        self.init_ui()

    def init_ui(self):
        """Initialize the dialog UI"""
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # Form layout
        form = QFormLayout()
        form.setSpacing(8)

        # Name field
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("e.g., bill-organizer")
        self.name_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Agent Name*:", self.name_edit)

        # Display Name field
        self.display_name_edit = QLineEdit()
        self.display_name_edit.setPlaceholderText("e.g., Bill Organizer (optional)")
        self.display_name_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Display Name:", self.display_name_edit)

        # Description field
        self.description_edit = QLineEdit()
        self.description_edit.setPlaceholderText("e.g., Extract and organize utility bills from Gmail")
        self.description_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Description*:", self.description_edit)

        # Category field
        self.category_edit = QLineEdit()
        self.category_edit.setPlaceholderText("e.g., automation, code-quality, documentation (optional)")
        self.category_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Category:", self.category_edit)

        # Color field
        self.color_combo = QComboBox()
        self.color_combo.addItems([
            "blue", "green", "red", "yellow", "purple", "cyan", "magenta", "orange"
        ])
        self.color_combo.setStyleSheet(get_combo_box_style())
        form.addRow("Color:", self.color_combo)

        # Model dropdown
        self.model_combo = QComboBox()
        self.model_combo.addItems(["sonnet", "opus", "haiku"])
        self.model_combo.setStyleSheet(get_combo_box_style())
        form.addRow("Model*:", self.model_combo)

        # Subfolder field (optional)
        self.subfolder_edit = QLineEdit()
        self.subfolder_edit.setPlaceholderText("e.g., code-quality (optional)")
        self.subfolder_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Subfolder:", self.subfolder_edit)

        # Tools access (optional)
        self.tools_edit = QLineEdit()
        self.tools_edit.setPlaceholderText("e.g., Read, Grep, Glob, Edit (optional)")
        self.tools_edit.setStyleSheet(get_line_edit_style())
        form.addRow("Tools:", self.tools_edit)

        layout.addLayout(form)

        # Info label
        info_label = QLabel(
            "* Required fields\n\n"
            "The agent will be created with YAML frontmatter containing all specified fields.\n"
            "You can add detailed instructions in the markdown content after creation."
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet(f"color: {FG_SECONDARY}; background: {BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(info_label)

        # Button box
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.setStyleSheet(get_button_style())
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def validate_and_accept(self):
        """Validate inputs before accepting"""
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "Validation Error", "Agent name is required.")
            return
        if not self.description_edit.text().strip():
            QMessageBox.warning(self, "Validation Error", "Description is required.")
            return
        self.accept()

    def get_agent_data(self):
        """Return the agent data as a dictionary"""
        return {
            'name': self.name_edit.text().strip(),
            'displayName': self.display_name_edit.text().strip(),
            'description': self.description_edit.text().strip(),
            'category': self.category_edit.text().strip(),
            'color': self.color_combo.currentText(),
            'model': self.model_combo.currentText(),
            'subfolder': self.subfolder_edit.text().strip(),
            'tools': self.tools_edit.text().strip()
        }


def get_combo_box_style():
    """Get combo box style"""
    return f"""
        QComboBox {{
            background: {BG_MEDIUM};
            color: {FG_PRIMARY};
            border: 1px solid {BG_LIGHT};
            border-radius: 3px;
            padding: 5px;
            min-height: 25px;
        }}
        QComboBox:hover {{
            border: 1px solid {ACCENT_PRIMARY};
        }}
        QComboBox::drop-down {{
            border: none;
            padding-right: 5px;
        }}
        QComboBox QAbstractItemView {{
            background: {BG_MEDIUM};
            color: {FG_PRIMARY};
            selection-background-color: {ACCENT_PRIMARY};
            selection-color: white;
            border: 1px solid {BG_LIGHT};
        }}
    """


class AgentsTab(QWidget):
    """Tab for managing Claude Code agents (single-scope)"""

    def __init__(self, config_manager, backup_manager, scope, project_context=None):
        super().__init__()
        self.config_manager = config_manager
        self.backup_manager = backup_manager
        self.scope = scope
        self.project_context = project_context

        # Validate parameters
        if scope == "project" and not project_context:
            raise ValueError("project_context is required when scope='project'")

        self.init_ui()

        # Connect to project changes if project scope
        if self.scope == "project" and self.project_context:
            self.project_context.project_changed.connect(self.on_project_changed)

    def init_ui(self):
        """Initialize the UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)

        # Header
        header_layout = QHBoxLayout()
        header_layout.setSpacing(5)

        scope_label = "User" if self.scope == "user" else "Project"
        header = QLabel(f"Agents ({scope_label})")
        header.setStyleSheet(f"font-size: {FONT_SIZE_LARGE}px; font-weight: bold; color: {ACCENT_PRIMARY};")

        header_layout.addWidget(header)
        header_layout.addStretch()

        layout.addLayout(header_layout)

        # Single agents editor for current scope
        editor_widget = self.create_agents_editor()
        layout.addWidget(editor_widget, 1)

        # Info tip with best practices
        tip_label = QLabel(
            "💡 <b>Agent Design Best Practices:</b> "
            "Define ONE clear responsibility per agent • "
            "Minimize tool access per role (principle of least privilege) • "
            "Prefer read-only agents for analysis/review tasks • "
            "Limit write permissions to essential agents only"
            "<br><b>Example Agents:</b> "
            "Planner (read-only: convert features → tasks) • "
            "Codegen (edit: implement with path restrictions) • "
            "Tester (read-only: write failing tests) • "
            "Reviewer (read-only: structured comments) • "
            "Docs (edit: update documentation)"
            "<br><b>Usage:</b> "
            "Use <code>claude /agents</code> to invoke • "
            "User agents (~/.claude/agents/) are global • "
            "Project agents (./.claude/agents/) are shared with team via git"
        )
        tip_label.setWordWrap(True)
        tip_label.setStyleSheet(f"color: {FG_SECONDARY}; background: {BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(tip_label)

    def create_agents_editor(self):
        """Create agents editor for the current scope"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # File path label
        agents_dir = self.get_scope_agents_dir()
        path_label = QLabel(f"Directory: {agents_dir}")
        path_label.setStyleSheet(f"font-size: {FONT_SIZE_SMALL}px; color: {FG_SECONDARY};")
        layout.addWidget(path_label)

        # Store references
        self.path_label = path_label
        self.current_agent = None

        # Splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left panel - agent list
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)

        # Search
        search_box = QLineEdit()
        search_box.setPlaceholderText("Search...")
        search_box.textChanged.connect(self.filter_agents)
        search_box.setStyleSheet(get_line_edit_style())
        left_layout.addWidget(search_box)

        # Agent list
        agent_list = QListWidget()
        agent_list.itemClicked.connect(self.load_agent_content)
        agent_list.setStyleSheet(get_list_widget_style())
        left_layout.addWidget(agent_list)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(5)

        new_btn = QPushButton("➕ New")
        new_btn.setToolTip("Create a new agent")
        edit_btn = QPushButton("✏️ Edit")
        edit_btn.setToolTip("Edit agent metadata")
        del_btn = QPushButton("🗑️ Delete")
        del_btn.setToolTip("Delete the selected agent")
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setToolTip("Reload the agents list")
        library_btn = QPushButton("📚 Agent Library")
        library_btn.setToolTip("Browse and add agents from library templates")

        for btn in [new_btn, edit_btn, del_btn, refresh_btn, library_btn]:
            btn.setStyleSheet(get_button_style())

        new_btn.clicked.connect(self.create_new_agent)
        edit_btn.clicked.connect(self.edit_agent_metadata)
        del_btn.clicked.connect(self.delete_agent)
        refresh_btn.clicked.connect(self.load_agents)
        library_btn.clicked.connect(self.open_agent_library)

        btn_layout.addWidget(new_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(del_btn)
        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(library_btn)
        left_layout.addLayout(btn_layout)

        splitter.addWidget(left_panel)

        # Right panel - editor
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(5)

        # Editor buttons
        editor_btn_layout = QHBoxLayout()
        editor_btn_layout.setSpacing(5)

        agent_name_label = QLabel("No agent selected")
        agent_name_label.setStyleSheet(get_label_style("normal", "secondary"))

        save_btn = QPushButton("💾 Save")
        save_btn.setToolTip("Save the current agent to file")
        backup_save_btn = QPushButton("📦 Backup & Save")
        backup_save_btn.setToolTip("Create timestamped backup before saving agent")
        revert_btn = QPushButton("Revert")
        revert_btn.setToolTip("Revert to saved version (discards unsaved changes)")

        for btn in [save_btn, backup_save_btn, revert_btn]:
            btn.setStyleSheet(get_button_style())

        save_btn.clicked.connect(self.save_agent)
        backup_save_btn.clicked.connect(self.backup_and_save_agent)
        revert_btn.clicked.connect(self.revert_agent)

        editor_btn_layout.addWidget(agent_name_label)
        editor_btn_layout.addStretch()
        editor_btn_layout.addWidget(save_btn)
        editor_btn_layout.addWidget(backup_save_btn)
        editor_btn_layout.addWidget(revert_btn)
        right_layout.addLayout(editor_btn_layout)

        # Editor
        agent_editor = QTextEdit()
        agent_editor.setStyleSheet(get_text_edit_style())
        right_layout.addWidget(agent_editor)

        splitter.addWidget(right_panel)
        splitter.setSizes([300, 1000])

        layout.addWidget(splitter, 1)

        # Store references
        self.search_box = search_box
        self.agent_list = agent_list
        self.agent_name_label = agent_name_label
        self.agent_editor = agent_editor

        # Load initial data
        self.load_agents()

        return widget

    def get_scope_agents_dir(self):
        """Get agents directory for the current scope"""
        if self.scope == "user":
            return self.config_manager.agents_dir
        else:  # project
            if not self.project_context.has_project():
                return None
            return self.project_context.get_project() / ".claude" / "agents"

    def on_project_changed(self, project_path: Path):
        """Handle project context change"""
        # Update path label
        agents_dir = self.get_scope_agents_dir()
        if agents_dir:
            self.path_label.setText(f"Directory: {agents_dir}")
        # Reload agents from new project
        self.load_agents()

    def load_agents(self):
        """Load all agents for the current scope"""
        try:
            self.agent_list.clear()

            agents_dir = self.get_scope_agents_dir()

            if not agents_dir or not agents_dir.exists():
                return

            # List all .md files in agents directory and subdirectories (recursive)
            agents = list(agents_dir.glob("**/*.md"))
            for agent_path in sorted(agents):
                # Show relative path from agents_dir
                rel_path = agent_path.relative_to(agents_dir)
                self.agent_list.addItem(str(rel_path))

        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load agents:\n{str(e)}")

    def filter_agents(self, text):
        """Filter agents based on search text"""
        for i in range(self.agent_list.count()):
            item = self.agent_list.item(i)
            item.setHidden(text.lower() not in item.text().lower())

    def load_agent_content(self, item):
        """Load content of selected agent"""
        try:
            agent_name = item.text()
            agents_dir = self.get_scope_agents_dir()
            agent_path = agents_dir / agent_name

            if agent_path.exists():
                with open(agent_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.current_agent = agent_path
                self.agent_name_label.setText(f"Editing: {agent_name}")
                self.agent_editor.setPlainText(content)
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load agent:\n{str(e)}")

    def save_agent(self):
        """Save current agent"""
        if not self.current_agent:
            QMessageBox.warning(self, "No Agent Selected", "Please select an agent to save.")
            return
        try:
            content = self.agent_editor.toPlainText()
            with open(self.current_agent, 'w', encoding='utf-8') as f:
                f.write(content)
            QMessageBox.information(self, "Save Success", "Agent saved successfully!")
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save agent:\n{str(e)}")

    def backup_and_save_agent(self):
        """Backup and save current agent"""
        if not self.current_agent:
            QMessageBox.warning(self, "No Agent Selected", "Please select an agent to save.")
            return
        try:
            self.backup_manager.create_file_backup(self.current_agent)
            content = self.agent_editor.toPlainText()
            with open(self.current_agent, 'w', encoding='utf-8') as f:
                f.write(content)
            QMessageBox.information(self, "Backup & Save Success", "Backup created and agent saved!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to backup and save:\n{str(e)}")

    def revert_agent(self):
        """Revert agent to saved version"""
        if not self.current_agent:
            return
        reply = QMessageBox.question(
            self, "Revert Changes", "Are you sure you want to revert to the saved version?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            try:
                with open(self.current_agent, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.agent_editor.setPlainText(content)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to revert:\n{str(e)}")

    def create_new_agent(self):
        """Create a new agent with proper YAML frontmatter"""
        # Show dialog to get agent data
        dialog = NewAgentDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        agent_data = dialog.get_agent_data()

        # Build agent path
        agents_dir = self.get_scope_agents_dir()

        # Handle subfolder
        if agent_data['subfolder']:
            agent_path = agents_dir / agent_data['subfolder'] / f"{agent_data['name']}.md"
        else:
            agent_path = agents_dir / f"{agent_data['name']}.md"

        if agent_path.exists():
            QMessageBox.warning(self, "Agent Exists", f"Agent '{agent_data['name']}' already exists.")
            return

        try:
            # Create parent directories if they don't exist
            agent_path.parent.mkdir(parents=True, exist_ok=True)

            # Build YAML frontmatter
            frontmatter_lines = [
                "---",
                f"name: {agent_data['name']}"
            ]

            # Add optional displayName
            if agent_data['displayName']:
                frontmatter_lines.append(f"displayName: {agent_data['displayName']}")

            frontmatter_lines.append(f"description: {agent_data['description']}")

            # Add optional category
            if agent_data['category']:
                frontmatter_lines.append(f"category: {agent_data['category']}")

            # Add color
            frontmatter_lines.append(f"color: {agent_data['color']}")

            # Add model
            frontmatter_lines.append(f"model: {agent_data['model']}")

            # Add tools if specified
            if agent_data['tools']:
                frontmatter_lines.append(f"tools: {agent_data['tools']}")

            frontmatter_lines.append("---")
            frontmatter = "\n".join(frontmatter_lines)

            # Build template with frontmatter
            template = f"""{frontmatter}

# {agent_data['name']}

## Description
{agent_data['description']}

## Usage
Define when and how to use this agent.

## Instructions
Provide detailed instructions for the agent to follow when invoked.

### Key Responsibilities
- Responsibility 1
- Responsibility 2

### Best Practices
- Follow principle of least privilege
- Minimize tool access to only what's needed
- Provide clear, actionable guidance
"""

            with open(agent_path, 'w', encoding='utf-8') as f:
                f.write(template)

            self.load_agents()
            QMessageBox.information(
                self,
                "Agent Created",
                f"Agent '{agent_data['name']}' created successfully!\n\nLocation: {agent_path}"
            )

            # Auto-select the new agent
            rel_path = agent_path.relative_to(agents_dir)
            items = self.agent_list.findItems(str(rel_path), Qt.MatchFlag.MatchExactly)
            if items:
                self.agent_list.setCurrentItem(items[0])
                self.load_agent_content(items[0])

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create agent:\n{str(e)}")

    def delete_agent(self):
        """Delete selected agent"""
        if not self.current_agent:
            QMessageBox.warning(self, "No Agent Selected", "Please select an agent to delete.")
            return
        reply = QMessageBox.question(
            self, "Delete Agent", f"Are you sure you want to delete:\n{self.current_agent.name}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            try:
                self.current_agent.unlink()
                self.agent_editor.clear()
                self.agent_name_label.setText("No agent selected")
                self.current_agent = None
                self.load_agents()
                QMessageBox.information(self, "Delete Success", "Agent deleted successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to delete agent:\n{str(e)}")

    def edit_agent_metadata(self):
        """Edit agent metadata (frontmatter) in a GUI"""
        if not self.current_agent:
            QMessageBox.warning(self, "No Agent Selected", "Please select an agent to edit.")
            return

        try:
            # Read current content
            with open(self.current_agent, 'r', encoding='utf-8') as f:
                content = f.read()

            # Parse frontmatter
            frontmatter, body = self.parse_frontmatter(content)

            # Create dialog and pre-fill with current values
            dialog = NewAgentDialog(self)
            dialog.setWindowTitle("Edit Agent Metadata")
            dialog.name_edit.setText(frontmatter.get('name', ''))
            dialog.display_name_edit.setText(frontmatter.get('displayName', ''))
            dialog.description_edit.setText(frontmatter.get('description', ''))
            dialog.category_edit.setText(frontmatter.get('category', ''))

            # Set color combo
            color = frontmatter.get('color', 'blue')
            color_index = dialog.color_combo.findText(color)
            if color_index >= 0:
                dialog.color_combo.setCurrentIndex(color_index)

            # Set model combo
            model = frontmatter.get('model', 'sonnet')
            model_index = dialog.model_combo.findText(model)
            if model_index >= 0:
                dialog.model_combo.setCurrentIndex(model_index)

            dialog.tools_edit.setText(frontmatter.get('tools', ''))

            # Don't show subfolder field for editing (can't move files)
            dialog.subfolder_edit.setVisible(False)
            dialog.findChild(QLabel).setVisible(False)  # Hide the label too

            if dialog.exec() != QDialog.DialogCode.Accepted:
                return

            agent_data = dialog.get_agent_data()

            # Rebuild frontmatter
            frontmatter_lines = [
                "---",
                f"name: {agent_data['name']}"
            ]

            if agent_data['displayName']:
                frontmatter_lines.append(f"displayName: {agent_data['displayName']}")

            frontmatter_lines.append(f"description: {agent_data['description']}")

            if agent_data['category']:
                frontmatter_lines.append(f"category: {agent_data['category']}")

            frontmatter_lines.append(f"color: {agent_data['color']}")
            frontmatter_lines.append(f"model: {agent_data['model']}")

            if agent_data['tools']:
                frontmatter_lines.append(f"tools: {agent_data['tools']}")

            frontmatter_lines.append("---")
            new_frontmatter = "\n".join(frontmatter_lines)

            # Combine with existing body
            new_content = f"{new_frontmatter}\n\n{body}"

            # Update editor
            self.agent_editor.setPlainText(new_content)

            QMessageBox.information(
                self,
                "Metadata Updated",
                "Agent metadata has been updated. Click 'Save' to save changes to file."
            )

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to edit metadata:\n{str(e)}")

    def parse_frontmatter(self, content):
        """Parse YAML frontmatter from content"""
        import re

        frontmatter = {}
        body = content

        # Check if content starts with ---
        if content.startswith('---'):
            # Find the closing ---
            match = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)$', content, re.DOTALL)
            if match:
                frontmatter_text = match.group(1)
                body = match.group(2)

                # Parse YAML-like frontmatter (simple key: value pairs)
                for line in frontmatter_text.split('\n'):
                    if ':' in line:
                        key, value = line.split(':', 1)
                        frontmatter[key.strip()] = value.strip()

        return frontmatter, body

    def open_agent_library(self):
        """Open agent library to browse and add agents from templates"""
        sources_file = Path(__file__).parent.parent.parent / "config" / "sources" / "agents.json"

        if not sources_file.exists():
            QMessageBox.warning(
                self, "Library Not Found",
                f"Agent library file not found:\n{sources_file}\n\nPlease ensure the file exists."
            )
            return

        dialog = AgentSourcesDialog(sources_file, self.scope, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            selected = dialog.get_selected_agents()
            if selected:
                self.deploy_agents(selected)
                self.load_agents()

    def deploy_agents(self, agents):
        """Deploy selected agents to the current scope"""
        agents_dir = self.get_scope_agents_dir()
        agents_dir.mkdir(parents=True, exist_ok=True)

        added_count = 0
        skipped_count = 0

        for agent_name, agent_data in agents:
            agent_file = agents_dir / f"{agent_name}.md"
            if agent_file.exists():
                skipped_count += 1
                continue

            try:
                content = agent_data.get("content", "")
                with open(agent_file, 'w', encoding='utf-8') as f:
                    f.write(content)
                added_count += 1
            except Exception as e:
                QMessageBox.critical(self, "Deploy Error", f"Failed to deploy '{agent_name}':\n{str(e)}")

        if added_count > 0 or skipped_count > 0:
            msg = f"Added {added_count} agent(s)"
            if skipped_count > 0:
                msg += f"\nSkipped {skipped_count} (already exist)"
            QMessageBox.information(self, "Deploy Complete", msg)


class AgentSourcesDialog(QDialog):
    """Dialog for adding agents from config/sources/agents.json"""

    def __init__(self, sources_file, scope, parent=None):
        super().__init__(parent)
        self.sources_file = sources_file
        self.scope = scope
        self.setWindowTitle("Agent Library")
        self.setModal(True)
        self.setMinimumWidth(900)
        self.setMinimumHeight(700)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("Agent Library - Manage and deploy agent templates")
        header.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY}; font-size: {FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        # File info
        file_info = QLabel(f"Source File: {self.sources_file}")
        file_info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(file_info)

        # Load sources
        try:
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                sources_data = json.load(f)
            self.agents = sources_data.get("agents", {})
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Failed to load agent sources:\n{str(e)}")
            self.agents = {}

        # Table with checkboxes
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Select", "Name", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {BG_DARK};
                color: {FG_PRIMARY};
                border: 1px solid {BG_LIGHT};
                border-radius: 3px;
            }}
            QHeaderView::section {{
                background-color: {BG_MEDIUM};
                color: {FG_PRIMARY};
                padding: 5px;
                border: 1px solid {BG_LIGHT};
            }}
        """)

        # Populate table
        self.checkboxes = []
        self.table.setRowCount(len(self.agents))
        for row, (agent_name, agent_data) in enumerate(self.agents.items()):
            # Checkbox
            checkbox = QCheckBox()
            checkbox_widget = QWidget()
            checkbox_layout = QHBoxLayout(checkbox_widget)
            checkbox_layout.addWidget(checkbox)
            checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            checkbox_layout.setContentsMargins(0, 0, 0, 0)
            self.table.setCellWidget(row, 0, checkbox_widget)
            self.checkboxes.append((agent_name, checkbox))

            # Name
            name_item = QTableWidgetItem(agent_name)
            self.table.setItem(row, 1, name_item)

            # Description
            description = agent_data.get("description", "No description")
            desc_item = QTableWidgetItem(description)
            self.table.setItem(row, 2, desc_item)

        layout.addWidget(self.table)

        # Management buttons
        manage_layout = QHBoxLayout()

        bulk_add_btn = QPushButton("➕ Bulk Add Agents")
        bulk_add_btn.setStyleSheet(get_button_style())
        bulk_add_btn.setToolTip("Open bulk paste dialog to add multiple agents at once")
        bulk_add_btn.clicked.connect(self.open_bulk_add)
        manage_layout.addWidget(bulk_add_btn)

        delete_btn = QPushButton("🗑️ Delete Selected")
        delete_btn.setStyleSheet(get_button_style())
        delete_btn.setToolTip("Delete selected agents from library")
        delete_btn.clicked.connect(self.delete_selected)
        manage_layout.addWidget(delete_btn)

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setStyleSheet(get_button_style())
        refresh_btn.setToolTip("Reload agents from file")
        refresh_btn.clicked.connect(self.refresh_sources)
        manage_layout.addWidget(refresh_btn)

        manage_layout.addStretch()
        layout.addLayout(manage_layout)

        # Select All / Deselect All buttons
        select_layout = QHBoxLayout()
        select_all_btn = QPushButton("✓ Select All")
        select_all_btn.setStyleSheet(get_button_style())
        select_all_btn.clicked.connect(self.select_all)
        select_layout.addWidget(select_all_btn)

        deselect_all_btn = QPushButton("✗ Deselect All")
        deselect_all_btn.setStyleSheet(get_button_style())
        deselect_all_btn.clicked.connect(self.deselect_all)
        select_layout.addWidget(deselect_all_btn)

        select_layout.addStretch()
        layout.addLayout(select_layout)

        # Info label
        info = QLabel("Select agents to deploy, then click OK.")
        info.setStyleSheet(f"color: {FG_SECONDARY}; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(info)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def select_all(self):
        """Select all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(True)

    def deselect_all(self):
        """Deselect all checkboxes"""
        for _, checkbox in self.checkboxes:
            checkbox.setChecked(False)

    def get_selected_agents(self):
        """Get list of selected agent names and their data"""
        selected = []
        for agent_name, checkbox in self.checkboxes:
            if checkbox.isChecked():
                selected.append((agent_name, self.agents[agent_name]))
        return selected

    def open_bulk_add(self):
        """Open bulk edit dialog to add agents to library"""
        dialog = BulkAgentEditDialog(self.sources_file, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh_sources()

    def delete_selected(self):
        """Delete selected agents from config/sources/agents.json"""
        selected = self.get_selected_agents()
        if not selected:
            QMessageBox.warning(self, "No Selection", "Please select agents to delete.")
            return

        agent_names = [name for name, _ in selected]
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete {len(agent_names)} agent(s) from library?\n\n" + "\n".join(agent_names),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                with open(self.sources_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                for name in agent_names:
                    if name in data.get("agents", {}):
                        del data["agents"][name]

                with open(self.sources_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)

                QMessageBox.information(self, "Success", f"Deleted {len(agent_names)} agent(s) from library.")
                self.refresh_sources()
            except Exception as e:
                QMessageBox.critical(self, "Delete Error", f"Failed to delete agents:\n{str(e)}")

    def refresh_sources(self):
        """Reload agents from file and refresh table"""
        try:
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.agents = data.get("agents", {})

            # Rebuild table
            self.checkboxes = []
            self.table.setRowCount(len(self.agents))

            for row, (agent_name, agent_data) in enumerate(self.agents.items()):
                # Checkbox
                checkbox = QCheckBox()
                checkbox_widget = QWidget()
                checkbox_layout = QHBoxLayout(checkbox_widget)
                checkbox_layout.addWidget(checkbox)
                checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
                checkbox_layout.setContentsMargins(0, 0, 0, 0)
                self.table.setCellWidget(row, 0, checkbox_widget)
                self.checkboxes.append((agent_name, checkbox))

                # Name
                name_item = QTableWidgetItem(agent_name)
                name_item.setForeground(QColor(FG_PRIMARY))
                self.table.setItem(row, 1, name_item)

                # Description
                description = agent_data.get("description", "No description")
                desc_item = QTableWidgetItem(description)
                desc_item.setForeground(QColor(FG_SECONDARY))
                self.table.setItem(row, 2, desc_item)

        except Exception as e:
            QMessageBox.critical(self, "Reload Error", f"Failed to reload agents:\n{str(e)}")


class BulkAgentEditDialog(QDialog):
    """Dialog for bulk editing agent sources"""

    def __init__(self, sources_file, parent=None):
        super().__init__(parent)
        self.sources_file = sources_file
        self.setWindowTitle("Bulk Add Agents")
        self.setModal(True)
        self.setMinimumWidth(700)
        self.setMinimumHeight(500)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Header
        header = QLabel("Bulk Add Agents")
        header.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY}; font-size: {FONT_SIZE_LARGE}px;")
        layout.addWidget(header)

        # Instructions
        instructions = QLabel(
            "Paste agent definitions in any format:\n\n"
            "<b>Format 1 (name,description,content):</b> code-reviewer,Code review agent,# Agent content...\n"
            "<b>Format 2 (name: content):</b> code-reviewer: # Agent content...\n"
            "<b>Format 3 (JSON):</b> Direct JSON from agents.json\n\n"
            "Each agent should be on a separate line or as valid JSON."
        )
        instructions.setWordWrap(True)
        instructions.setStyleSheet(f"color: {FG_SECONDARY}; background: {BG_MEDIUM}; padding: 8px; border-radius: 3px; font-size: {FONT_SIZE_SMALL}px;")
        layout.addWidget(instructions)

        # Text area for pasting
        input_label = QLabel("Paste agent definitions:")
        input_label.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY};")
        layout.addWidget(input_label)

        self.input_text = QTextEdit()
        self.input_text.setPlaceholderText(
            "code-reviewer,Code review agent,# Agent content here\n"
            "test-generator: # Test generator agent content\n"
            "Or paste JSON: {\"code-reviewer\": {\"name\": \"code-reviewer\", ...}}"
        )
        self.input_text.setStyleSheet(get_text_edit_style())
        layout.addWidget(self.input_text)

        # Buttons
        button_layout = QHBoxLayout()

        parse_btn = QPushButton("🔄 Parse & Preview")
        parse_btn.setStyleSheet(get_button_style())
        parse_btn.clicked.connect(self.parse_and_preview)
        button_layout.addWidget(parse_btn)

        button_layout.addStretch()

        save_btn = QPushButton("💾 Save to Library")
        save_btn.setStyleSheet(get_button_style())
        save_btn.clicked.connect(self.save_to_library)
        button_layout.addWidget(save_btn)

        close_btn = QPushButton("✗ Close")
        close_btn.setStyleSheet(get_button_style())
        close_btn.clicked.connect(self.reject)
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

        # Preview area
        preview_label = QLabel("Preview (JSON):")
        preview_label.setStyleSheet(f"font-weight: bold; color: {FG_PRIMARY};")
        layout.addWidget(preview_label)

        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setStyleSheet(get_text_edit_style())
        layout.addWidget(self.preview_text)

    def parse_and_preview(self):
        """Parse input and show preview"""
        input_text = self.input_text.toPlainText().strip()
        if not input_text:
            QMessageBox.warning(self, "Empty Input", "Please paste agent definitions first.")
            return

        try:
            parsed_agents = {}

            # Try JSON first
            if input_text.startswith("{"):
                data = json.loads(input_text)
                if "agents" in data:
                    parsed_agents = data["agents"]
                else:
                    parsed_agents = data
            else:
                # Parse line by line
                lines = input_text.split('\n')
                for line in lines:
                    line = line.strip()
                    if not line:
                        continue

                    # Format: name,description,content
                    if ',' in line:
                        parts = line.split(',', 2)
                        if len(parts) >= 2:
                            name = parts[0].strip()
                            description = parts[1].strip() if len(parts) > 1 else "No description"
                            content = parts[2].strip() if len(parts) > 2 else description
                            parsed_agents[name] = {
                                "name": name,
                                "description": description,
                                "content": content
                            }
                    # Format: name: content
                    elif ':' in line:
                        name, content = line.split(':', 1)
                        name = name.strip()
                        content = content.strip()
                        parsed_agents[name] = {
                            "name": name,
                            "description": f"Agent: {name}",
                            "content": content
                        }

            if not parsed_agents:
                QMessageBox.warning(self, "Parse Error", "No valid agents found in input.")
                return

            # Show preview
            preview = json.dumps({"agents": parsed_agents}, indent=2)
            self.preview_text.setPlainText(preview)
            self.parsed_data = parsed_agents

        except Exception as e:
            QMessageBox.critical(self, "Parse Error", f"Failed to parse input:\n{str(e)}")

    def save_to_library(self):
        """Save parsed agents to library"""
        if not hasattr(self, 'parsed_data') or not self.parsed_data:
            QMessageBox.warning(self, "No Data", "Please parse agents first using 'Parse & Preview'.")
            return

        try:
            # Load existing
            with open(self.sources_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if "agents" not in data:
                data["agents"] = {}

            # Merge
            added = 0
            for agent_name, agent_data in self.parsed_data.items():
                if agent_name not in data["agents"]:
                    data["agents"][agent_name] = agent_data
                    added += 1

            # Save
            with open(self.sources_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)

            QMessageBox.information(self, "Success", f"Added {added} agent(s) to library.")
            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save agents:\n{str(e)}")
