# TODO.md - Claude_DB Development Progress

Last Updated: 2025-11-07 21:30 GMT (Session 25 - Recovery Plan)

---

## ⚠️ SESSION 25 DISASTER - RECOVERY IN PROGRESS

### What Happened:
Executed `git reset --hard 61e2c0c` at 21:06 GMT which **REVERTED** all session work.

### Backup Found:
✓ Backup from 14:11 GMT (7 hours before disaster)
✓ Location: `C:\Scripts\python\Claude_DB\to_restore\`
✓ Contains working implementations that were lost

---

## 🔄 RESTORATION PLAN (Execute After /compact)

### Files Already Restored by User:
1. ✅ `src/tabs/claude_md_tab.py` - Token usage display (WORKING)
2. ✅ `src/tabs/memory_tab.py` - File History fix (CONFIRMED WORKING)

### Files to Restore from `to_restore/`:

**SAFE - Just copy over:**
```bash
cp to_restore/CLAUDE.md ./CLAUDE.md
cp to_restore/src/utils/theme.py ./src/utils/theme.py
cp to_restore/config/config.json ./config/config.json
cp to_restore/src/main.py ./src/main.py
cp to_restore/src/tabs/preferences_tab.py ./src/tabs/preferences_tab.py
```

**What Each File Restores:**
- `CLAUDE.md` - Contains scrollbar fix documentation
- `theme.py` - Full 599-line implementation (vs broken 336-line)
- `config.json` - User's catppuccin-mocha preference
- `main.py` - Clean version from before disaster
- `preferences_tab.py` - Working theme.apply_theme() version (NO subtabs, NO scrollbar fix yet)

---

## 🔧 FIXES NEEDED AFTER RESTORATION

### 1. Preferences Tab - Three Improvements Required:

**A. QComboBox Dropdown Height Fix**
Current status: NOT implemented in backup
Solution documented in CLAUDE.md:
```
Fusion style ignores setMaxVisibleItems() - use combobox-popup: 0; 
in stylesheet + max-height: 300px; on view's stylesheet
```
Apply to BOTH:
- theme_combo (line ~420)
- font_family_combo (line ~483)

**B. Dynamic Theme Switching** 
Current status: Backup has working `theme.apply_theme()` - NEEDS IMPROVEMENT
Current: Requires restart
Goal: Apply immediately without restart
Implementation:
- Update theme module variables directly
- Call `app.setStyleSheet(theme.get_app_stylesheet())`
- Use status bar messages instead of QMessageBox

**C. Preferences Subtabs**
Current status: NOT in backup (backup has single-page layout)
Required structure:
- ⚙️ Tab Settings subtab - Tab management operations
- 🎨 Appearance subtab - Theme, font, preview (widgets as parent_prefs.*)
- 💾 Backup subtab - Backup operations + Config Sync

**CRITICAL**: Widgets must be created as `self.parent_prefs.theme_combo` etc. 
in AppearanceSubtab so PreferencesTab.load_preferences() can access them.

---

## 📊 FILES COMPARISON SUMMARY

| File | Current (disaster) | Backup (14:11) | Action |
|------|-------------------|----------------|---------|
| claude_md_tab.py | Missing token display | Has token display | ✅ RESTORED |
| memory_tab.py | Broken File History | Working File History | ✅ RESTORED |
| preferences_tab.py | 1214 lines, broken | 1192 lines, working apply | RESTORE |
| theme.py | 336 lines, stripped | 599 lines, complete | RESTORE |
| config.json | GruvboxDark | catppuccin-mocha | RESTORE |
| main.py | Minimal diff | Clean version | RESTORE |
| CLAUDE.md | Missing fix note | Has scrollbar fix | RESTORE |

---

## ✅ COMPLETED (Sessions 1-24)

**Core Development:**
- ✅ 22 functional tabs with User/Project nested structure
- ✅ Single-scope architecture (Agents, Commands, Skills, MCP)
- ✅ Settings implementation (User/Project tabs)
- ✅ Permissions system with full UI
- ✅ All phases complete - User Config (10 subtabs), Project Config (9 subtabs)

---

## 📝 POST-RESTORATION TASKS

1. Test restored files work
2. Apply scrollbar fix to both QComboBoxes
3. Enhance theme switching to work without restart
4. Add subtabs to Preferences (carefully, with working widgets)
5. Add Config Sync to Backup subtab
6. Test everything thoroughly
7. Commit with proper messages

---

**NEXT ACTION:** User runs /compact, then execute restoration plan above

**END OF TODO.md**
