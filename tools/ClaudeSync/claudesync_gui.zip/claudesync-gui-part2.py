class ClaudeSyncGUI(customtkinter.CTk):
    """Main application window"""
    def __init__(self):
        super().__init__()

        # Initialize components
        self.config = ConfigHandler()
        self.logger = LogHandler()
        self.command_executor = CommandExecutor(self.logger)

        # Window setup
        self.title("ClaudeSync GUI")
        self.geometry(f"{self.config.get('General', 'min_width')}x{self.config.get('General', 'min_height')}")
        self.minsize(
            width=int(self.config.get('General', 'min_width')),
            height=int(self.config.get('General', 'min_height'))
        )

        # Initialize GUI elements
        self.setup_gui()
        
        # First run check
        if self.config.get('General', 'first_run') == 'true':
            self.first_run_setup()
        
        # Check session expiry
        self.check_session_expiry()
        
        # Check for updates
        self.check_for_updates()

    def setup_gui(self):
        """Setup main GUI elements"""
        # Main container
        self.main_container = customtkinter.CTkFrame(self)
        self.main_container.pack(fill="both", expand=True, padx=10, pady=(10, 0))

        # Tab view
        self.tab_view = customtkinter.CTkTabview(self.main_container)
        self.tab_view.pack(fill="both", expand=True)

        # Add tabs
        self.tab_view.add("Authentication")
        self.tab_view.add("Projects")
        self.tab_view.add("Sync")
        self.tab_view.add("Chat")
        self.tab_view.add("Configuration")
        self.tab_view.add("Logs")

        # Setup each tab
        self.setup_auth_tab()
        self.setup_projects_tab()
        self.setup_sync_tab()
        self.setup_chat_tab()
        self.setup_config_tab()
        self.setup_logs_tab()

        # Status bar
        self.status_bar = StatusBar(self)
        self.status_bar.pack(fill="x", padx=10, pady=10)

    def setup_auth_tab(self):
        """Setup Authentication tab"""
        tab = self.tab_view.tab("Authentication")
        
        # Login frame
        login_frame = customtkinter.CTkFrame(tab)
        login_frame.pack(padx=20, pady=20, fill="x")

        # Session key entry
        session_key_label = customtkinter.CTkLabel(login_frame, text="Session Key:")
        session_key_label.grid(row=0, column=0, padx=10, pady=10)
        
        self.session_key_entry = customtkinter.CTkEntry(login_frame, width=300, show="*")
        self.session_key_entry.grid(row=0, column=1, padx=10, pady=10)
        CTkToolTip(self.session_key_entry, message="Enter your Claude.ai session key")

        # Login button
        login_button = customtkinter.CTkButton(
            login_frame,
            text="Login",
            command=self.handle_login
        )
        login_button.grid(row=0, column=2, padx=10, pady=10)

        # Organization selection
        org_frame = customtkinter.CTkFrame(tab)
        org_frame.pack(padx=20, pady=20, fill="x")

        org_label = customtkinter.CTkLabel(org_frame, text="Organization:")
        org_label.grid(row=0, column=0, padx=10, pady=10)

        self.org_dropdown = customtkinter.CTkOptionMenu(
            org_frame,
            values=["No organizations found"],
            command=self.handle_org_selection
        )
        self.org_dropdown.grid(row=0, column=1, padx=10, pady=10)

    def setup_projects_tab(self):
        """Setup Projects tab"""
        tab = self.tab_view.tab("Projects")

        # Project list frame
        list_frame = customtkinter.CTkFrame(tab)
        list_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Project selection
        select_label = customtkinter.CTkLabel(list_frame, text="Select Project:")
        select_label.pack(padx=10, pady=5)

        self.project_list = customtkinter.CTkTextbox(list_frame, height=200)
        self.project_list.pack(padx=10, pady=5, fill="both", expand=True)

        # Buttons frame
        button_frame = customtkinter.CTkFrame(tab)
        button_frame.pack(padx=20, pady=10, fill="x")

        create_button = customtkinter.CTkButton(
            button_frame,
            text="Create Project",
            command=self.create_project
        )
        create_button.pack(side="left", padx=5)

        archive_button = customtkinter.CTkButton(
            button_frame,
            text="Archive Project",
            command=self.archive_project
        )
        archive_button.pack(side="left", padx=5)

        refresh_button = customtkinter.CTkButton(
            button_frame,
            text="Refresh List",
            command=self.refresh_projects
        )
        refresh_button.pack(side="left", padx=5)

    def setup_sync_tab(self):
        """Setup Sync tab"""
        tab = self.tab_view.tab("Sync")

        # Sync options frame
        options_frame = customtkinter.CTkFrame(tab)
        options_frame.pack(padx=20, pady=20, fill="x")

        # Sync mode selection
        mode_label = customtkinter.CTkLabel(options_frame, text="Sync Mode:")
        mode_label.grid(row=0, column=0, padx=10, pady=10)

        self.sync_mode = customtkinter.CTkOptionMenu(
            options_frame,
            values=["Normal", "Uberproject", "Category"],
            command=self.handle_sync_mode_change
        )
        self.sync_mode.grid(row=0, column=1, padx=10, pady=10)

        # Category selection (initially hidden)
        self.category_frame = customtkinter.CTkFrame(options_frame)
        self.category_dropdown = customtkinter.CTkOptionMenu(
            self.category_frame,
            values=["No categories"]
        )
        
        # Preview frame
        preview_frame = customtkinter.CTkFrame(tab)
        preview_frame.pack(padx=20, pady=10, fill="both", expand=True)

        preview_label = customtkinter.CTkLabel(preview_frame, text="Files to Sync:")
        preview_label.pack(padx=10, pady=5)

        self.preview_list = customtkinter.CTkTextbox(preview_frame)
        self.preview_list.pack(padx=10, pady=5, fill="both", expand=True)

        # Scheduler frame
        scheduler_frame = customtkinter.CTkFrame(tab)
        scheduler_frame.pack(padx=20, pady=10, fill="x")

        # Schedule enable switch
        self.schedule_switch = customtkinter.CTkSwitch(
            scheduler_frame,
            text="Enable Scheduling",
            command=self.toggle_scheduler
        )
        self.schedule_switch.grid(row=0, column=0, padx=10, pady=10)

        # Frequency selection
        self.frequency_dropdown = customtkinter.CTkOptionMenu(
            scheduler_frame,
            values=["Daily", "Weekly"],
            command=self.handle_frequency_change
        )
        self.frequency_dropdown.grid(row=0, column=1, padx=10, pady=10)

        # Time selection
        time_label = customtkinter.CTkLabel(scheduler_frame, text="Time:")
        time_label.grid(row=0, column=2, padx=5, pady=10)

        self.time_entry = customtkinter.CTkEntry(scheduler_frame, width=100)
        self.time_entry.grid(row=0, column=3, padx=5, pady=10)
        self.time_entry.insert(0, "00:00")

        # Days selection (for weekly schedule)
        self.days_frame = customtkinter.CTkFrame(scheduler_frame)
        self.day_vars = {}
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for i, day in enumerate(days):
            var = customtkinter.StringVar(value="0")
            checkbox = customtkinter.CTkCheckBox(
                self.days_frame,
                text=day,
                variable=var
            )
            checkbox.grid(row=0, column=i, padx=5, pady=5)
            self.day_vars[day] = var

        # Sync button
        sync_button = customtkinter.CTkButton(
            tab,
            text="Start Sync",
            command=self.start_sync
        )
        sync_button.pack(padx=20, pady=20)

        # Progress bar
        self.sync_progress = customtkinter.CTkProgressBar(tab)
        self.sync_progress.pack(padx=20, pady=10, fill="x")
        self.sync_progress.set(0)

    def setup_chat_tab(self):
        """Setup Chat tab"""
        tab = self.tab_view.tab("Chat")

        # Chat list frame
        list_frame = customtkinter.CTkFrame(tab)
        list_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Chat selection
        select_label = customtkinter.CTkLabel(list_frame, text="Select Chat:")
        select_label.pack(padx=10, pady=5)

        self.chat_list = customtkinter.CTkTextbox(list_frame, height=200)
        self.chat_list.pack(padx=10, pady=5, fill="both", expand=True)

        # Buttons frame
        button_frame = customtkinter.CTkFrame(tab)
        button_frame.pack(padx=20, pady=10, fill="x")

        create_button = customtkinter.CTkButton(
            button_frame,
            text="Create Chat",
            command=self.create_chat
        )
        create_button.pack(side="left", padx=5)

        delete_button = customtkinter.CTkButton(
            button_frame,
            text="Delete Chat",
            command=self.delete_chat
        )
        delete_button.pack(side="left", padx=5)

        sync_button = customtkinter.CTkButton(
            button_frame,
            text="Sync Chats",
            command=self.sync_chats
        )
        sync_button.pack(side="left", padx=5)

        # Message frame
        message_frame = customtkinter.CTkFrame(tab)
        message_frame.pack(padx=20, pady=10, fill="x")

        self.message_entry = customtkinter.CTkEntry(
            message_frame,
            placeholder_text="Enter message..."
        )
        self.message_entry.pack(side="left", padx=5, pady=5, fill="x", expand=True)

        send_button = customtkinter.CTkButton(
            message_frame,
            text="Send",
            command=self.send_message
        )
        send_button.pack(side="right", padx=5, pady=5)

    def setup_config_tab(self):
        """Setup Configuration tab"""
        tab = self.tab_view.tab("Configuration")

        # Create scrollable frame
        config_frame = customtkinter.CTkScrollableFrame(tab)
        config_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Theme selection
        theme_label = customtkinter.CTkLabel(config_frame, text="Theme:")
        theme_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.theme_dropdown = customtkinter.CTkOptionMenu(
            config_frame,
            values=["blue", "dark-blue", "green"],
            command=self.change_theme
        )
        self.theme_dropdown.grid(row=0, column=1, padx=10, pady=10, sticky="w")
        self.theme_dropdown.set(self.config.get("General", "theme"))

        # Sync settings
        upload_delay_label = customtkinter.CTkLabel(config_frame, text="Upload Delay:")
        upload_delay_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        self.upload_delay_entry = customtkinter.CTkEntry(config_frame)
        self.upload_delay_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")
        self.upload_delay_entry.insert(0, self.config.get("Sync", "upload_delay"))

        max_file_size_label = customtkinter.CTkLabel(config_frame, text="Max File Size (bytes):")
        max_file_size_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.max_file_size_entry = customtkinter.CTkEntry(config_frame)
        self.max_file_size_entry.grid(row=2, column=1, padx=10, pady=10, sticky="w")
        self.max_file_size_entry.insert(0, self.config.get("Sync", "max_file_size"))

        # Sync options
        self.two_way_sync_var = customtkinter.StringVar(
            value=self.config.get("Sync", "two_way_sync")
        )
        two_way_sync_check = customtkinter.CTkCheckBox(
            config_frame,
            text="Two-way Sync",
            variable=self.two_way_sync_var
        )
        two_way_sync_check.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky="w")

        self.prune_remote_var = customtkinter.StringVar(
            value=self.config.get("Sync", "prune_remote_files")
        )
        prune_remote_check = customtkinter.CTkCheckBox(
            config_frame,
            text="Prune Remote Files",
            variable=self.prune_remote_var
        )
        prune_remote_check.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky="w")

        # Category management
        category_label = customtkinter.CTkLabel(config_frame, text="Categories:")
        category_label.grid(row=5, column=0, columnspan=2, padx=10, pady=(20,10), sticky="w")

        # Category list
        self.category_list = customtkinter.CTkTextbox(config_frame, height=100)
        self.category_list.grid(row=6, column=0, columnspan=2, padx=10, pady=5, sticky="ew")

        # Category buttons
        category_button_frame = customtkinter.CTkFrame(config_frame)
        category_button_frame.grid(row=7, column=0, columnspan=2, padx=10, pady=10, sticky="ew")

        add_category_button = customtkinter.CTkButton(
            category_button_frame,
            text="Add Category",
            command=self.add_category
        )
        add_category_button.pack(side="left", padx=5)

        remove_category_button = customtkinter.CTkButton(
            category_button_frame,
            text="Remove Category",
            command=self.remove_category
        )
        remove_category_button.pack(side="left", padx=5)

        # Save button
        save_button = customtkinter.CTkButton(
            config_frame,
            text="Apply Changes",
            command=self.save_config
        )
        save_button.grid(row=8, column=0, columnspan=2, padx=10, pady=20)

    def setup_logs_tab(self):
        """Setup Logs tab"""
        tab = self.tab_view.tab("Logs")

        # Log level selection
        level_frame = customtkinter.CTkFrame(tab)
        level_frame.pack(padx=20, pady=10, fill="x")

        level_label = customtkinter.CTkLabel(level_frame, text="Log Level:")
        level_label.pack(side="left", padx=10)

        self.log_level = customtkinter.CTkOptionMenu(
            level_frame,
            values=["INFO", "WARNING", "ERROR", "DEBUG"],
            command=self.change_log_level
        )
        self.log_level.pack(side="left", padx=10)

        # Search frame
        search_frame = customtkinter.CTkFrame(tab)
        search_frame.pack(padx=20, pady=10, fill="x")

        self.search_entry = customtkinter.CTkEntry(
            search_frame,
            placeholder_text="Search logs..."
        )
        self.search_entry.pack(side="left", padx=10, pady=10, fill="x", expand=True)

        search_button = customtkinter.CTkButton(
            search_frame,
            text="Search",
            command=self.search_logs
        )
        search_button.pack(side="right", padx=10, pady=10)

        # Log display
        self.log_display = customtkinter.CTkTextbox(tab)
        self.log_display.pack(padx=20, pady=10, fill="both", expand=True)

        # Buttons frame
        button_frame = customtkinter.CTkFrame(tab)
        button_frame.pack(padx=20, pady=10, fill="x")

        clear_button = customtkinter.CTkButton(
            button_frame,
            text="Clear Logs",
            command=self.clear_logs
        )
        clear_button.pack(side="left", padx=5)

        export_button = customtkinter.CTkButton(
            button_frame,
            text="Export Logs",
            command=self.export_logs
        )
        export_button.pack(side="left", padx=5)

        # Initialize log handler
        self.logger.add_gui_handler(self.update_log_display)

    def update_log_display(self, message: str):
        """Update log display with new message"""
        self.log_display.insert("end", message + "\n")
        self.log_display.see("end")

    # Event handlers and utility methods will be implemented in Part 3