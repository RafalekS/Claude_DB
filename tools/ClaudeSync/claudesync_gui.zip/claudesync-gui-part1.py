#!/usr/bin/env python3
import os
import sys
import json
import logging
import subprocess
import configparser
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any, Tuple
import tkinter as tk
from tkinter import filedialog
import customtkinter
from CTkToolTip.CTkToolTip import CTkToolTip
from PIL import Image
from logging.handlers import RotatingFileHandler

# Configure customtkinter appearance
customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("dark-blue")

class ConfigHandler:
    """Handles all configuration file operations"""
    def __init__(self, config_file: str = "claudesync.conf"):
        self.config_file = config_file
        self.config = configparser.ConfigParser()
        self.load_or_create_config()

    def load_or_create_config(self) -> None:
        if os.path.exists(self.config_file):
            self.config.read(self.config_file)
        else:
            self._create_default_config()

    def _create_default_config(self) -> None:
        self.config['General'] = {
            'theme': 'dark-blue',
            'language': 'en',
            'first_run': 'true',
            'min_width': '800',
            'min_height': '600',
            'log_level': 'INFO',
            'log_file': 'claudesync.log'
        }

        self.config['Authentication'] = {
            'session_key': '',
            'session_expiry': '',
            'active_provider': 'claude.ai',
            'active_organization_id': ''
        }

        self.config['Project'] = {
            'active_project_id': '',
            'active_project_name': '',
            'local_path': ''
        }

        self.config['Sync'] = {
            'upload_delay': '0.5',
            'max_file_size': '32768',
            'two_way_sync': 'false',
            'prune_remote_files': 'false'
        }

        self.config['Schedule'] = {
            'enabled': 'false',
            'frequency': 'daily',
            'time': '00:00',
            'days': ''
        }

        self.config['Categories'] = {}
        
        self.save()

    def save(self) -> None:
        with open(self.config_file, 'w') as configfile:
            self.config.write(configfile)

    def get(self, section: str, key: str, fallback: Any = None) -> str:
        return self.config.get(section, key, fallback=fallback)

    def set(self, section: str, key: str, value: str) -> None:
        if not self.config.has_section(section):
            self.config.add_section(section)
        self.config.set(section, key, str(value))

class LogHandler:
    """Handles application logging"""
    def __init__(self, log_file: str = 'claudesync.log'):
        self.logger = logging.getLogger('ClaudeSync')
        self.logger.setLevel(logging.INFO)
        
        # File Handler
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=5*1024*1024,  # 5MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        ))
        self.logger.addHandler(file_handler)
        
        # Store logs for GUI display
        self.log_queue: List[str] = []
        self.max_queue_size = 1000

    def add_gui_handler(self, callback):
        """Add handler for GUI updates"""
        class GUIHandler(logging.Handler):
            def emit(self_handler, record):
                log_entry = self_handler.format(record)
                callback(log_entry)
                self.log_queue.append(log_entry)
                if len(self.log_queue) > self.max_queue_size:
                    self.log_queue.pop(0)

        gui_handler = GUIHandler()
        gui_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(gui_handler)

    def log(self, level: str, message: str) -> None:
        level_map = {
            'INFO': self.logger.info,
            'WARNING': self.logger.warning,
            'ERROR': self.logger.error,
            'DEBUG': self.logger.debug
        }
        if level.upper() in level_map:
            level_map[level.upper()](message)

class CommandExecutor:
    """Handles CLI command execution"""
    def __init__(self, logger: LogHandler):
        self.logger = logger

    def execute(self, command: List[str]) -> Tuple[int, str, str]:
        try:
            self.logger.log('DEBUG', f"Executing command: {' '.join(command)}")
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            stdout, stderr = process.communicate()
            
            if process.returncode != 0:
                self.logger.log('ERROR', f"Command failed: {stderr}")
            else:
                self.logger.log('DEBUG', f"Command successful: {stdout}")
                
            return process.returncode, stdout, stderr
        except Exception as e:
            self.logger.log('ERROR', f"Command execution error: {str(e)}")
            return -1, "", str(e)

class StatusBar(customtkinter.CTkFrame):
    """Status bar for displaying application state"""
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        self.status = {
            'Connection': 'Disconnected',
            'Project': 'None',
            'Last Sync': 'Never',
            'Status': 'Ready'
        }
        
        self.labels = {}
        for i, (key, value) in enumerate(self.status.items()):
            self.labels[key] = customtkinter.CTkLabel(
                self,
                text=f"{key}: {value}",
                width=150
            )
            self.labels[key].grid(row=0, column=i, padx=5, pady=2, sticky="w")
            
        self.grid_columnconfigure(len(self.status)-1, weight=1)

    def update_status(self, key: str, value: str) -> None:
        if key in self.labels:
            self.status[key] = value
            self.labels[key].configure(text=f"{key}: {value}")

class ConfirmDialog(customtkinter.CTkToplevel):
    """Dialog for confirming dangerous operations"""
    def __init__(self, parent, title: str, message: str):
        super().__init__(parent)
        
        self.title(title)
        self.result = False
        
        # Make dialog modal
        self.transient(parent)
        self.grab_set()
        
        # Layout
        self.geometry("300x150")
        
        label = customtkinter.CTkLabel(self, text=message, wraplength=250)
        label.pack(pady=20, padx=20)
        
        button_frame = customtkinter.CTkFrame(self)
        button_frame.pack(fill="x", padx=20, pady=10)
        
        yes_button = customtkinter.CTkButton(
            button_frame,
            text="Yes",
            command=self.yes_click
        )
        yes_button.pack(side="left", padx=10)
        
        no_button = customtkinter.CTkButton(
            button_frame,
            text="No",
            command=self.no_click
        )
        no_button.pack(side="right", padx=10)
        
        self.wait_window()

    def yes_click(self):
        self.result = True
        self.destroy()

    def no_click(self):
        self.result = False
        self.destroy()

class UpdateCheckDialog(customtkinter.CTkToplevel):
    """Dialog for update checking"""
    def __init__(self, parent):
        super().__init__(parent)
        
        self.title("Checking for Updates")
        self.geometry("300x100")
        
        # Make dialog modal
        self.transient(parent)
        self.grab_set()
        
        self.label = customtkinter.CTkLabel(self, text="Checking for updates...")
        self.label.pack(pady=20)
        
        self.progress = customtkinter.CTkProgressBar(self)
        self.progress.pack(padx=20, pady=10)
        self.progress.start()

    def update_status(self, message: str):
        self.label.configure(text=message)

    def done(self):
        self.progress.stop()
        self.destroy()