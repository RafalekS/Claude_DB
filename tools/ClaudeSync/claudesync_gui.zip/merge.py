def process_file_content(file_path: str, need_indent: bool = False) -> str:
    """Read file and process its content"""
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    processed_lines = []
    for line in lines:
        # Skip empty lines or main guard
        if not line.strip() or line.startswith('if __name__'):
            processed_lines.append(line)
        # Add indentation for class methods
        elif need_indent:
            processed_lines.append('    ' + line)
        # Keep original line
        else:
            processed_lines.append(line)
            
    return ''.join(processed_lines)

# Create the merged file
with open('claudesync_gui.py', 'w', encoding='utf-8') as outfile:
    # Part 1 - No indentation needed
    part1 = process_file_content('claudesync-gui-part1.py')
    outfile.write(part1)
    outfile.write('\n\n')
    
    # Part 2 - Needs indentation for class methods
    part2 = process_file_content('claudesync-gui-part2.py', need_indent=True)
    outfile.write(part2)
    outfile.write('\n\n')
    
    # Part 3 - Needs indentation for class methods
    part3 = process_file_content('claudesync-gui-part3.py', need_indent=True)
    outfile.write(part3)

print("Files merged successfully into claudesync_gui.py")