def first_run_setup(self):
        """Handle first run setup"""
        dialog = customtkinter.CTkInputDialog(
            text="Please enter your Claude.ai session key:",
            title="First Run Setup"
        )
        session_key = dialog.get_input()
        if session_key:
            self.config.set("Authentication", "session_key", session_key)
            self.config.set("General", "first_run", "false")
            self.config.save()
            self.session_key_entry.insert(0, session_key)
            self.handle_login()

    def check_session_expiry(self):
        """Check if session key is near expiration"""
        expiry_str = self.config.get("Authentication", "session_expiry")
        if expiry_str:
            expiry = datetime.strptime(expiry_str, "%Y-%m-%d %H:%M:%S")
            warning_threshold = expiry - timedelta(days=7)
            if datetime.now() >= warning_threshold:
                self.show_warning(
                    "Session Expiring",
                    f"Your session key will expire on {expiry.strftime('%Y-%m-%d')}. Please update it soon."
                )

    def check_for_updates(self):
        """Check for application updates"""
        dialog = UpdateCheckDialog(self)
        
        try:
            # Execute update check command
            returncode, stdout, stderr = self.command_executor.execute(
                ["claudesync", "upgrade", "--check"]
            )
            
            if returncode == 0 and "upgrade available" in stdout.lower():
                dialog.update_status("Update available!")
                if self.show_confirm("Update Available", "Would you like to update now?"):
                    self.perform_update()
            else:
                dialog.update_status("No updates available")
                self.after(2000, dialog.done)
                
        except Exception as e:
            dialog.update_status(f"Update check failed: {str(e)}")
            self.after(2000, dialog.done)

    def perform_update(self):
        """Perform application update"""
        returncode, stdout, stderr = self.command_executor.execute(
            ["claudesync", "upgrade"]
        )
        if returncode == 0:
            self.show_info("Update Complete", "Application has been updated successfully. Please restart the application.")
        else:
            self.show_error("Update Failed", f"Failed to update: {stderr}")

    # Authentication handlers
    def handle_login(self):
        """Handle login attempt"""
        session_key = self.session_key_entry.get()
        if not session_key:
            self.show_error("Login Error", "Please enter a session key")
            return

        # Save session key
        self.config.set("Authentication", "session_key", session_key)
        self.config.save()

        # Attempt login
        returncode, stdout, stderr = self.command_executor.execute(
            ["claudesync", "auth", "login", "--provider", "claude.ai"]
        )

        if returncode == 0:
            self.status_bar.update_status("Connection", "Connected")
            self.load_organizations()
        else:
            self.show_error("Login Failed", f"Failed to login: {stderr}")

    def load_organizations(self):
        """Load available organizations"""
        returncode, stdout, stderr = self.command_executor.execute(
            ["claudesync", "organization", "ls"]
        )
        
        if returncode == 0:
            orgs = [line.strip() for line in stdout.split('\n') if line.strip()]
            if orgs:
                self.org_dropdown.configure(values=orgs)
                self.org_dropdown.set(orgs[0])

    def handle_org_selection(self, org: str):
        """Handle organization selection"""
        returncode, stdout, stderr = self.command_executor.execute(
            ["claudesync", "organization", "set", org]
        )
        
        if returncode == 0:
            self.config.set("Authentication", "active_organization_id", org)
            self.config.save()
            self.refresh_projects()

    # Project handlers
    def refresh_projects(self):
        """Refresh project list"""
        returncode, stdout, stderr = self.command_executor.execute(
            ["claudesync", "project", "ls", "-a"]
        )
        
        if returncode == 0:
            self.project_list.delete("0.0", "end")
            self.project_list.insert("0.0", stdout)

    def create_project(self):
        """Create new project"""
        name_dialog = customtkinter.CTkInputDialog(
            text="Enter project name:",
            title="Create Project"
        )
        project_name = name_dialog.get_input()
        
        if project_name:
            path_dialog = customtkinter.CTkInputDialog(
                text="Enter project path:",
                title="Create Project"
            )
            project_path = path_dialog.get_input()
            
            if project_path:
                returncode, stdout, stderr = self.command_executor.execute(
                    ["claudesync", "project", "create", "--name", project_name, "--path", project_path]
                )
                
                if returncode == 0:
                    self.refresh_projects()
                else:
                    self.show_error("Project Creation Failed", f"Failed to create project: {stderr}")

    def archive_project(self):
        """Archive selected project"""
        if self.show_confirm("Archive Project", "Are you sure you want to archive this project?"):
            returncode, stdout, stderr = self.command_executor.execute(
                ["claudesync", "project", "archive"]
            )
            
            if returncode == 0:
                self.refresh_projects()
            else:
                self.show_error("Archive Failed", f"Failed to archive project: {stderr}")

    # Sync handlers
    def handle_sync_mode_change(self, mode: str):
        """Handle sync mode change"""
        if mode == "Category":
            self.category_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=10)
            self.load_categories()
        else:
            self.category_frame.grid_forget()

    def load_categories(self):
        """Load available categories"""
        if "Categories" in self.config.config:
            categories = list(self.config.config["Categories"].keys())
            if categories:
                self.category_dropdown.configure(values=categories)
                self.category_dropdown.set(categories[0])

    def toggle_scheduler(self):
        """Toggle scheduler settings"""
        enabled = self.schedule_switch.get()
        self.frequency_dropdown.configure(state="normal" if enabled else "disabled")
        self.time_entry.configure(state="normal" if enabled else "disabled")
        
        if enabled and self.frequency_dropdown.get() == "Weekly":
            self.days_frame.grid(row=1, column=0, columnspan=4, padx=10, pady=10)
        else:
            self.days_frame.grid_forget()

    def handle_frequency_change(self, frequency: str):
        """Handle schedule frequency change"""
        if frequency == "Weekly" and self.schedule_switch.get():
            self.days_frame.grid(row=1, column=0, columnspan=4, padx=10, pady=10)
        else:
            self.days_frame.grid_forget()

    def start_sync(self):
        """Start sync operation"""
        # Get files to sync
        self.preview_sync()
        
        if not self.show_confirm("Start Sync", "Do you want to proceed with the sync?"):
            return

        self.sync_progress.set(0)
        self.sync_progress.start()
        
        # Prepare sync command
        cmd = ["claudesync", "push"]
        mode = self.sync_mode.get()
        
        if mode == "Uberproject":
            cmd.append("--uberproject")
        elif mode == "Category":
            cmd.extend(["--category", self.category_dropdown.get()])

        # Execute sync
        returncode, stdout, stderr = self.command_executor.execute(cmd)
        
        self.sync_progress.stop()
        
        if returncode == 0:
            self.sync_progress.set(1)
            self.status_bar.update_status("Last Sync", datetime.now().strftime("%Y-%m-%d %H:%M"))
            self.show_info("Sync Complete", "Files synchronized successfully")
        else:
            self.sync_progress.set(0)
            self.show_error("Sync Failed", f"Failed to sync: {stderr}")

    def preview_sync(self):
        """Preview files to be synced"""
        cmd = ["claudesync", "project", "file", "ls"]
        returncode, stdout, stderr = self.command_executor.execute(cmd)
        
        if returncode == 0:
            self.preview_list.delete("0.0", "end")
            self.preview_list.insert("0.0", stdout)

    # Chat handlers
    def create_chat(self):
        """Create new chat"""
        name_dialog = customtkinter.CTkInputDialog(
            text="Enter chat name:",
            title="Create Chat"
        )
        chat_name = name_dialog.get_input()
        
        if chat_name:
            returncode, stdout, stderr = self.command_executor.execute(
                ["claudesync", "chat", "init", "--name", chat_name]
            )
            
            if returncode == 0:
                self.refresh_chats()
            else:
                self.show_error("Chat Creation Failed", f"Failed to create chat: {stderr}")

    def delete_chat(self):
        """Delete selected chat"""
        if self.show_confirm("Delete Chat", "Are you sure you want to delete this chat?"):
            returncode, stdout, stderr = self.command_executor.execute(
                ["claudesync", "chat", "rm"]
            )
            
            if returncode == 0:
                self.refresh_chats()
            else:
                self.show_error("Delete Failed", f"Failed to delete chat: {stderr}")

    def sync_chats(self):
        """Sync chats"""
        returncode, stdout, stderr = self.command_executor.execute(
            ["claudesync", "chat", "pull"]
        )
        
        if returncode == 0:
            self.refresh_chats()
        else:
            self.show_error("Sync Failed", f"Failed to sync chats: {stderr}")

    def refresh_chats(self):
        """Refresh chat list"""
        returncode, stdout, stderr = self.command_executor.execute(
            ["claudesync", "chat", "ls"]
        )
        
        if returncode == 0:
            self.chat_list.delete("0.0", "end")
            self.chat_list.insert("0.0", stdout)

    def send_message(self):
        """Send chat message"""
        message = self.message_entry.get()
        if message:
            returncode, stdout, stderr = self.command_executor.execute(
                ["claudesync", "chat", "message", message]
            )
            
            if returncode == 0:
                self.message_entry.delete(0, "end")
                self.refresh_chats()
            else:
                self.show_error("Send Failed", f"Failed to send message: {stderr}")

    # Configuration handlers
    def change_theme(self, theme: str):
        """Change application theme"""
        customtkinter.set_default_color_theme(theme)
        self.config.set("General", "theme", theme)
        self.config.save()

    def add_category(self):
        """Add new category"""
        name_dialog = customtkinter.CTkInputDialog(
            text="Enter category name:",
            title="Add Category"
        )
        name = name_dialog.get_input()
        
        if name:
            desc_dialog = customtkinter.CTkInputDialog(
                text="Enter category description:",
                title="Add Category"
            )
            desc = desc_dialog.get_input()
            
            if desc:
                pattern_dialog = customtkinter.CTkInputDialog(
                    text="Enter file patterns (comma-separated):",
                    title="Add Category"
                )
                patterns = pattern_dialog.get_input()
                
                if patterns:
                    category_data = {
                        "description": desc,
                        "patterns": [p.strip() for p in patterns.split(",")]
                    }
                    self.config.set("Categories", name, json.dumps(category_data))
                    self.config.save()
                    self.refresh_categories()

    def remove_category(self):
        """Remove selected category"""
        if "Categories" in self.config.config:
            categories = list(self.config.config["Categories"].keys())
            if categories:
                dialog = customtkinter.CTkInputDialog(
                    text="Select category to remove:",
                    title="Remove Category"
                )
                category = dialog.get_input()
                
                if category in categories:
                    if self.show_confirm("Remove Category", f"Are you sure you want to remove category '{category}'?"):
                        self.config.config.remove_option("Categories", category)
                        self.config.save()
                        self.refresh_categories()

    def refresh_categories(self):
        """Refresh category list display"""
        if "Categories" in self.config.config:
            self.category_list.delete("0.0", "end")
            for name, data_str in self.config.config["Categories"].items():
                data = json.loads(data_str)
                self.category_list.insert("end", f"Name: {name}\n")
                self.category_list.insert("end", f"Description: {data['description']}\n")
                self.category_list.insert("end", f"Patterns: {', '.join(data['patterns'])}\n\n")

    def save_config(self):
        """Save configuration changes"""
        # Save sync settings
        self.config.set("Sync", "upload_delay", self.upload_delay_entry.get())
        self.config.set("Sync", "max_file_size", self.max_file_size_entry.get())
        self.config.set("Sync", "two_way_sync", self.two_way_sync_var.get())
        self.config.set("Sync", "prune_remote_files", self.prune_remote_var.get())
        
        # Save scheduler settings
        self.config.set("Schedule", "enabled", str(self.schedule_switch.get()))
        self.config.set("Schedule", "frequency", self.frequency_dropdown.get())
        self.config.set("Schedule", "time", self.time_entry.get())
        
        if self.frequency_dropdown.get() == "Weekly":
            selected_days = [day for day, var in self.day_vars.items() if var.get() == "1"]
            self.config.set("Schedule", "days", ",".join(selected_days))
        
        self.config.save()
        self.show_info("Configuration", "Settings saved successfully")

    # Log handlers
    def change_log_level(self, level: str):
        """Change logging level"""
        self.logger.logger.setLevel(getattr(logging, level))
        self.config.set("General", "log_level", level)
        self.config.save()

    def search_logs(self):
        """Search logs for text"""
        search_text = self.search_entry.get()
        if search_text:
            self.log_display.delete("0.0", "end")
            for log in self.logger.log_queue:
                if search_text.lower() in log.lower():
                    self.log_display.insert("end", log + "\n")

def clear_logs(self):
        """Clear log display"""
        if self.show_confirm("Clear Logs", "Are you sure you want to clear the logs?"):
            self.log_display.delete("0.0", "end")
            self.logger.log_queue.clear()

    def export_logs(self):
        """Export logs to file"""
        filename = filedialog.asksaveasfilename(
            defaultextension=".log",
            filetypes=[("Log files", "*.log"), ("All files", "*.*")]
        )
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(self.log_display.get("0.0", "end"))
                self.show_info("Export Complete", "Logs exported successfully")
            except Exception as e:
                self.show_error("Export Failed", f"Failed to export logs: {str(e)}")

    # Utility methods
    def show_error(self, title: str, message: str):
        """Show error dialog"""
        dialog = customtkinter.CTkInputDialog(
            text=message,
            title=title
        )

    def show_warning(self, title: str, message: str):
        """Show warning dialog"""
        dialog = customtkinter.CTkInputDialog(
            text=message,
            title=title
        )

    def show_info(self, title: str, message: str):
        """Show info dialog"""
        dialog = customtkinter.CTkInputDialog(
            text=message,
            title=title
        )

    def show_confirm(self, title: str, message: str) -> bool:
        """Show confirmation dialog"""
        dialog = ConfirmDialog(self, title, message)
        return dialog.result

if __name__ == "__main__":
    app = ClaudeSyncGUI()
    app.mainloop()