class ClaudeSyncGUI(customtkinter.CTk):
    """Main application window"""
    def __init__(self):
        super().__init__()

        # Initialize components
        self.config = ConfigHandler()
        self.logger = LogHandler()
        self.command_executor = CommandExecutor(self.logger)

        # Window setup
        self.title("ClaudeSync GUI")
        self.geometry(f"{self.config.get('General', 'min_width')}x{self.config.get('General', 'min_height')}")
        self.minsize(
            width=int(self.config.get('General', 'min_width')),
            height=int(self.config.get('General', 'min_height'))
        )

        # Initialize GUI elements
        self.setup_gui()
        
        # First run check
        if self.config.get('General', 'first_run') == 'true':
            self.first_run_setup()
        
        # Check session expiry
        self.check_session_expiry()
        
        # Check for updates
        self.check_for_updates()

    def setup_gui(self):
        """Setup main GUI elements"""
        # Main container
        self.main_container = customtkinter.CTkFrame(self)
        self.main_container.pack(fill="both", expand=True, padx=10, pady=(10, 0))

        # Tab view
        self.tab_view = customtkinter.CTkTabview(self.main_container)
        self.tab_view.pack(fill="both", expand=True)

        # Add tabs
        self.tab_view.add("Authentication")
        self.tab_view.add("Projects")
        self.tab_view.add("Sync")
        self.tab_view.add("Chat")
        self.tab_view.add("Configuration")
        self.tab_view.add("Logs")

        # Setup each tab
        self.setup_auth_tab()
        self.setup_projects_tab()
        self.setup_sync_tab()
        self.setup_chat_tab()
        self.setup_config_tab()
        self.setup_logs_tab()

        # Status bar
        self.status_bar = StatusBar(self)
        self.status_bar.pack(fill="x", padx=10, pady=10)

    def setup_auth_tab(self):
        """Setup Authentication tab"""
        tab = self.tab_view.tab("Authentication")
        
        # Login frame
        login_frame = customtkinter.CTkFrame(tab)
        login_frame.pack(padx=20, pady=20, fill="x")

        # Session key entry
        session_key_label = customtkinter.CTkLabel(login_frame, text="Session Key:")
        session_key_label.grid(row=0, column=0, padx=10, pady=10)
        
        self.session_key_entry = customtkinter.CTkEntry(login_frame, width=300, show="*")
        self.session_key_entry.grid(row=0, column=1, padx=10, pady=10)
        CTkToolTip(self.session_key_entry, message="Enter your Claude.ai session key")

        # Login button
        login_button = customtkinter.CTkButton(
            login_frame,
            text="Login",
            command=self.handle_login
        )
        login_button.grid(row=0, column=2, padx=10, pady=10)

        # Organization selection
        org_frame = customtkinter.CTkFrame(tab)
        org_frame.pack(padx=20, pady=20, fill="x")

        org_label = customtkinter.CTkLabel(org_frame, text="Organization:")
        org_label.grid(row=0, column=0, padx=10, pady=10)

        self.org_dropdown = customtkinter.CTkOptionMenu(
            org_frame,
            values=["No organizations found"],
            command=self.handle_org_selection
        )
        self.org_dropdown.grid(row=0, column=1, padx=10, pady=10)

    def setup_projects_tab(self):
        """Setup Projects tab"""
        tab = self.tab_view.tab("Projects")

        # Project list frame
        list_frame = customtkinter.CTkFrame(tab)
        list_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Project selection
        select_label = customtkinter.CTkLabel(list_frame, text="Select Project:")
        select_label.pack(padx=10, pady=5)

        self.project_list = customtkinter.CTkTextbox(list_frame, height=200)
        self.project_list.pack(padx=10, pady=5, fill="both", expand=True)

        # Buttons frame
        button_frame = customtkinter.CTkFrame(tab)
        button_frame.pack(padx=20, pady=10, fill="x")

        create_button = customtkinter.CTkButton(
            button_frame,
            text="Create Project",
            command=self.create_project
        )
        create_button.pack(side="left", padx=5)

        archive_button = customtkinter.CTkButton(
            button_frame,
            text="Archive Project",
            command=self.archive_project
        )
        archive_button.pack(side="left", padx=5)

        refresh_button = customtkinter.CTkButton(
            button_frame,
            text="Refresh List",
            command=self.refresh_projects
        )
        refresh_button.pack(side="left", padx=5)

    def setup_sync_tab(self):
        """Setup Sync tab"""
        tab = self.tab_view.tab("Sync")

        # Sync options frame
        options_frame = customtkinter.CTkFrame(tab)
        options_frame.pack(padx=20, pady=20, fill="x")

        # Sync mode selection
        mode_label = customtkinter.CTkLabel(options_frame, text="Sync Mode:")
        mode_label.grid(row=0, column=0, padx=10, pady=10)

        self.sync_mode = customtkinter.CTkOptionMenu(
            options_frame,
            values=["Normal", "Uberproject", "Category"],
            command=self.handle_sync_mode_change
        )
        self.sync_mode.grid(row=0, column=1, padx=10, pady=10)

        # Category selection (initially hidden)
        self.category_frame = customtkinter.CTkFrame(options_frame)
        self.category_dropdown = customtkinter.CTkOptionMenu(
            self.category_frame,
            values=["No categories"]
        )
        
        # Preview frame
        preview_frame = customtkinter.CTkFrame(tab)
        preview_frame.pack(padx=20, pady=10, fill="both", expand=True)

        preview_label = customtkinter.CTkLabel(preview_frame, text="Files to Sync:")
        preview_label.pack(padx=10, pady=5)

        self.preview_list = customtkinter.CTkTextbox(preview_frame)
        self.preview_list.pack(padx=10, pady=5, fill="both", expand=True)

        # Scheduler frame
        scheduler_frame = customtkinter.CTkFrame(tab)
        scheduler_frame.pack(padx=20, pady=10, fill="x")

        # Schedule enable switch
        self.schedule_switch = customtkinter.CTkSwitch(
            scheduler_frame,
            text="Enable Scheduling",
            command=self.toggle_scheduler
        )
        self.schedule_switch.grid(row=0, column=0, padx=10, pady=10)

        # Frequency selection
        self.frequency_dropdown = customtkinter.CTkOptionMenu(
            scheduler_frame,
            values=["Daily", "Weekly"],
            command=self.handle_frequency_change
        )
        self.frequency_dropdown.grid(row=0, column=1, padx=10, pady=10)

        # Time selection
        time_label = customtkinter.CTkLabel(scheduler_frame, text="Time:")
        time_label.grid(row=0, column=2, padx=5, pady=10)

        self.time_entry = customtkinter.CTkEntry(scheduler_frame, width=100)
        self.time_entry.grid(row=0, column=3, padx=5, pady=10)
        self.time_entry.insert(0, "00:00")

        # Days selection (for weekly schedule)
        self.days_frame = customtkinter.CTkFrame(scheduler_frame)
        self.day_vars = {}
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for i, day in enumerate(days):
            var = customtkinter.StringVar(value="0")
            checkbox = customtkinter.CTkCheckBox(
                self.days_frame,
                text=day,
                variable=var
            )
            checkbox.grid(row=0, column=i, padx=5, pady=5)
            self.day_vars[day] = var

        # Sync button
        sync_button = customtkinter.CTkButton(
            tab,
            text="Start Sync",
            command=self.start_sync
        )
        sync_button.pack(padx=20, pady=20)

        # Progress bar
        self.sync_progress = customtkinter.CTkProgressBar(tab)
        self.sync_progress.pack(padx=20, pady=10, fill="x")
        self.sync_progress.set(0)

