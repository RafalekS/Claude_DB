def setup_chat_tab(self):
        """Setup Chat tab"""
        tab = self.tab_view.tab("Chat")

        # Chat list frame
        list_frame = customtkinter.CTkFrame(tab)
        list_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Chat selection
        select_label = customtkinter.CTkLabel(list_frame, text="Select Chat:")
        select_label.pack(padx=10, pady=5)

        self.chat_list = customtkinter.CTkTextbox(list_frame, height=200)
        self.chat_list.pack(padx=10, pady=5, fill="both", expand=True)

        # Buttons frame
        button_frame = customtkinter.CTkFrame(tab)
        button_frame.pack(padx=20, pady=10, fill="x")

        create_button = customtkinter.CTkButton(
            button_frame,
            text="Create Chat",
            command=self.create_chat
        )
        create_button.pack(side="left", padx=5)

        delete_button = customtkinter.CTkButton(
            button_frame,
            text="Delete Chat",
            command=self.delete_chat
        )
        delete_button.pack(side="left", padx=5)

        sync_button = customtkinter.CTkButton(
            button_frame,
            text="Sync Chats",
            command=self.sync_chats
        )
        sync_button.pack(side="left", padx=5)

        # Message frame
        message_frame = customtkinter.CTkFrame(tab)
        message_frame.pack(padx=20, pady=10, fill="x")

        self.message_entry = customtkinter.CTkEntry(
            message_frame,
            placeholder_text="Enter message..."
        )
        self.message_entry.pack(side="left", padx=5, pady=5, fill="x", expand=True)

        send_button = customtkinter.CTkButton(
            message_frame,
            text="Send",
            command=self.send_message
        )
        send_button.pack(side="right", padx=5, pady=5)

    def setup_config_tab(self):
        """Setup Configuration tab"""
        tab = self.tab_view.tab("Configuration")

        # Create scrollable frame
        config_frame = customtkinter.CTkScrollableFrame(tab)
        config_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Theme selection
        theme_label = customtkinter.CTkLabel(config_frame, text="Theme:")
        theme_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.theme_dropdown = customtkinter.CTkOptionMenu(
            config_frame,
            values=["blue", "dark-blue", "green"],
            command=self.change_theme
        )
        self.theme_dropdown.grid(row=0, column=1, padx=10, pady=10, sticky="w")
        self.theme_dropdown.set(self.config.get("General", "theme"))

        # Sync settings
        upload_delay_label = customtkinter.CTkLabel(config_frame, text="Upload Delay:")
        upload_delay_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        self.upload_delay_entry = customtkinter.CTkEntry(config_frame)
        self.upload_delay_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")
        self.upload_delay_entry.insert(0, self.config.get("Sync", "upload_delay"))

        max_file_size_label = customtkinter.CTkLabel(config_frame, text="Max File Size (bytes):")
        max_file_size_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.max_file_size_entry = customtkinter.CTkEntry(config_frame)
        self.max_file_size_entry.grid(row=2, column=1, padx=10, pady=10, sticky="w")
        self.max_file_size_entry.insert(0, self.config.get("Sync", "max_file_size"))

        # Sync options
        self.two_way_sync_var = customtkinter.StringVar(
            value=self.config.get("Sync", "two_way_sync")
        )
        two_way_sync_check = customtkinter.CTkCheckBox(
            config_frame,
            text="Two-way Sync",
            variable=self.two_way_sync_var
        )
        two_way_sync_check.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky="w")

        self.prune_remote_var = customtkinter.StringVar(
            value=self.config.get("Sync", "prune_remote_files")
        )
        prune_remote_check = customtkinter.CTkCheckBox(
            config_frame,
            text="Prune Remote Files",
            variable=self.prune_remote_var
        )
        prune_remote_check.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky="w")

        # Category management
        category_label = customtkinter.CTkLabel(config_frame, text="Categories:")
        category_label.grid(row=5, column=0, columnspan=2, padx=10, pady=(20,10), sticky="w")

        # Category list
        self.category_list = customtkinter.CTkTextbox(config_frame, height=100)
        self.category_list.grid(row=6, column=0, columnspan=2, padx=10, pady=5, sticky="ew")

        # Category buttons
        category_button_frame = customtkinter.CTkFrame(config_frame)
        category_button_frame.grid(row=7, column=0, columnspan=2, padx=10, pady=10, sticky="ew")

        add_category_button = customtkinter.CTkButton(
            category_button_frame,
            text="Add Category",
            command=self.add_category
        )
        add_category_button.pack(side="left", padx=5)

        remove_category_button = customtkinter.CTkButton(
            category_button_frame,
            text="Remove Category",
            command=self.remove_category
        )
        remove_category_button.pack(side="left", padx=5)

        # Save button
        save_button = customtkinter.CTkButton(
            config_frame,
            text="Apply Changes",
            command=self.save_config
        )
        save_button.grid(row=8, column=0, columnspan=2, padx=10, pady=20)

    def setup_logs_tab(self):
        """Setup Logs tab"""
        tab = self.tab_view.tab("Logs")

        # Log level selection
        level_frame = customtkinter.CTkFrame(tab)
        level_frame.pack(padx=20, pady=10, fill="x")

        level_label = customtkinter.CTkLabel(level_frame, text="Log Level:")
        level_label.pack(side="left", padx=10)

        self.log_level = customtkinter.CTkOptionMenu(
            level_frame,
            values=["INFO", "WARNING", "ERROR", "DEBUG"],
            command=self.change_log_level
        )
        self.log_level.pack(side="left", padx=10)

        # Search frame
        search_frame = customtkinter.CTkFrame(tab)
        search_frame.pack(padx=20, pady=10, fill="x")

        self.search_entry = customtkinter.CTkEntry(
            search_frame,
            placeholder_text="Search logs..."
        )
        self.search_entry.pack(side="left", padx=10, pady=10, fill="x", expand=True)

        search_button = customtkinter.CTkButton(
            search_frame,
            text="Search",
            command=self.search_logs
        )
        search_button.pack(side="right", padx=10, pady=10)

        # Log display
        self.log_display = customtkinter.CTkTextbox(tab)
        self.log_display.pack(padx=20, pady=10, fill="both", expand=True)

        # Buttons frame
        button_frame = customtkinter.CTkFrame(tab)
        button_frame.pack(padx=20, pady=10, fill="x")

        clear_button = customtkinter.CTkButton(
            button_frame,
            text="Clear Logs",
            command=self.clear_logs
        )
        clear_button.pack(side="left", padx=5)

        export_button = customtkinter.CTkButton(
            button_frame,
            text="Export Logs",
            command=self.export_logs
        )
        export_button.pack(side="left", padx=5)

        # Initialize log handler
        self.logger.add_gui_handler(self.update_log_display)

    def update_log_display(self, message: str):
        """Update log display with new message"""
        self.log_display.insert("end", message + "\n")
        self.log_display.see("end")
